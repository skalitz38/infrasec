
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class CodeComprehensionSolver(SolverTemplate):
    available_solvers = ['*']
    router_description = cleandoc("""\
        **CodeComprehensionSolver** - 代码语义理解专家
        - **专业领域**: 代码语义理解
        - **核心能力**: 分析代码逻辑、识别代码模式、理解代码意图
        - **适用场景**: 复杂代码语义理解
        - **协作关系**: 当难以理解代码语义信息时，负责详细解释代码语义，拆解成当前可解决的子问题""")
    
    def _init_solver(self):
        self.domain = "处理代码中比较复杂的语义"
        self.capabilities = cleandoc("""\
            识别并总结代码中的复杂语义""")
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：理解当前任务
            **任务理解**：
            - **任务分析**：分析当前任务是什么，需要理解什么代码语义
            - **上下文分析**：根据所给的上下文，理解代码的复杂语义
            - **显式声明**：在reasoning中明确记录"理解当前任务：[具体任务描述]"
            
            ### 第二步：分析代码语义
            **语义分析逻辑**：
            - **代码结构分析**：分析代码的结构和组成
            - **语义识别**：识别代码中的复杂语义和逻辑
            - **功能总结**：总结代码的功能和作用
            - **显式声明**：在reasoning中明确记录"分析代码语义：[具体语义分析]"
            
            ### 第三步：总结代码语义
            **语义总结**：
            - **核心功能**：总结代码的核心功能
            - **关键逻辑**：识别关键逻辑和流程
            - **语义描述**：用简洁的语言描述代码语义
            - **显式声明**：在reasoning中记录"总结代码语义：[具体语义总结]"
            
            ### 第四步：结果自检与输出
            **自检清单**：
            1. 是否理解了当前任务？任务是什么？
            2. 是否分析了代码语义？语义是什么？
            3. 是否总结了代码语义？总结是否准确？
            4. 语义描述是否简洁明了？
            5. 每个结论都有明确的依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功理解代码语义且信息完整时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **NEEDS_FOLLOWUP**：当遇到无法解决的问题时，必须详细描述问题场景
            - **FAILED**：当遇到无法处理的情况时，必须详细描述问题场景""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于代码分析的语义理解总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)任务理解过程 2)代码语义分析过程 3)语义总结过程 4)推断依据 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "semantic": "理解的代码语义，用50个字以内总结"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "analyze_code_semantic", 
                        "parameters": { "code_context": "代码上下文" }, 
                        "description": "分析代码语义",
                        "reason": "需要分析代码语义进行理解"
                    }
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_self_cls_result  
        self.post_processor = self._post_process_self_cls_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["field_name", "class_name", "current_file"]
        return all(param in task.params for param in required_params)
    
    def _validate_self_cls_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["type"]
        return all(field in result_data for field in required_fields)
    
    def _post_process_self_cls_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
