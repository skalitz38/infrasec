
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class MethodFinderSolver(SolverTemplate):

    available_solvers = []
    router_description = cleandoc("""\
        **MethodFinderSolver** - 方法查找专家
        - **重要区分**：该solver用于**已知类名/模块名**，在该类/模块中寻找相应方法。且不处理self.func()形式。
        - **专业领域**: 从指定类/模块/包中查找指定方法
        - **解答问题**: 在给定的类/模块/包中是否存在指定的方法？
        - **适用场景**: 需要确认某个类/模块/包中是否定义了特定方法
    """)
    
    def _init_solver(self):
        self.domain = "方法查找与存在性验证"
        self.capabilities = "类方法查找、模块方法查找、包方法查找、链式调用解析"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            ### 第一步：判断任务相关性
            **非当前职责**：
            - **不处理的情况**: 任何以self/cls开头的方法；没有明确从哪个模块/哪个类中寻找方法。
            - **决策**：返回FAILED，说明为什么不处理。
   
            ### 第二步：分析容器类型和标识符
            **容器分析**：
            - **类查找**：如果container_type为"class"
              - **强制工具调用**：调用get_class_define_path(container_identifier)获取类定义路径
              - **验证要求**：必须获得明确的类定义路径信息
              - **显式声明**：在reasoning中明确记录"已调用get_class_define_path，获得类[container_identifier]定义路径：[具体路径]"
              - **内部类检查**：如果返回路径不为空，说明是内部类，继续第三步
              - **外部类处理**：如果返回路径为空，说明是外部类，返回FAILED
            
            - **模块查找**：如果container_type为"module"
              - **决策**：直接进入第四步，调用get_method_code_in_container
              - **显式声明**：在reasoning中记录"容器类型为模块，直接查找方法"
            
            - **包查找**：如果container_type为"package"
              - **决策**：直接进入第四步，调用get_method_code_in_container
              - **显式声明**：在reasoning中记录"容器类型为包，直接查找方法"
            
            ### 第三步：处理链式调用形式（如a.b.c.method_name）
            **链式调用分析**：
            - **识别链式调用**：如果method_name包含"."，如"a.b.c.method_name"
              - **分解调用链**：将method_name分解为路径部分和方法名部分
              - **路径解析**：调用get_possible_sources_of_key分别获取a、b、c的可能来源
              - **显式声明**：在reasoning中记录"检测到链式调用[method_name]，开始解析调用链"
              
              - **逐步解析**：
                - 调用get_possible_sources_of_key("a")获取a的可能来源
                - 调用get_possible_sources_of_key("b")获取b的可能来源  
                - 调用get_possible_sources_of_key("c")获取c的可能来源
                - 显式声明每个步骤的调用结果
              
              - **最终方法查找**：基于解析结果，确定最终的容器和方法名
                - 如果解析出明确的容器，调用get_method_code_in_container
                - 如果无法确定容器，返回FAILED
            
            ### 第四步：查找方法定义
            **方法查找逻辑**：
            - **类方法查找**：如果container_type为"class"
              - **强制工具调用**：调用check_method_of_class(container_identifier, method_name)
              - **验证要求**：必须获得明确的方法存在性信息
              - **显式声明**：在reasoning中明确记录"已调用check_method_of_class，检查类[container_identifier]中是否存在方法[method_name]，结果：[具体结果]"
            
            - **模块/包方法查找**：如果container_type为"module"或"package"
              - **强制工具调用**：调用get_method_code_in_container(method_name, container_identifier, container_type)
              - **验证要求**：必须获得明确的方法信息
              - **显式声明**：在reasoning中明确记录"已调用get_method_code_in_container，在[container_type][container_identifier]中查找方法[method_name]，结果：[具体结果]"
            
            ### 第五步：处理符号定义查找
            **符号定义查找**：
            - **如果方法查找失败**：尝试查找符号定义
              - **强制工具调用**：调用find_last_define_of_symbol(method_name)
              - **验证要求**：必须获得明确的符号定义信息
              - **显式声明**：在reasoning中明确记录"已调用find_last_define_of_symbol，查找符号[method_name]的定义，结果：[具体结果]"
            
            ### 第六步：结果分析与输出
            **结果处理**：
            - **方法存在**：如果成功找到方法信息
              - **决策**：返回COMPLETED，包含完整的方法信息
              - **显式声明**：在reasoning中明确记录"成功找到方法[method_name]，位置：[method_location]"
            
            - **方法不存在**：如果确认方法不存在
              - **决策**：返回COMPLETED，method_exists为false
              - **显式声明**：在reasoning中明确记录"确认方法[method_name]在[container_identifier]中不存在"
            
            - **无法确定**：如果无法确定方法是否存在
              - **决策**：返回FAILED
              - **显式声明**：在reasoning中记录"无法确定方法[method_name]是否存在"
            
            ### 第七步：结果自检与输出
            **自检清单**：
            0. 是否查看了当前任务执行历史中其他Solver的结果？
            1. 是否正确分析了容器类型和标识符？
            2. 是否处理了链式调用形式？
            3. 是否调用了正确的工具查找方法？
            4. 是否获得了明确的方法存在性信息？
            5. 如果遇到问题，是否尝试了符号定义查找？
            6. 每个结论都有明确的工具调用依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功找到方法或确认方法不存在时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **FAILED**：如果遇到无法处理的情况""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用方法)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于方法查找的结果总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)容器类型分析 2)链式调用处理(如果适用) 3)工具调用过程 4)方法查找结果 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "container_type": "class|module|package",
                    "container_identifier": "类名/模块绝对路径/包名",
                    "method_name": "方法名",
                    "method_exists": true|false,
                    "method_location": "方法定义位置（如果找到）",
                    "method_signature": "方法签名（如果找到）"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "get_class_define_path", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取类定义文件路径",
                        "reason": "需要检查类是否为内部类"
                    },
                    { 
                        "ability_name": "check_method_of_class", 
                        "parameters": { "class_name": "类名", "method_name": "方法名" }, 
                        "description": "检查类中是否存在指定方法",
                        "reason": "需要在类中查找方法"
                    },
                    { 
                        "ability_name": "get_method_code_in_container", 
                        "parameters": { "method_name": "方法名", "container_identifier": "容器标识符", "container_type": "class|module|package" }, 
                        "description": "在容器中查找方法",
                        "reason": "需要在模块/包中查找方法"
                    },
                    { 
                        "ability_name": "get_possible_sources_of_key", 
                        "parameters": { "key": "符号名" }, 
                        "description": "获取符号的可能来源",
                        "reason": "需要解析链式调用中的符号来源"
                    },
                    { 
                        "ability_name": "find_last_define_of_symbol", 
                        "parameters": { "symbol": "符号名" }, 
                        "description": "查找符号的最后定义",
                        "reason": "需要查找符号定义作为备选方案"
                    }
                ],
                "error_message": "如果状态为FAILED，详细描述失败原因"
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_method_finder_result  
        self.post_processor = self._post_process_method_finder_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["container_identifier", "container_type", "method_name"]
        return all(param in task.params for param in required_params)
    
    def _validate_method_finder_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["container_type", "container_identifier", "method_name", "method_exists"]
        return all(field in result_data for field in required_fields)

    def _post_process_method_finder_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "FAILED"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, self.thinking_steps, voter_counts=voter_counts, solver=self)
        
        return result
