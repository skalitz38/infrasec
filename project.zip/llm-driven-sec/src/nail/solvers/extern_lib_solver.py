from inspect import cleandoc
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config

class ExternLibSolver(SolverTemplate):

    available_solvers = []
    dependent_solvers = []
    router_description = cleandoc("""\
        **ExternLibSolver** - 外部库调用解析专家
        - **专业领域**: 对于涉及到外部库/标准库/第三方库的调用语句，解析调用语义/调用方法/返回类型
        - **解答疑问**：**任何有关外部库的疑问**；给定一条涉及外部库/标准库的调用语句，其调用语义和返回值类型是什么？
        - **适用场景**: 任何关于外部库、标准库、第三方库的函数调用和信息获取
    """)
    
    def _init_solver(self):
        self.domain = "外部第三方库方法调用解析"
        self.capabilities = "外部库识别、外部库方法调用解析、函数执行API检测、返回值类型确定"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：分析调用语句结构
            **调用语句解析**：
            - **输入分析**：
                - 若调用语句为`obj.method()`的结构
                  - **receiver_expr**：obj（接收者表达式）
                  - **method_name**：method（方法名）
                  - **call_site**：调用位置信息
                  - **显式声明**：在reasoning中明确记录"解析外部库调用语句：obj.method，接收者=obj，方法名=method"
                - 若调用语句为`module.function()`的结构
                  - **module_name**：module（模块名）
                  - **function_name**：function（函数名）
                  - **call_site**：调用位置信息
                  - **显式声明**：在reasoning中明确记录"解析外部库调用语句：module.function，模块=module，函数=function"
                - 若调用语句为`Class()`的结构（实例化）
                  - **class_name**：Class（类名）
                  - **method_name**：__init__（构造方法）
                  - **call_site**：调用位置信息
                  - **显式声明**：在reasoning中明确记录"解析外部库调用语句：Class()，类名=Class，方法名=__init__"
            
            ### 第二步：识别第三方库类型
            **库类型识别逻辑**：
            - **基于调用语句分析**：根据调用语句中的模块名、类名、方法名等特征
            - **常见第三方库识别**：
              - **并发并行库**：threading, asyncio, multiprocessing, concurrent.futures, queue, subprocess
              - **网络库**：requests, urllib, socket, http
              - **数据处理库**：pandas, numpy, json, csv
              - **系统库**：os, sys, pathlib, shutil
              - **其他库**：根据具体特征识别
            - **显式声明**：在reasoning中明确记录"识别第三方库类型：[具体库名]，基于特征：[识别依据]"
            
            ### 第三步：判断是否为函数执行API
            **函数执行API检测逻辑**：
            - **API语义识别**：检查调用是否具有"执行用户指定函数"的语义特征
            - **关键特征识别**：
              - **参数传递函数**：API调用中通过参数传递了函数引用（如func、callback、target等）
              - **执行语义**：API的语义是执行、调用、运行用户提供的函数
              - **常见模式**：
                - threading.Thread(target=func)
                - asyncio.create_task(func())
                - multiprocessing.Process(target=func)
                - concurrent.futures.submit(func)
                - contextvars.Context.run(func)
                - queue.Queue.put(func)
                - subprocess.run(func)
                - 其他具有"执行指定函数"语义的API
            
            **情况A：确认为函数执行API（立即处理）**
            - **决策**：返回COMPLETED状态
            - **结果填充**：
              - container_type: "EXTERNAL"
              - container_identifier: 具体的外部库库名
              - method_name: 具体的外部库API名
              - function_execution: "Yes"
              - semantic: 明确指出这是涉及到函数执行的API，需要解析具体方法调用
            - **显式声明**：在reasoning中明确记录"确认为'函数执行'的API库：[库名]，API名：[API名]，这是涉及到函数执行的API"
            
            **情况B：非函数执行API（继续处理）**
            - **显式声明**：在reasoning中记录"非函数执行API：[库名]，继续分析具体方法调用"
            
            ### 第四步：分析具体方法调用
            **方法调用分析逻辑**：
            - **基于第三方库经验**：根据对第三方库的了解分析具体方法以及方法返回值类型
            - **方法类型识别**：
              - **构造方法**：如果是类实例化，方法名为"__init__"
              - **实例方法**：如果是obj.method()，方法名为method
              - **静态方法**：如果是Class.method()，方法名为method
              - **模块函数**：如果是module.function()，方法名为function
            - **语义分析**：分析这个调用的具体语义和用途
            - **显式声明**：在reasoning中明确记录"分析具体方法调用：方法名=[方法名]，语义=[具体语义]"
            - open方法模式	    返回的文件对象类型
                'r' / 'rt'	    io.TextIOWrapper	
                'rb'	        io.BufferedReader	
                'w' / 'wt'	    io.TextIOWrapper	
                'wb'	        io.BufferedWriter	
                'a'	            io.TextIOWrapper	
                'ab'	        io.BufferedWriter	

            
            ### 第五步：结果自检与输出
            **自检清单**：
            1. 是否正确解析了调用语句结构？
            2. 是否准确识别了第三方库类型？
            3. 是否正确判断了是否为函数执行API？
            4. 如果是函数执行API，是否明确指出这是涉及到函数执行的API？
            5. 如果不是函数执行API，是否基于第三方库经验填充了结果字段？
            6. 是否分析了具体方法调用的语义？
            7. 是否分析了方法的返回值类型？
            8. 每个结论都有明确的识别依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功识别第三方库并完成分析时
            - **FAILED**：当无法识别第三方库或分析失败时""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于第三方库识别和方法调用的外部库解析总结",
                "reasoning": "必须包含：1)调用语句结构解析 2)第三方库类型识别 3)函数执行API检测 4)方法调用分析 5)语义分析",
                "result_data": {
                    "container_type": "EXTERNAL",
                    "container_identifier": "第三方库库名",
                    "method_name": "被调用的方法名",
                    "method_location": "None",
                    "function_execution": "如果该调用涉及函数执行API则为Yes，否则为No",
                    "return_type": "该调用返回值的具体类型",
                    "semantic": "简单解释这个调用的语义。如果是函数执行API则明确指出这是涉及到函数执行的API，需要解析被指定调用的具体方法信息"
                },
                "suggested_abilities": [ { "ability_name": "", "parameters": { }, "description": "" } ],
                "next_problems": { 
                    "description": "外部库调用解析问题", 
                    "metadata": { 
                        "call_statement": "调用语句", 
                        "library_type": "库类型",
                        "analysis_result": "分析结果"
                    }
                }
            }
            ```""")
        
        self.result_validator = self._validate_import_result  
        self.post_processor = self._post_process_import_result  
        self.task_params_validator = self._validate_task_params  
        

    def _validate_import_result(self, result_data: dict) -> bool:
        required_fields = ["container_type", "container_identifier", "method_name",
                           "method_location", "function_execution", "semantic"]
        return all(field in result_data for field in required_fields)

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["source", "type", "path"]
        return all(param in task.params for param in required_params)

    
    def _post_process_import_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "FAILED"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
