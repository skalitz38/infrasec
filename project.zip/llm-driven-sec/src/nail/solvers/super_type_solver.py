
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult, AbilityCall
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class SuperTypeSolver(SolverTemplate):

    available_solvers = ["MethodCallSolver", "ImportSolver", "ParameterTypeSolver", "MethodFinderSolver"]
    router_description = cleandoc("""\
        **SuperTypeSolver** - 超类类型判断专家
        - **专业领域**: 超类类型判断
        - **核心能力**: 分析类定义、超类继承关系
        - **适用场景**: 确定一个类的超类类型
        - **协作关系**: 需要类定义信息""")
    
    def _init_solver(self):
        self.domain = "判断super()调用中，实际上调用的方法所属的类名"
        self.capabilities = "给定一条调用语句含super的call_stmt：super().func()，判断这条调用语句中调用的func()方法的源代码在哪个类中"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：获取当前类的父类
            **强制工具调用**：
            - **必须执行**：调用get_parent_of_class获取当前类的父类
            - **验证要求**：必须获得明确的父类信息，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用get_parent_of_class，获得父类信息：[具体父类信息]"
            
            ### 第二步：检查父类方法定义
            **强制工具调用**：
            - **必须执行**：调用check_method_of_class查看父类是否定义了该方法
            - **验证要求**：必须获得明确的方法定义信息
            - **显式声明**：在reasoning中明确记录"已调用check_method_of_class，获得方法定义信息：[具体方法信息]"
            
            ### 第三步：判断方法定义状态
            **方法定义判断逻辑**：
            - **找到方法定义**：如果在类中找到了该方法的定义，且不是抽象方法
              - **决策**：直接返回该类名
              - **显式声明**：在reasoning中明确记录"找到方法定义：[具体方法定义]，返回类名：[类名]"
            
            - **未找到方法定义**：如果父类没有该方法的定义
              - **决策**：继续向上查找，重复第一步和第二步
              - **显式声明**：在reasoning中记录"父类未找到方法定义，继续向上查找"
            
            ### 第四步：处理继承链查找
            **继承链查找逻辑**：
            - **重复查找**：重复步骤1-3，直到找到该方法的定义或到达object类
            - **到达object类**：如果到达object类仍未找到该方法的定义，返回FAILED
              - **问题描述要求**：详细描述当前遇到的问题场景和困难
              - **必须包含**：
                - 当前查找的方法名是什么
                - 已遍历的继承链信息
                - 为什么无法找到方法定义
                - 缺少什么关键信息
                - 这个问题的性质（是继承链分析问题、方法查找问题、还是其他问题）
              - **显式声明**：在reasoning中详细记录"到达object类仍未找到方法定义，问题描述：[详细问题场景]"
            
            ### 第五步：结果自检与输出
            **自检清单**：
            1. 是否调用了get_parent_of_class？获得了什么父类信息？
            2. 是否调用了check_method_of_class？获得了什么方法定义信息？
            3. 是否进行了方法定义判断？判断结果是什么？
            4. 是否完成了完整的继承链查找？
            5. 如果遇到问题，是否详尽地描述了问题场景？
            6. 每个结论都有明确的工具调用依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功找到方法定义且信息完整时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **NEEDS_FOLLOWUP**：当遇到无法解决的问题时，必须详细描述问题场景
            - **FAILED**：当遇到无法处理的情况时，必须详细描述问题场景""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于继承链分析的super()调用解析总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)get_parent_of_class调用结果 2)check_method_of_class调用结果 3)方法定义判断过程 4)继承链查找过程 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "class_name": "该类的名字"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "get_parent_of_class", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取类的父类信息",
                        "reason": "需要获取父类信息进行继承链分析"
                    },
                    { 
                        "ability_name": "check_method_of_class", 
                        "parameters": { "class_name": "类名", "method_name": "方法名" }, 
                        "description": "检查类中是否定义了方法",
                        "reason": "需要检查方法定义进行super()调用解析"
                    }
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_super_result  
        self.post_processor = self._post_process_super_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["class_name", "method_name", "current_file"]
        return all(param in task.params for param in required_params)
    
    def _validate_super_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["class_name"]
        return all(field in result_data for field in required_fields)
    
    def _post_process_super_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
