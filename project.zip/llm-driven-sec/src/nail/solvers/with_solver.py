
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class WithSolver(SolverTemplate):

    available_solvers = ["CodeComprehensionSolver"]
    router_description = cleandoc("""\
        **WithSolver** - with语句解析专家
        - **专业领域**: 解析with子句、上下文管理器、__enter__方法返回值
        - **核心能力**: 判断with子句中symbol的类型，解答"被with定义的symbol的具体类型？"
        - **适用场景**: with xxx as f，解析其中f的具体类型""")
    
    def _init_solver(self):
        self.domain = "处理with子句中符号类型"
        self.capabilities = cleandoc("""\
            给定一个with子句，找到with子句中指定symbol的具体类型""")
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            检查上下文中是否已经含有with子句的源代码，如果有，则直接跳到第二步
            ### 第一步：获取with子句源代码
            **强制工具调用**：
            - **必须执行**：如果当前上下文中没有with子句的源代码，则调用find_last_define_of_symbol(symbol_name)获取with子句的源代码
            - **验证要求**：必须获得明确的with子句源代码，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用find_last_define_of_symbol，获得with子句源代码：[具体源代码]"
            
            ### 第二步：分析指定调用点
            **调用点分析逻辑**：
            - **方法名识别**：根据with子句的源代码，分析指定调用点调用的具体方法名
            - **调用上下文**：分析调用点的上下文信息
            - **显式声明**：在reasoning中明确记录"分析调用点：[具体调用点信息]，方法名：[方法名]"
            
            ### 第三步：判断方法归属
            **方法归属判断**：
            - **归属类型分析**：根据自身知识，判断该方法是属于一个类，还是一个模块（文件），还是一个包
            - **容器识别**：识别方法所属的容器类型和标识符
            - **显式声明**：在reasoning中明确记录"判断方法归属：[具体归属信息]"
            
            ### 第四步：结果自检与输出
            **自检清单**：
            1. 是否调用了find_last_define_of_symbol获得了with子句源代码？
            2. 是否分析了指定调用点？调用点信息是什么？
            3. 是否判断了方法归属？归属结果是什么？
            4. 推断依据是否充分？
            5. 每个结论都有明确的依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功识别方法归属且信息完整时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **NEEDS_FOLLOWUP**：当遇到无法解决的问题时，必须详细描述问题场景
            - **FAILED**：当遇到无法处理的情况时，必须详细描述问题场景""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于with子句分析的调用方法识别总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)find_last_define_of_symbol调用结果 2)调用点分析过程 3)方法归属判断过程 4)推断依据 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "method_name": "具体调用的方法名",
                    "container_type": "如果该方法属于一个类，则为class|如果该方法属于一个模块则为"module"|如果该方法属于一个包则为"package",
                    "container_identifier": "类名|模块名|包名"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "find_last_define_of_symbol", 
                        "parameters": { }, 
                        "description": "获取with子句源代码",
                        "reason": "需要获取with子句源代码进行分析"
                    }
                ],
                "next_problems": { 
                    "kind": "根据问题性质由planner判断", 
                    "metadata": { 
                        "problem_scenario": "详细的问题场景描述",
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_self_cls_result  
        self.post_processor = self._post_process_self_cls_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["field_name", "class_name", "current_file"]
        return all(param in task.params for param in required_params)
    
    def _validate_self_cls_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["type"]
        return all(field in result_data for field in required_fields)
    
    def _post_process_self_cls_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
