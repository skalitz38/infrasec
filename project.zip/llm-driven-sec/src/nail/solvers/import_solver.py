
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class ImportSolver(SolverTemplate):

    available_solvers = ["ExternLibSolver"]
    dependent_solvers = []
    router_description = cleandoc("""\
        **ImportSolver** - 导入语句解析专家
        - **专业领域**: 解析来自外部导入的符号类型、import语句解析和符号来源判断；
        - **解答问题**: 给定一个符号，它是否来自于import导入？是来自内部/外部？定义所在的source文件是什么？; 或给定一条import语句，它的来源是什么？
        - **适用场景**: 包含"import"、"from xxx import"、symbol来自import语句
    """)
    
    def _init_solver(self):
        self.domain = "判断import来源、解析符号类型、匹配source文件"
        self.capabilities = cleandoc("""\
            给定一条import a或者from xxx import a语句的源代码，判断：
            - 这条语句是在导入项目内部代码还是在导入第三方库
            - 导入的symbol a，是一个文件还是一个类/方法，还是一个包""")

        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            首先查看任务上下文中是否已经存在import语句的源代码，如果存在，直接跳转到第二步
            
            ### 第一步：获取import语句源代码
            **强制工具调用**：
            - **必须执行**：调用find_last_define_of_symbol(symbol_name)获取import语句源代码
            - **调用工具要求**：在使用find_last_define_of_symbol这个工具时，symbol_name参数应该是一个简单的symbol，对于链式调用a.b.c.d()，你应该分别寻找a, b, c, d的last_define
            - **验证要求**：必须调用该工具并指出该工具的调用结果，不允许跳过调用
            - **显式声明**：在reasoning中明确记录"已调用find_last_define_of_symbol，获得import语句源代码：[具体import语句]"
            
            ### 第二步：获取项目结构信息
            **强制工具调用**：
            - **必须执行**：调用analyze_project_context工具获取项目结构信息
            - **验证要求**：必须获得明确的项目结构信息
            - **显式声明**：在reasoning中明确记录"已调用analyze_project_context，获得项目结构信息：[具体项目结构]"
            
            ### 第三步：获取可能的来源sources
            **强制工具调用**：
            - **必须执行**：调用get_possible_sources_of_key，查看所有可能的来源sources
            - **验证要求**：必须获得明确的可能来源列表
            - **显式声明**：在reasoning中明确记录"已调用get_possible_sources_of_key，获得可能来源：[具体来源列表]"
            
            ### 第四步：匹配项目内部来源
            **内部来源匹配逻辑**：
            - **匹配过程**：在可能的sources中查找与import语句匹配的项目内部来源
            - **匹配标准**：
              - 文件路径匹配
              - 模块名匹配
              - 包结构匹配
            - **匹配结果处理**：
              - **找到匹配**：如果存在source能够匹配上这条语句
                - **决策**：返回source为INNER，type根据匹配结果确定
                - **显式声明**：在reasoning中明确记录"找到项目内部匹配：[具体匹配信息]"
              - **未找到匹配**：如果没有匹配到任何source
                - **显式声明**：在reasoning中记录"未找到项目内部匹配，继续判断是否为外部库"
            
            ### 第五步：判断外部库来源
            **外部库判断逻辑**：
            - **判断标准(同时满足)**：
              - **无项目内部的可能来源**：如果找到项目内可能来源，或import语句的写法不可能指向项目内可能来源
              - **import语句涉及到你熟悉的外部库**：审计import语句，通过你的经验判断这是否导入的是你知道的外部库
            - **问题描述要求**：详细描述当前遇到的问题场景和困难
                - **必须包含**：
                  - 当前import语句的具体内容
                  - 已尝试的匹配过程
                  - 为什么匹配失败
                - **显式声明**：在reasoning中详细记录"无法确定import来源，怀疑是外部库，需要找其他solver解析外部库.问题描述：[详细问题场景]"
            
            ### 第六步：结果自检与输出
            **自检清单**：
            1. 是否调用了工具，以及获得了什么结果？**若没调用请必须调用**
                - 是否调用了find_last_define_of_symbol？获得了什么import语句？
                - 是否调用了analyze_project_context？获得了什么项目结构信息？
                - 是否调用了get_possible_sources_of_key？获得了什么可能来源？
            2. 如果找到了可能的项目内部来源，是否能和import语句匹配上？
            3. 如果判断了是来自项目外部库的导入，是否寻求帮助？
            4. 如果遇到问题，是否详尽地描述了问题场景？
            5. 每个结论都有明确的信息依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功确定import来源(来自内部哪个绝对路径/来自外部)且信息完整(什么类型)
            - **NEEDS_ABILITY**：调用工具获取信息
            - **NEEDS_FOLLOWUP**：详细描述问题场景
            - **FAILED**：当无法在内部解析出import来源，并且也不属于你已知的外部库时""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于import语句解析和来源匹配的导入解析总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)find_last_define_of_symbol调用结果 2)analyze_project_context调用结果 3)get_possible_sources_of_key调用结果 4)项目内部来源匹配过程 5)外部库判断过程 6)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "source": "INNER|EXTERNAL|UNKNOWN",
                    "type": "FILE|CLASS|METHOD|PACKAGE|UNKNOWN",
                    "path": "/abs/or/None"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "find_last_define_of_symbol", 
                        "parameters": { "symbol_name": "符号名" }, 
                        "description": "查找import语句源代码",
                        "reason": "需要获取import语句源代码进行分析"
                    },
                    { 
                        "ability_name": "analyze_project_context", 
                        "parameters": { }, 
                        "description": "分析项目结构信息",
                        "reason": "需要获取项目结构信息进行匹配"
                    },
                    { 
                        "ability_name": "get_possible_sources_of_key", 
                        "parameters": { "key": "符号名" }, 
                        "description": "获取可能的来源sources",
                        "reason": "需要获取所有可能的来源进行匹配"
                    }
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.result_validator = self._validate_import_result  
        self.post_processor = self._post_process_import_result  
        self.task_params_validator = self._validate_task_params  
        

    def _validate_import_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["source", "type", "path"]
        return all(field in result_data for field in required_fields)

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["import_stmt", "symbol_name"]
        return all(param in task.params for param in required_params)

    def _post_process_import_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
