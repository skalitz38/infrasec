
from typing import Dict, Any, List
from abc import abstractmethod
from nail.common_structure import Task, SolverResult
from nail.config.config import SOLVER_MAX_TIMES
from nail.utils.simple_llm import SimpleLLM
from nail.solvers.abilities.abilities_manager import AbilityManager
from lian.core.resolver import Resolver
from lian.util.loader import Loader
from nail.utils.workflow_log import get_workspace_logger

logger = get_workspace_logger()

class SolverTemplate:

    router_description: str = ""
    
    def __init__(self, lian=None):
        self.solver_name = self.__class__.__name__
        self.llm = SimpleLLM(llm_character=self.solver_name)
        self.lian = lian
        if self.lian:
            self.loader:Loader = self.lian.loader
            self.resolver:Resolver = self.lian.resolver
        self.ability_manager = AbilityManager(lian=lian)

        self.domain = "通用问题"  
        self.capabilities = "通用问题解决"  
        self.task_params_validator = None 
        self.thinking_steps = "## 思考步骤\n1. 分析问题\n2. 制定解决方案"  
        self.result_validator = None  
        self.post_processor = None  
        
        self._init_solver()
        
        self.available_abilities = self._get_available_abilities()
    
    @abstractmethod
    def _init_solver(self):

        pass
    
    def _get_available_abilities(self) -> list:
        return self.ability_manager.get_abilities_for_solver(self.solver_name)

    def generate_system_prompt(self, task: Task) -> str:
        role = f"你是{self.solver_name}，负责解决<{self.domain}>类型的问题。"
        capabilities = (
            f"## 能力与边界\n"
            f"- 你的主要职责是：{self.capabilities}\n"
            f"- 如果你发现问题类型不在你的能力以内，直接返回任务失败，并解释原因。\n"
            f"- **可用工具**：\n{self._format_available_abilities()}\n"
            f"- 一旦你发现缺失信息，请立即调用合适的工具。\n"
        )
        thought = (
            "## 决策和要求\n"
            "- 先粗判是否能直接完成；若信息不足，明确需要的工具与目的，并**详细描述当前碰到的问题场景**。\n"
            "- 若更适合其他Solver，明确建议转交对象与理由。\n"
            "- 输出必须与'输出格式'严格一致，仅输出JSON，无多余文本。\n"
            "- **请先查看'## 当前任务执行历史'中的子任务结果**，若子任务结果已经解决了当前任务的目标，返回COMPLETED，并使用子任务结果。\n"
            "- **使用已有信息时，务必引用任务执行历史或工具调用结果的原文，提供引用原文**(根据第#条任务执行历史/工具调用结果的[哪句话]，可知[具体信息])"
        )
        return "\n\n".join([role, capabilities, thought, self.thinking_steps, self.output_format, "注意：如果要调用工具，返回的任务状态应该为NEEDS_ABILITY"])

    def generate_user_prompt(self, task: Task) -> str:
        basic_task_info = self._build_basic_task_info(task)
        parts = [basic_task_info]

        supervisor_feedback = self._build_supervisor_feedback(task)
        if supervisor_feedback:
            parts.append(supervisor_feedback)

        task_execution_history = self._build_current_task_history(task)
        parts.append(task_execution_history)

        dispatch_history = self._build_dispatch_history(task)
        parts.append(dispatch_history)

        ability_history = self._build_ability_call_history(task)
        parts.append(ability_history)

        return "\n\n".join(parts)

    def _format_available_abilities(self) -> str:
        if not self.available_abilities:
            return "无"
        
        ability_descriptions = []
        for ability in self.available_abilities:
            ability_descriptions.append(f"{ability['name']}: {ability['description']} # 工具所需参数:{ability['parameters']}")
        
        return '\n'.join([f"    - {desc}" for desc in ability_descriptions])

    def _get_solver_info(self, solver_name: str) -> str:
        try:
            solver_class = self._get_solver_class(solver_name)
            if solver_class:
                return solver_class.router_description
            else:
                return f"**{solver_name}**\n- 处理范围：未知\n- 主要能力：未知"
        except Exception as e:
            return f"**{solver_name}**\n- 处理范围：未知\n- 主要能力：未知"
    
    def _get_solver_class(self, solver_name: str):
        try:
            if solver_name == "ImportSolver":
                from nail.solvers.import_solver import ImportSolver
                return ImportSolver
            elif solver_name == "ParameterTypeSolver":
                from nail.solvers.parameter_type_solver import ParameterTypeSolver
                return ParameterTypeSolver
            elif solver_name == "MethodCallSolver":
                from nail.solvers.method_call_solver import MethodCallSolver
                return MethodCallSolver
            elif solver_name == "SymbolTypeSolver":
                from nail.solvers.symbol_type_solver import SymbolTypeSolver
                return SymbolTypeSolver
            elif solver_name == "ExternLibSolver":
                return None
            else:
                return None
        except ImportError:
            return None

    def _build_basic_task_info(self, task: Task) -> str:
        basic_task_info = ["## 任务信息"]
        
        if task.name:
            basic_task_info.append(f"- 任务名称：{task.name}")
        if task.description:
            basic_task_info.append(f"- 任务描述：{task.description}")
        if task.params:
            basic_task_info.append(f"- 任务参数：{task.params}")
        problem_kind = getattr(task.problem, 'kind', None) if hasattr(task, 'problem') and task.problem else None
        if problem_kind and problem_kind != 'Unknown':
            basic_task_info.append(f"- 问题类型：{problem_kind}")
        problem_metadata = getattr(task.problem, 'metadata', None) if hasattr(task, 'problem') and task.problem else None
        if problem_metadata:
            basic_task_info.append(f"- 问题元数据：{problem_metadata}")
        return '\n'.join(basic_task_info)
    
    def _build_current_task_history(self, task: Task) -> str:


        history_content = task.format_execution_history()
        if not history_content.strip():
            history_content = "无子任务历史"

        return (
            "\n\n## 当前任务执行历史\n"
            "-这段内容记录了当前任务在执行过程中产生的所有子任务和中间结果\n"
            "-包含了已完成的子任务、失败的任务、以及它们的具体执行结果和输出\n"
            "-这些信息可以帮助你了解任务的整体进展和当前状态\n"
            "-请结合这些信息，判断当前任务的下个步骤。\n"
            f"{history_content}\n"
        )
    
    def _build_supervisor_feedback(self, task: Task) -> str:

        if not hasattr(task, 'supervisor_feedback') or not task.supervisor_feedback:
            return ""
        
        feedback = task.supervisor_feedback
        feedback_section = "\n\n## 监督反馈信息\n"
        feedback_section += "- 这是监督模型对上一次solver处理的反馈，请仔细阅读并据此调整本次处理\n"
        
        if feedback.get('has_hallucination'):
            feedback_section += "- **幻觉检测**：上一次处理存在幻觉，请确保所有推理都有事实依据\n"
        
        if not feedback.get('is_consistent', True):
            feedback_section += "- **一致性问题**：上一次处理存在不一致，请确保推理逻辑前后一致\n"
        
        if feedback.get('feedback'):
            feedback_section += f"- **具体反馈**：{feedback['feedback']}\n"
        
        if feedback.get('supervision_process'):
            feedback_section += f"- **监督过程**：{feedback['supervision_process']}\n"
        
        feedback_section += "- 请基于以上反馈，调整本次处理策略，避免重复相同问题\n"
        
        return feedback_section
    
    def _build_ability_call_history(self, task: Task) -> str:

        if not (hasattr(task, 'ability_call_history') and task.ability_call_history):
            return "\n\n## 工具调用历史\n  -没有调用过工具"

        history_lines = ["\n\n## 工具调用历史"]
        history_lines.append("- 这段内容记录了当前任务在执行过程中产生的所有工具调用记录")
        history_lines.append("- **引用工具结果时，必须给出该结果对应的工具调用历史编号**")

        for i, call_record in enumerate(task.ability_call_history, 1):
            solver_name = call_record.get('solver_name', 'Unknown')
            ability_name = call_record.get('ability_name', 'Unknown')
            ability_result = call_record.get('ability_result', {})
            parameters = ability_result.get("parameters",{})
            reason = call_record.get('reason', '')
            description = call_record.get('description', '')
            call_sequence = call_record.get('call_sequence', i)

            history_lines.append(f"### 工具调用 #{call_sequence}")
            history_lines.append(f"- 工具：{ability_name}")
            if description:
                history_lines.append(f"  调用描述：{description}")
            if reason:
                history_lines.append(f"  调用原因：{reason}")
            if parameters:
                history_lines.append(f"  调用参数：{parameters}")

            if isinstance(ability_result, dict):
                if ability_result.get('success', False):
                    result_info = ability_result.get('result', '无结果信息')
                    history_lines.append(f"  结果：{result_info}")
                else:
                    error_info = ability_result.get('error', '未知错误')
                    history_lines.append(f"  结果：调用失败 - {error_info}")
            else:
                history_lines.append(f"  结果：{ability_result}")

            history_lines.append("")

        return '\n'.join(history_lines)

    def _build_dispatch_history(self, task: Task) -> str:

        dispatch_history_content = task.format_dispatch_history()
        if not dispatch_history_content.strip() or dispatch_history_content.strip() == "无":
            return "\n\n## 分发历史\n  - 无分发历史"

        return (
            "\n\n## 分发历史\n"
            "- 这段内容记录了当前任务的分发历史，包括之前分发给哪些Solver以及结果\n"
            "- **重要**：如果发现同一个语义的任务多次分发到同一个Solver却无法解决，说明可能存在无限递归\n"
            "- **判断标准**：如果对于同一个语义的任务，多次分发到自己却无法解决，陷入无限递归，则应该返回FAILED\n"
            "- **避免重复**：请根据分发历史判断是否已经尝试过类似的方法，避免重复处理\n"
            f"{dispatch_history_content}\n"
        )

    def solve(self, task: Task) -> SolverResult:

        try:
            if self.task_params_validator and not self.task_params_validator(task):
                print(f"[{self.solver_name}] 任务参数不完整")

            iteration = 0
            decision = {}

            while iteration < SOLVER_MAX_TIMES:
                system_prompt = self.generate_system_prompt(task)
                user_prompt = self.generate_user_prompt(task)
                llm_response = self.llm.chat_structured(system_prompt=system_prompt, user_prompt=user_prompt)

                decision = self._parse_llm_response(llm_response)

                if decision.get("status") == "NEEDS_ABILITY":
                    suggested_abilities = decision.get("suggested_abilities", [])

                    if not isinstance(suggested_abilities, list):
                        if suggested_abilities:
                            suggested_abilities = [suggested_abilities]
                        else:
                            suggested_abilities = []

                    valid_abilities = []
                    for ability in suggested_abilities:
                        if isinstance(ability, dict) and ability.get("ability_name"):
                            valid_abilities.append(ability)

                    if valid_abilities:
                        ability_results = self._execute_abilities(valid_abilities, task)
                        iteration += 1
                        continue
                    else:
                        print(f"警告: 状态为NEEDS_ABILITY但没有有效的suggested_abilities: {suggested_abilities}")
                        break
                else:
                    break
            
            if iteration >= SOLVER_MAX_TIMES:
                from nail.utils.workflow_log import get_workflow_logger
                logger.log_solver_iteration_limit(
                    solver_name=self.solver_name,
                    task_desc=task.description,
                    max_iterations=SOLVER_MAX_TIMES,
                    final_status=decision.get("status", "UNKNOWN")
                )
            
            result = self._build_solver_result(decision, task)

            if self.post_processor:
                result = self.post_processor(result, task)
            
            result = self.result_processing(result)

            logger.log_solver_result(
                solver_name=self.solver_name,
                status=result.status,
                result_summary=result.summary,
                reasoning=result.reasoning
            )

            return result
            
        except Exception as e:
            print(f"{self.solver_name}执行过程报错：{e}")
            result = SolverResult(
                status="FAILED",
                error_message=f"Solver执行失败: {str(e)}",
                confidence=0.0,
                reasoning=f"执行过程中发生异常: {str(e)}"
            )
            
            logger.log_solver_result(
                solver_name=self.solver_name,
                status=result.status,
                result_summary=result.error_message,
                reasoning=result.reasoning
            )
            
            return result
    
    def _parse_llm_response(self, response: str) -> dict:

        try:
            from nail.utils.format_llm_out import get_dict_from_reply
            data = get_dict_from_reply(response)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
        return {
            "status": "FAILED",
            "error_message": "无法解析LLM响应",
            "confidence": 0.0,
            "reasoning": "LLM响应格式错误"
        }

    
    def _execute_abilities(self, suggested_abilities: List[Dict[str, Any]], task: Task) -> List[Dict[str, Any]]:
        ability_results = []
        
        for ability_info in suggested_abilities:
            ability_name = ability_info.get("ability_name", "")
            parameters_from_llm = ability_info.get("parameters", {})
            description = ability_info.get("description", "")
            reason = ability_info.get("reason", "")
            
            result = self.ability_manager.call_ability(ability_name, parameters_from_llm, task)
            
            task.add_ability_call_history(
                solver_name=self.solver_name,
                ability_name=ability_name,
                ability_result=result,
                description=description,
                reason=reason
            )

            logger.log_ability_call(
                solver_name=self.solver_name,
                ability_name=ability_name,
                parameters=parameters_from_llm,
                result=result,
            )
            
            ability_results.append({
                "ability_name": ability_name,
                "parameters": parameters_from_llm,
                "description": description,
                "result": result
            })
        
        return ability_results

    def _build_solver_result(self, decision: dict, task: Task) -> SolverResult:
        status = decision.get("status", "FAILED")
        result_data = decision.get("result_data", {})
        confidence = decision.get("confidence", 0.0)
        reasoning = decision.get("reasoning", "")
        summary = decision.get("summary", "")
        error_message = decision.get("error_message", "")

        follow_up_tasks = decision.get("next_problems", decision.get("follow_up_tasks", []))
        
        return SolverResult(
            status=status,
            result_data=result_data,
            confidence=confidence,
            reasoning=reasoning,
            summary=summary,
            follow_up_tasks=follow_up_tasks,
            error_message=error_message
        )
    
    def result_processing(self, result: SolverResult) -> SolverResult:

        if self.result_validator and result.status == "COMPLETED":
            if not self.result_validator(result.result_data):
                result.status = "NEEDS_ABILITY"
                result.confidence = max(0.0, result.confidence * 0.6)
                result.reasoning = "result_processing方法————检测到结果字段缺失，需要更多信息"
        
        return result
