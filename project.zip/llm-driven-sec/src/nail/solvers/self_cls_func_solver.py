
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class SelfClsFuncSolver(SolverTemplate):

    available_solvers = ["HierarchySolver", "SelfClsPropTypeSolver", "SymbolTypeSolver", "SuperTypeSolver", "MethodCallSolver"]
    router_description = cleandoc("""\
        **SelfClsFuncSolver** - 专注于解析self.method()与cls.method()/cls()形式的直接成员方法调用。
        - **重要区分**：当且仅当**self/cls.func()**形式的调用属于该Solver，其余形式(尤其是self.a.b()这种先属性访问的链式调用形式)都属于MethodCallSolver！！
        - **专业领域**: 解析self.func()/cls.func()类型的方法调用的具体方法
        - **解答问题**: 给定一条self.func()/cls.func()类型的方法调用，它调用的是哪个方法(具体定义是什么)？判断一个类中有没有某个方法？
        - **适用场景**: self.func()/cls.func()的调用形式中需要找到func方法的源代码以及位置
    """)
    
    def _init_solver(self):
        self.domain = "self.func()/cls.func()方法调用解析与方法定义查找"
        self.capabilities = "实例方法定义查找、类方法定位查找、继承链遍历、抽象方法识别"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            ### 开始前检查
            **任务类型判断**: 首先判断任务是否**严格属于**self.func()/cls.func()形式的方法解析。如果不是，直接返回任务失败，并描述任务失败的原因。
            - self/cls.prop.func()这种先属性访问后链式调用的形式不是你的处理范畴。
            
            ### 第一步：检查任务执行历史中的其他Solver结果
            **结果整合**：
            - **其他Solver结果检查**：如果任务执行历史中已有其他Solver的处理结果
            - **特殊**：如果HierarchySolver已经返回了所有的可能的子类，直接返回结果，此时method_location为None, container_identifier为字符串列表，列表元素为HierarchySolver结果的target_classes中的子类名
              - **决策**：基于其他Solver结果继续处理，自行决定跳到第几步
              - **显式声明**：在reasoning中记录"基于其他Solver结果继续处理：[具体结果]"
            
            ### 第二步：检查当前类中的方法定义
            **强制工具调用**：
            - **必须执行**：调用get_class_source_code(class_name)检查当前类是否定义了名为func的**方法**或**属性**！
            - **验证要求**：必须获得明确的方法/属性存在性信息，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用get_class_source_code，检查当前类[class_name]中是否存在方法/属性[method_name]，结果：[具体结果]"
            
            ### 第三步：分析工具调用结果
            **属性定义结果分析**：
            1.方法确实存在名为func的属性定义：
              - **决策**：返回NEEDS_FOLLOWUP，确定self.func属性的类型
              - **显式声明**：在reasoning中明确记录"当前类[class_name]中定义了属性[method_name],需要确定self.method_name的类型是否为函数指针"
            
            **方法定义结果分析**：
            2.方法在当前类中存在定义且非抽象方法：
              - **决策**：直接返回当前类作为方法定义类
              - **显式声明**：在reasoning中明确记录"当前类[class_name]中定义了方法[method_name]，任务完成"
            
            3. 方法在当前类中存在定义但为抽象方法
              - **问题描述要求**：详细描述当前遇到的问题场景和困难
              - **必须包含**：
                - 当前类名和抽象方法名
                - 抽象方法的特征（@abstractmethod装饰器等）
                - 这个问题的性质（需要子类类型解析）
              - **决策**：返回NEEDS_FOLLOWUP，详细描述问题场景
              - **显式声明**：在reasoning中详细记录"当前类中方法为抽象方法，需要查找该类的所有子类类型，问题描述：[详细问题场景]"
            
            4. 方法在当前类中不存在方法定义或者属性定义
              - **决策**：该方法只可能来自父类，进行第四步
              - **显式声明**：在reasoning中记录"当前类中未找到方法定义，开始遍历父类继承链"
            
            ### 第四步：遍历父类继承链查找方法定义
            **继承链遍历逻辑**：
            - **强制工具调用**：调用get_parent_of_class(class_name)获取当前类的直接父类
            - **验证要求**：必须获得明确的直接父类信息
            - **显式声明**：在reasoning中明确记录"已调用get_parent_of_class，获得直接父类信息：[具体父类信息]"
            
            **父类方法检查**：
            - **遍历父类**：对每个直接父类调用check_method_of_class(parent_class_name, method_name)
            - **检查顺序**：按照继承链顺序，从直接父类开始向上查找
            - **显式声明**：在reasoning中记录每个父类的检查结果
            
            **情况A：找到方法定义（立即处理）**
            - **方法存在且非抽象**：如果父类中找到了非抽象的方法定义
              - **决策**：返回该父类作为方法定义类
              - **显式声明**：在reasoning中明确记录"在父类[parent_class_name]中找到方法[method_name]定义"
            
            **情况B：未找到方法定义（继续查找）**
            - **继续遍历**：如果当前所有的直接父类都没有找到方法定义，重复第四步，获取父类的父类
            - **显式声明**：在reasoning中记录"父类[parent_class_name]中未找到方法，继续查找父类的父类"
            - **继续调用get_parent_of_class工具时，如果你发现父类中含有泛型，应该传递的class_name参数为父类类名且不带泛型
            - 如发现父类名为A[B]，继续查找父类的父类时，应该传递get_parent_of_class(class_name=A)
            - **再次强调**：如果没有在当前类的所有直接父类中找到该方法定义，应该重复第四步，遍历查找父类的父类！
            
            ### 第五步：获取方法定义类的文件路径
            **文件路径获取**：
            - **强制工具调用**：调用get_class_define_path(class_name)获取方法定义类的文件路径
            - **验证要求**：必须获得明确的文件路径信息
            - **显式声明**：在reasoning中明确记录"已调用get_class_define_path，获得类[class_name]定义文件路径：[具体路径]"
            
            ### 第六步：结果自检与输出
            **自检清单**：
            1. 是否确认当前调用属于你的职责(self/cls.func()形式，而非任何其他形式如self.a.b())。若形式不符，返回FAILED
            2. 是否查看了当前任务执行历史中其他Solver的结果？
            3. 是否调用了check_method_of_class检查当前类中对于func方法的定义？
            4. 如果当前类没有方法，是否调用了get_parent_of_class？获得了什么父类信息？
            5. 是否遍历了所有父类并调用了check_method_of_class？每个父类的检查结果是什么？
            6. 在哪个类中找到了方法定义？是抽象方法还是具体实现？
            7. 如果找到抽象方法，是否详细描述了问题场景？
            8. 是否调用了get_class_define_path获取文件路径？
            9. 每个结论都有明确的工具调用依据吗？
            
            **输出条件**：
            - **COMPLETED**：只有当找到明确的方法定义且信息完整时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **NEEDS_FOLLOWUP**：如果发现自身无法解决，必须详细描述问题场景
            - **FAILED**：如果遇到无法处理的情况""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于方法定义查找和继承链遍历的方法调用解析总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)check_method_of_class调用结果 2)get_parent_of_class调用结果 3)父类遍历过程 4)方法定义查找结果 5)问题场景详细描述(如果遇到抽象方法)",
                "result_data": {
                    "container_type": "class",
                    "container_identifier": "具体定义了func方法的类的类名",
                    "method_name": "func方法名",
                    "method_location": "方法定义所在文件路径",
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "check_method_of_class", 
                        "parameters": { "class_name": "类名", "method_name": "方法名" }, 
                        "description": "检查类中是否存在指定方法",
                        "reason": "需要检查类中是否存在方法定义"
                    },
                    { 
                        "ability_name": "get_parent_of_class", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取类的父类信息",
                        "reason": "需要获取父类信息进行继承链遍历"
                    },
                    { 
                        "ability_name": "get_class_define_path", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取类定义文件路径",
                        "reason": "需要获取方法定义类的文件路径"
                    }
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "problem_scenario": "详细的问题场景描述",
                        "current_class": "当前类名",
                        "method_name": "方法名",
                        "abstract_method_info": "抽象方法信息",
                        "inheritance_chain": "继承链信息",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_self_cls_result  
        self.post_processor = self._post_process_self_cls_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["call_site_code", "callee_name", "class_name", "file_path"]
        return all(param in task.params for param in required_params)
    
    def _validate_self_cls_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["container_type", "container_identifier", "method_name", "method_location"]
        return all(field in result_data for field in required_fields)

    def _post_process_self_cls_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, self.thinking_steps, voter_counts=voter_counts, solver=self)
        
        return result
