



from typing import Dict, Any, List, Optional

from nail.common_structure import Task, Problem
from nail.solvers.abilities.abilities_catalog import ABILITIES_CATALOG, SOLVER_TO_ABILITIES
from nail.solvers.abilities.abilities_implementations import ABILITY_IMPLEMENTATIONS
from lian.core.resolver import Resolver
from lian.util.loader import Loader


class AbilityManager:
    
    def __init__(self, lian=None):
        self.lian = lian
        if self.lian:
            self.loader:Loader = self.lian.loader
            self.resolver:Resolver = self.lian.resolver
        self._abilities = {}
        self._initialize_abilities()
    
    def _initialize_abilities(self):
        for ability_name, ability_info in ABILITIES_CATALOG.items():
            if ability_name in ABILITY_IMPLEMENTATIONS:
                self._abilities[ability_name] = {
                    'info': ability_info,
                    'implementation': ABILITY_IMPLEMENTATIONS[ability_name]
                }
    
    def get_abilities_for_solver(self, solver_name: str) -> List[Dict[str, Any]]:
        available_abilities = SOLVER_TO_ABILITIES.get(solver_name, [])
        abilities_desc = []
        
        for ability_name in available_abilities:
            if ability_name in self._abilities:
                ability_info = self._abilities[ability_name]['info']
                abilities_desc.append({
                    'name': ability_name,
                    'description': ability_info['description'],
                    'parameters': ability_info['parameters']
                })
        
        return abilities_desc
    
    def call_ability(self, ability_name: str, parameters_from_llm: Dict[str, Any], task: Task) -> Any:
        if ability_name not in self._abilities:
            return {"error": f"工具 {ability_name} 不存在"}
        
        try:
            ability_implementation = self._abilities[ability_name]['implementation']
            
            enriched_params = self._build_enriched_params(task, parameters_from_llm)
            
            result = ability_implementation(enriched_params)
            return {
                "success": True,
                "result": result,
                "ability_name": ability_name,
                "parameters": parameters_from_llm
            }
        except Exception as e:
            return {
                "success": False,
                "error": f"工具调用失败: {str(e)}",
                "ability_name": ability_name,
                "parameters": parameters_from_llm
            }
    
    def _build_enriched_params(self, task: Task, parameters_from_llm: Dict[str, Any]) -> Dict[str, Any]:

        enriched_params = {
            "loader": self.lian.loader,
            "resolver": self.lian.resolver,
            "lian": self.lian,
            "parameters_from_llm" : parameters_from_llm,
            "task": task
        }

        return enriched_params
    
    def get_ability_description(self, ability_name: str) -> Optional[Dict[str, Any]]:
        if ability_name in self._abilities:
            return self._abilities[ability_name]['info']
        return None
    
    def list_all_abilities(self) -> List[str]:
        return list(self._abilities.keys())
    
    def validate_ability_call(self, ability_name: str, parameters: Dict[str, Any]) -> bool:
        if ability_name not in self._abilities:
            return False
        
        ability_info = self._abilities[ability_name]['info']
        required_params = [param['name'] for param in ability_info['parameters'] if param.get('required', False)]
        
        for required_param in required_params:
            if required_param not in parameters:
                return False
        
        return True
