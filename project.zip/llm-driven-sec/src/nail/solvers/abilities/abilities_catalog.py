



ABILITIES_CATALOG = {

    "get_upper_call_stack": {
        "description": "获取调用栈的上一层调用点信息，每调用一次就多获取一层。",
        "parameters": "无需参数"
    },

    "get_parent_of_class": {
        "description": "获取指定类的所有直接父类的类名",
        "parameters": [
            {"name": "class_name", "type": "str", "description": "类名", "required": True}
        ]
    },
    "get_son_of_class": {
        "description": "获取某个类的所有直接子类的类名",
        "parameters": [
            {"name": "class_name", "type": "str", "description": "类名", "required": True}
        ]
    },

    "find_last_define_of_symbol": {
        "description": "查找符号的最后定义，symbol_name参数应该是一个简单的symbol",
        "parameters": [
            {"name": "symbol_name", "type": "str", "description": "符号名", "required": True}
        ]
    },
    "get_method_code_in_container": {
        "description": "返回某个类、模块、包中指定方法的定义源代码",
        "parameters": [
            {"name": "method_name", "type": "str", "description": "方法名", "required": True},
            {"name": "container_identifier", "type": "str", "description": "类名/模块绝对路径（文件绝对路径）/包绝对路径", "required": True},
            {"name": "container_type", "type": "str", "description": "如果为类则为class，如果为模块则为module，如果为包则为package", "required": True}
        ]
    },
    "get_init_method_source_code_of_class": {
        "description": "给一个类名，返回该类的__init__方法的源代码",
        "parameters": [
            {"name": "class_name", "type": "str", "description": "类名", "required": True}
        ]
    },
    "get_class_source_code": {
        "description": "获取某个类的源代码",
        "parameters": [
            {"name": "class_name", "type": "str", "description": "类名", "required": True}
        ]
    },

    "get_prop_def_codes_of_class": {
        "description": "给一个类名和属性名prop，返回该类中涉及到self/cls.prop",
        "parameters": [
            {"name": "class_name", "type": "str", "description": "类名", "required": True},
            {"name": "prop_name", "type": "str", "description": "属性名", "required": True}
        ]
    },

    "check_method_of_class": {
        "description": "判断某个类是否定义了指定方法",
        "parameters": [
            {"name": "class_name", "type": "str", "description": "类名", "required": True},
            {"name": "method_name", "type": "str", "description": "方法名", "required": True}
        ]
    },

    "get_possible_sources_of_key": {
        "description": "找到项目中，所有叫做key.py的文件的文件路径、所有定义了key类/方法的文件路径、包路径",
        "parameters": [
            {"name": "symbol_name", "type": "str", "description": "目标symbol名称", "required": True}
        ]
    },

    "analyze_project_context": {
        "description": "分析当前项目的上下文信息",
        "parameters": [ {} ]
    },
    "get_caller_source_code": {
        "description": "获取当前上下文所在方法的源代码",
        "parameters": [ ]
    },
    "get_class_define_path": {
        "description": "获取指定类的类定义所在文件路径",
        "parameters": [
            {"name": "class_name", "type": "str", "description": "类名", "required": True}
        ],
    },
    "get_with_source_code": {
        "description": "获取with子句的源代码",
        "parameters": [ ]
    },
    
    
    "get_source_code": {
        "description": "获取源代码",
        "parameters": [
            {"name": "file_path", "type": "str", "description": "文件路径", "required": True},
            {"name": "line_range", "type": "str", "description": "行号范围（可选）", "required": False}
        ]
    },
    "check_module_in_project": {
        "description": "检查指定模块是否在当前项目中存在",
        "parameters": [
            {"name": "module_name", "type": "str", "description": "模块名（如gradio、numpy等）", "required": True}
        ]
    },

}

SOLVER_TO_ABILITIES = {
    "CodeComprehensionSolver": [

    ],
    "DecoratorSolver": [
        "get_method_code_in_container",
    ],
    "ExternLibSolver": [
        "find_last_define_of_symbol",
    ],
    "HierarchySolver": [
        "get_son_of_class",
        "check_method_of_class",
    ],
    "ImportSolver": [
        "get_possible_sources_of_key",
        "analyze_project_context",
        "find_last_define_of_symbol",
        
    ],
    "MethodCallSolver": [
        "get_method_code_in_container",
        "get_class_define_path",
    ],
    "FunctionExecutionSolver": [

    ],
    "ParameterTypeSolver": [
        "get_upper_call_stack",
        "find_last_define_of_symbol"
    ],
    "ReturnTypeSolver": [
        "get_method_code_in_container",
        "find_last_define_of_symbol",
    ],
    "SelfClsFuncSolver": [
        "check_method_of_class",
        "get_parent_of_class",
        "get_class_define_path",
        "get_class_source_code"
    ],
    "SelfClsPropTypeSolver": [
        "get_caller_source_code",
        "get_class_source_code",
        "get_prop_def_codes_of_class",
        "get_init_method_source_code_of_class"
        
    ],
    "SuperTypeSolver": [
        "get_parent_of_class",
        "get_method_code_in_container"
    ],
    "SymbolTypeSolver": [
        "get_class_define_path",
        "find_last_define_of_symbol",
        "get_class_source_code",
        "check_method_of_class",
    ],
    "WithSolver": [
        "find_last_define_of_symbol"
    ],
    "MethodFinderSolver": [
        "get_class_define_path",
        "check_method_of_class",
        "get_method_code_in_container",
        "get_possible_sources_of_key",
        "find_last_define_of_symbol"
    ],
}
