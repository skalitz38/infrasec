from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult, AbilityCall
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class SymbolTypeSolver(SolverTemplate):

    available_solvers = ["SuperTypeSolver", "ImportSolver", "ReturnTypeSolver", "ParameterTypeSolver", "SelfClsPropTypeSolver",
                         "ExternLibSolver", "WithSolver", "SymbolTypeSolver", "HierarchySolver", "MethodFinderSolver"]
    
    router_description = cleandoc("""\
        **SymbolTypeSolver** - 符号类型和定义位置解析专家
        - **专业领域**: 解析符号类型、查找符号定义、审计符号定义语句类型、类定义识别
        - **解答问题**: 给定一个符号，该符号的具体类型、定义位置和来源是什么？
        - **适用场景**: 某符号的具体类型和定义位置未知，没有明确信息告知来自于哪里（类、方法、变量、模块等）
    """)
    
    def _init_solver(self):
        self.domain = "符号类型解析与定义语句审计"
        self.capabilities = "符号定义查找、定义语句类型审计、类定义识别、依赖符号迭代查找"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：获取symbol定义语句
            **强制工具调用**：
            - **必须执行**：调用find_last_define_of_symbol(symbol_name)获取symbol的定义语句
            - **工具要求**：在传递symbol_name时，如果碰到a.b.c.d()的链式调用的情况，应尝试"a"、"a.b"、"a.b.c"、"a.b.c.d"作为参数
            - **验证要求**：不允许跳过工具调用，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用find_last_define_of_symbol，获得symbol定义语句：[具体定义语句]"
            
            ### 第二步：审计定义语句类型并决策
            **类型审计与决策逻辑**：
            
            **情况A：没有找到该符号的定义语句**
            - 调用工具get_class_define_path(class_name)获取符号定义位置
            - 调用工具get_class_source_code(class_name)获取类的源代码
            - 若**调用所有可调用的工具后**，仍然无法确定symbol的具体类是什么，按FAILED输出
                    
            **情况B：symbol的定义语句类型是类声明语句（找到类定义）**
            - **类声明语句**：形如"class symbol_name:"形式的类声明
              - **验证要求**：必须是类声明语句，形如"class symbol_name"。并调用工具get_class_source_code(class_name)来验证是否获取到了类的源代码。
              - **输出结果**：category=CLASS, name=类名, path=类定义所在文件的绝对路径
              - **显式声明**：在reasoning中明确记录"找到类定义语句：[具体类型定义]，任务完成"
            
            **情况C：symbol的定义语句类型不是类声明语句**
            - **定义语句类型识别**：
              - **import语句**：如"import module_name"、"from module import symbol"等
                - **决策**：返回NEEDS_FOLLOWUP，转交其他Solver处理
                - **问题描述要求**：详细描述当前遇到的问题场景和需求
                - **必须包含**：
                  - 当前symbol的定义语句（import语句）
                  - 识别出的import类型（直接import、from import等）
                  - 这个问题的性质（import解析问题）
                  - 需要什么帮助（解析import语句，确定symbol的来源模块和类型）
                - **显式声明**：在reasoning中详细记录"找到import语句：[具体import语句]，需要其他Solver解析import语义，问题描述：[详细问题场景]"
              
              - **参数声明语句**：如"def func(param: type)"等
                - **决策**：返回NEEDS_FOLLOWUP，转交其他Solver处理。**忽略类型提示**
                - **问题描述要求**：详细描述当前遇到的问题场景和需求
                - **必须包含**：
                  - 当前symbol的定义语句（参数声明）
                  - 参数所在的函数和方法信息
                  - 这个问题的性质（参数类型解析问题）
                  - 需要什么帮助（解析参数类型，确定symbol的具体类型）
                - **显式声明**：在reasoning中详细记录"找到参数声明：[具体参数声明]，需要其他Solver解析参数类型，问题描述：[详细问题场景]"
              
              - **赋值语句**：如"symbol = value"等
                - **决策**：返回NEEDS_FOLLOWUP，转交其他Solver处理
                - **问题描述要求**：详细描述当前遇到的问题场景和需求
                - **必须包含**：
                  - 当前symbol的定义语句（赋值语句）
                  - 赋值语句的右侧值类型
                  - 这个问题的性质（变量类型推断问题）
                  - 需要什么帮助（解析赋值语句右侧值的类型，确定symbol的具体类型）
                - **显式声明**：在reasoning中详细记录"找到赋值语句：[具体赋值语句]，需要其他Solver解析变量类型，问题描述：[详细问题场景]"
              
              - **其他类型定义语句**：如返回值、self属性等
                - **决策**：返回NEEDS_FOLLOWUP，转交其他Solver处理
                - **问题描述要求**：详细描述当前遇到的问题场景和需求
                - **必须包含**：
                  - 当前symbol的定义语句
                  - 定义语句的具体类型
                  - 这个问题的性质（特定类型解析问题）
                  - 需要什么帮助（解析特定类型的定义，确定symbol的具体类型）
                - **显式声明**：在reasoning中详细记录"找到其他类型定义：[具体定义语句]，需要其他Solver解析，问题描述：[详细问题场景]"

            ### 第三步：检查任务执行历史中的已有信息
            - **找到了symbol的具体类型**：
                - 来自项目内部：如果任务执行历史中明确指出symbol来自某个source文件，以及具体类型
                - 来自项目外部：如果任务执行历史中明确指出symbol来自具体哪个外部库/标准库，以及外部库的具体信息
              - **决策**：直接采用该结果，结合定义语句完成判定，输出COMPLETED
              - **显式声明**：在reasoning中记录"依据任务执行历史#x条，确认symbol具体类型是：[具体结果]"
            
            ### 第四步：结果自检与输出
            **自检清单**：
            1. 是否调用工具找到了符号的定义语句？
            2. 是否判断了定义语句的类型？定义语句是不是类声明语句？
            3. 如果不是类声明语句，是否识别了具体的定义语句类型（import、参数声明、赋值等）？
            4. 如果识别出import语句，是否详细描述了问题场景并转交其他Solver？
            5. 如果识别出参数声明，是否详细描述了问题场景并转交其他Solver？
            6. 如果识别出其他类型定义，是否详细描述了问题场景并转交其他Solver？
            7. 如果不是类声明语句，是否在任务执行历史中检查有无可用信息？
            8. 如果是类定声明语句，是否调用工具获得了完整的类信息来进行验证？
            9. 每个结论都有明确的信息依据吗？
            
            **输出条件**：
            - **COMPLETED**：只有当找到明确的类型信息(category、name和path)，任务才算完成
            - **NEEDS_FOLLOWUP**：当获取到的定义语句不是类声明语句时
            - **NEEDS_ABILITY**：必须说明需要什么工具
            - **FAILED**：当没找到定义语句，且调用工具后也无法确定具体类型时""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于符号定义审计和结果整合的类型解析总结",
                "reasoning": "必须包含：1)find_last_define_of_symbol调用结果 2)定义语句类型判断 3)转交决策依据 4)任务执行历史中的结果检查 5)迭代查找过程",
                "result_data": {
                    "category": "symbol的类别，可以是CLASS,FILE,PACKAGE,EXTERNAL,FUNCTION",
                    "name": "symbol的具体类型名，可以是具体类名,文件绝对路径,模块绝对路径",
                    "path": "symbol定义所在的项目内部绝对路径"(若任务执行历史中明确告知来自外部库，则为空)
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "find_last_define_of_symbol", 
                        "parameters": { "symbol_name": "依赖的符号名" }, 
                        "description": "查找依赖符号的定义",
                        "reason": "需要继续迭代查找符号定义"
                    }, { 
                        "ability_name": "get_class_source_code", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取类的源代码",
                        "reason": "需要获取类的完整定义"
                    }, { 
                        "ability_name": "get_class_define_path", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取类的定义路径",
                        "reason": "需要获取类的定义路径"
                    },
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和需求", 
                    "metadata": { 
                        "symbol_name": "符号名", 
                        "definition_statement": "具体的定义语句",
                        "definition_type": "定义语句类型（import、参数声明、赋值等）",
                        "problem_nature": "问题的性质（import解析、参数类型解析、变量类型推断等）",
                        "help_needed": "需要什么帮助（解析import语义、参数类型、变量类型等）"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_symbol_type_result  
        self.post_processor = self._post_process_symbol_type_result  
        

    def _validate_symbol_type_result(self, result_data: dict) -> bool:
        required_fields = ["category", "name", "path"]
        return all(field in result_data for field in required_fields)
    
    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["symbol_name"]
        return all(param in task.params for param in required_params)
    
    def _post_process_symbol_type_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
