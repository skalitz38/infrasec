
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class SelfClsPropTypeSolver(SolverTemplate):

    available_solvers = ["SymbolTypeSolver", "SelfClsPropTypeSolver", "ReturnTypeSolver"]
    router_description = cleandoc("""\
        **SelfClsPropTypeSolver** - self/cls属性类型判断专家
        - **专业领域**: self/cls属性的具体类型判断、实例属性定义查找、实例属性类型推断、类属性识别、实例属性识别
        - **解答问题**：给定一个self/cls.prop属性，或给定一个类和一个属性名，这个属性的定义和类型是什么？
        - **适用场景**: self.property 或 cls.property 需要确定具体类型
        - **关键特征**: 处理属性访问，不涉及方法调用""")

    def _init_solver(self):
        self.domain = "self.property/cls.property类型解析与属性定义审计"
        self.capabilities = "属性定义查找、属性类型推断、类属性识别、实例属性识别"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：调用工具并搜索self/cls.prop属性的定义语句
            **强制工具调用**：
            - **必须执行**：依次调用get_caller_source_code(class_name)、get_init_method_source_code_of_class(class_name)、get_prop_def_codes_of_class(class_name, prop_name)和get_class_source_code(class_name)方法。
            - **验证要求**：必须调用工具，直到从工具结果中找到self/cls.prop属性的定义语句。不能基于假设或推测。
            - **显式声明**：在reasoning中明确记录"已调用xxx工具，来自工具调用第#x条记录，结果为[该工具结果]，其中找到了self/cls.prop的定义语句是[具体定义语句]"
            **属性定义查找逻辑**：
            - **搜索目标**：在工具结果中搜索self.property/cls.property的定义语句
            - **搜索顺序**: 当前方法源代码 > 当前类的__init__方法 > get_prop_def_codes_of_class返回的相关代码行 > 整个类的源代码
            - **查找模式**：self.property = 右值 或 cls.property = 右值
            
            ### 第二步：分析属性定义语句并确定解析策略
            **情况A：找到属性定义语句（非参数赋值）**
            - **定义语句形式**：self/cls.property = {obj/obj()/obj.prop/self.prop()/self.b().c()/a.b().c()等}，**不允许是参数声明**
            - **寻找策略**：记录所有找到的定义语句，逐个解析，直到能确定具体类型。
            - **决策**：返回NEEDS_FOLLOWUP，转交其他Solver解析右值中符号的具体类型信息。
            - **显式声明**：在reasoning中明确记录"在工具#x的结果中找到哪几条属性定义语句：[所有具体定义语句]，先从哪一条[具体定义语句]解析具体类型，需要转交其他Solver解析右值中符号的具体类型信息"
            
            **情况B：找到参数赋值语句（self.prop_name = prop_name）**
            - **识别条件**：发现self.prop_name = prop_name形式的赋值，其中prop_name是类中方法的参数
            - **兜底处理**：当遇到参数赋值时，开始寻找类型提示信息
            - **处理策略**：
              1. 检查__init__方法参数是否有类型注解
              2. 检查类属性是否有类型注解
              3. 检查是否有其他类型提示信息
            - **决策**：如果找到类型提示，返回FAILED并将TypeHint设为True；如果无类型提示，返回FAILED
            - **显式声明**：在reasoning中明确记录"发现参数赋值语句self.{prop_name} = {prop_name}，开始兜底处理寻找类型提示：[找到的类型提示信息或'无类型提示']"
            
            **情况C：未找到属性定义语句 或 实在无法确定属性具体类型**
            - **决策**：返回FAILED，若有类型提示信息，则返回类型提示信息并将TypeHint字段设为True。并详细描述失败情况
            - **显式声明**：在reasoning中记录"所有工具均未找到属性定义语句，有/无类型提示[类型提示信息]，[详细失败情况描述]"
            
            ### 第三步：检查任务执行历史中的类型解析结果
            **任务执行历史检查**：
            - **检查内容**：是否有任务执行历史；并且任务执行历史中是否明确提供了self.property/cls.property右值中符号的具体类型信息
            - **验证要求**：是否有任务执行历史明确提供了右值符号的具体类型信息？
            - **决策**：如果任务执行历史有具体类型信息，返回COMPLETED；如果没有，返回NEED_FOLLOWUP；如果有任务执行历史但没有具体类型信息，返回FAILED。
            - **显式声明**：在reasoning中明确记录"基于任务执行历史中的明确类型信息：[具体类型信息]，来源：[哪一条**任务执行历史**的类型解析结果]"
            
            ### 第四步：结果自检与输出
            **自检清单**：
            1. 是否调用了get_caller_source_code获得了方法源代码？
            2. 是否调用了get_init_method_source_code_of_class获得__init__方法源代码？
            3. 是否调用了get_prop_def_codes_of_class获得了属性相关代码行？
            4. 是否调用了get_class_source_code获得了类源代码？
            5. 在哪个工具调用结果中找到了属性定义？具体定义语句是什么？
            6. 是否在工具结果中找到了所有的属性定义语句？有没有遗漏？
            7. 找到定义语句后，是否按要求返回了NEEDS_FOLLOWUP？需要解析定义语句右值中的哪个符号？
            8. 只要有别的定义语句还没解析(没返回解析结果)，就不允许使用类型提示返回
            9. 只找到类型提示时，是否返回FAILED，TypeHint字段是否设为True？
            10. 当返回COMPLETED时，提供的最终结果是来自于**任务执行历史**中的明确类型信息吗？没有**任务执行历史**，禁止COMPLETED。
            
            **输出条件**：
            - **COMPLETED**：当且仅当任务执行历史中明确提供了self.property/cls.property的具体类型信息时。
            - **NEEDS_FOLLOWUP**：找到属性定义语句时，必须明确说明需要解析右值中符号的具体类型信息
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **FAILED**：如果未找到属性定义且任务执行历史中无明确类型信息""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED(只找到类型提示 或 无法解析具体类型)",
                "confidence": 0.0 - 1.0,
                "summary": "基于属性定义查找的属性类型解析总结，或描述遇到的问题",
                "reasoning": "必须包含：1)get_caller_source_code调用结果 2)get_init_method_source_code_of_class调用结果 3)get_prop_def_codes_of_class调用结果 4)get_class_source_code调用结果 5)属性定义查找过程 6)参数赋值兜底处理过程 7)需要解析的符号识别 8)任务执行历史中的类型信息检查 9)避免基于命名经验判断类型的说明",
                "result_data": {
                    "category": "属性的类别，可以是CLASS,FILE,PACKAGE,EXTERNAL",
                    "name": "属性的具体类型名，可以是具体类名,文件名,模块名,字面量类型",
                    "path": "属性类型定义所在的绝对路径",
                    "TypeHint": "返回的类型信息是否来自于类型提示"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "get_caller_source_code", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取当前方法源代码",
                        "reason": "需要获取当前方法源代码查找属性定义"
                    },
                    { 
                        "ability_name": "get_init_method_source_code_of_class", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取__init__方法源代码",
                        "reason": "需要在__init__方法中查找属性定义"
                    },
                    { 
                        "ability_name": "get_prop_def_codes_of_class", 
                        "parameters": { "class_name": "类名", "prop_name": "属性名" }, 
                        "description": "获取类中与指定属性相关的代码行",
                        "reason": "需要查找类中self.prop_name或cls.prop_name的定义语句代码行"
                    },
                    { 
                        "ability_name": "get_class_source_code", 
                        "parameters": { "class_name": "类名" }, 
                        "description": "获取类源代码",
                        "reason": "需要在类源代码中查找属性定义"
                    }
                ],
                "next_problems": { 
                    "description": "需要解析右值中符号的具体类型信息", 
                    "metadata": { 
                        "property_name": "属性名", 
                        "class_name": "类名",
                        "right_value_symbol": "右值中需要解析的符号名",
                        "definition_statement": "找到的属性定义语句",
                    }
                }
            }
            ```""")
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_self_cls_result  
        self.post_processor = self._post_process_self_cls_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["field_name", "class_name", "current_file"]
        return all(param in task.params for param in required_params)
    
    def _validate_self_cls_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["type"]
        return all(field in result_data for field in required_fields)
    
    def _post_process_self_cls_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
