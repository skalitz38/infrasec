from nail.common_structure import (
    Result
)
from lian.events.handler_template import EventData
from lian.config.constants import LIAN_SYMBOL_KIND
from lian.common_structs import ComputeFrame
from lian.util import util
from lian.util.loader import Loader


class ResultValidator:
    def __init__(self, lian):
        self.lian = lian
        self.loader:Loader = lian.loader
        self.resolver = lian.resolver
        
        self.result_cache: dict[tuple[int, int], set[int]] = {}

    def reset(self):
        
        self.result_cache.clear()

    def complete_lian(self, results, collected_info:dict, data:EventData):

        if not isinstance(results, list):
            results = [results]
        
        results = [res for res in results if res is not util.is_empty(res)]
        
        if util.is_empty(results):
            self.fallback_find_methods(collected_info, data)
            return
        
        all_failed = all(
            getattr(res, "status") == "FAILED" or getattr(res, "need_fallback", False) 
            for res in results
        )
        if all_failed:
            
            self.fallback_find_methods(collected_info, data)
            return

        in_data = data.in_data
        out_data = data.out_data
        frame:ComputeFrame = in_data.frame
        frame_call_site = frame.call_site
        breakpoint_stmt_id = in_data.stmt_id
        status = in_data.status
        
        all_callee_ids = set()
        all_uncertain_callee_ids = set()
        
        for res in results:
            if getattr(res, "status") == "FAILED" or getattr(res, "need_fallback", False):
                continue
            
            final_result = res.result_data
            container_type = final_result.get("container_type") 
            container_identifier_list = final_result.get("container_identifier") 
            if not isinstance(container_identifier_list, list):
                container_identifier_list = [container_identifier_list]
            method_name = final_result.get("method_name") 
            method_location = final_result.get("method_location") 

            callee_ids = set()
            
            uncertain_callee_ids = set()

            source_unit_id = self.loader.convert_unit_path_to_unit_id(method_location)

            if container_type == "class":
                
                for container_identifier in container_identifier_list:
                    candidate_methods = self.loader.get_method_of_class_with_name(container_identifier, method_name)
                    for candidate_method_id in candidate_methods:
                        
                        verifying_unit_id = self.loader.convert_method_id_to_unit_id(candidate_method_id)
                        if verifying_unit_id == source_unit_id:
                            callee_ids.add(candidate_method_id)
                        else:
                            uncertain_callee_ids.add(candidate_method_id)
            elif container_type == "module":
                for container_identifier in container_identifier_list:
                    unit_id = self.loader.convert_unit_path_to_unit_id(container_identifier)
                    if unit_id == -1:
                        unit_id = self.loader.convert_unit_path_to_unit_id(method_location)
                    symbol_global_def_in_unit = self.resolver.find_symbol_global_def_in_unit(unit_id, method_name)
                    candidate_methods = symbol_global_def_in_unit[LIAN_SYMBOL_KIND.METHOD_KIND]

                    if util.is_empty(candidate_methods):
                        
                        method_ids = self.loader.convert_method_name_to_method_ids(method_name)
                        for method_id in method_ids:
                            verifying_unit_id = self.loader.convert_method_id_to_unit_id(method_id)
                            if verifying_unit_id == unit_id:
                                
                                candidate_methods.add(method_id)

                    callee_ids.update(candidate_methods)
            
            all_callee_ids.update(callee_ids)
            all_uncertain_callee_ids.update(uncertain_callee_ids)

        if util.is_available(all_callee_ids):
            out_data.callee_method_ids = all_callee_ids
            cache_key = (frame_call_site, breakpoint_stmt_id)
            util.add_to_dict_with_default_set(self.result_cache, cache_key, all_callee_ids)
            out_data.interruption_flag = True
        elif util.is_available(all_uncertain_callee_ids):
            out_data.callee_method_ids = all_uncertain_callee_ids
            cache_key = (frame_call_site, breakpoint_stmt_id)
            util.add_to_dict_with_default_set(self.result_cache, cache_key, all_uncertain_callee_ids)
            out_data.interruption_flag = True
        else:
            
            self.fallback_find_methods(collected_info, data)

    def fallback_find_methods(self, collected_info, data:EventData):
        callee_name = collected_info.get("callee_name")
        breakpoint_stmt_id = collected_info.get("stmt_id")
        method_name = callee_name.split(".")[-1] if isinstance(callee_name, str) else None

        
        possible_methods = self.loader.convert_method_name_to_method_ids(method_name)
        out_data = data.out_data
        in_data = data.in_data
        frame:ComputeFrame = in_data.frame
        frame_call_site = frame.call_site
        out_data.callee_method_ids = possible_methods
        
        cache_key = (frame_call_site, breakpoint_stmt_id)
        util.add_to_dict_with_default_set(self.result_cache, cache_key, possible_methods)
        out_data.interruption_flag = True







