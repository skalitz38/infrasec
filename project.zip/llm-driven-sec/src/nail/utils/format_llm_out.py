
import re
import json

def get_dict_from_reply(reply: str) -> dict:

    def extract_outermost_braces(text: str) -> str:
        start = text.find('{')
        if start == -1:
            return None

        depth = 0
        for i in range(start, len(text)):
            if text[i] == '{':
                depth += 1
            elif text[i] == '}':
                depth -= 1
                if depth == 0:
                    return text[start:i+1]
        return None  
    candidate = extract_outermost_braces(reply)
    if not candidate:
        print("❌ 未找到任何 { } 结构")
        return None

    cleaned = candidate.strip()
    try:
        result = json.loads(cleaned)
        if isinstance(result, dict):
            return result
    except Exception as e:
        print(f"⚠️ json.loads 失败: {e}")
    try:
        fixed = re.sub(r"(?<!\\)'", '"', cleaned)  
        if isinstance(result, dict):
            return result
    except Exception as e:
        print(f"⚠️ 修复引号后仍失败: {e}")
    try:
        import ast
        result = ast.literal_eval(cleaned)
        if isinstance(result, dict):
            return result
    except Exception as e:
        print(f"⚠️ ast.literal_eval 失败: {e}")

    print("❌ 所有方法均失败，无法解析字典")
    return None
