
import logging
import os
import threading
from datetime import datetime
from typing import Any, Dict, Optional
from collections import defaultdict
_thread_local = threading.local()
_workflow_stats = defaultdict(lambda: {
    'start_time': None,
    'end_time': None,
    'log_count': 0,
    'status': 'UNKNOWN'
})
_stats_lock = threading.Lock()
_first_worker_lock = threading.Lock()
_first_worker_cleared = False
_last_logged_worker_id = None
_last_worker_lock = threading.Lock()


class RealtimeFileHandler(logging.FileHandler):
    def __init__(self, filename, mode='a', encoding=None, delay=False):
        super().__init__(filename, mode=mode, encoding=encoding, delay=delay)
        if not delay and self.stream:
            self.stream.close()
            self.stream = open(self.baseFilename, mode='a', encoding=encoding or 'utf-8', buffering=1)
    
    def _open(self):
        return open(self.baseFilename, self.mode, encoding=self.encoding, buffering=1)


class WorkflowLogger:
    _logger_cache = {}
    _cache_lock = threading.Lock()
    
    def __init__(self, log_file: str = "workflow_log.log", workspace_dir: str = None):
        self.logger = self._setup_logger(log_file, workspace_dir)
    
    @staticmethod
    def set_worker_id(worker_id: int):
        _thread_local.worker_id = worker_id
    
    @staticmethod
    def get_worker_id() -> Optional[int]:
        return getattr(_thread_local, 'worker_id', None)
    
    def _setup_logger(self, log_file: str, workspace_dir: str = None) -> logging.Logger:
        logger_name = f'workflow_{workspace_dir}' if workspace_dir else 'workflow'
        if logger_name in self._logger_cache:
            return self._logger_cache[logger_name]
        with self._cache_lock:
            if logger_name in self._logger_cache:
                return self._logger_cache[logger_name]
            
            logger = logging.getLogger(logger_name)
            logger.setLevel(logging.INFO)
            if logger.handlers:
                self._logger_cache[logger_name] = logger
                return logger
            if workspace_dir:
                workspace_name = os.path.basename(workspace_dir)
                workspace_parent = os.path.dirname(workspace_dir)
                log_path = os.path.join(workspace_parent, f"{workspace_name}_{log_file}")
            else:
                current_file = os.path.abspath(__file__)
                project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(current_file))))
                tests_dir = os.path.join(project_root, "tests")
                os.makedirs(tests_dir, exist_ok=True)
                log_path = os.path.join(tests_dir, "single_run_llm_workflow_log")
            file_handler = RealtimeFileHandler(log_path, encoding='utf-8')
            file_handler.setLevel(logging.INFO)
            

            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)

            formatter = logging.Formatter(
                '%(asctime)s | %(levelname)-8s | %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            
            file_handler.setFormatter(formatter)
            console_handler.setFormatter(formatter)
            logger.addHandler(file_handler) 
            logger.propagate = False
            self._logger_cache[logger_name] = logger
        
        return logger
    
    def _check_and_add_worker_segment(self):
        worker_id = self.get_worker_id()
        if worker_id is None:
            return
        
        global _last_logged_worker_id
        with _last_worker_lock:
            if _last_logged_worker_id is not None and _last_logged_worker_id != worker_id:
                self.logger.info("")
                self.logger.info("─" * 70)
                self.logger.info(f">>> Worker-{worker_id} 日志分段 <<<")
                self.logger.info("─" * 70)
                self.logger.info("")
            _last_logged_worker_id = worker_id
    
    def _log_with_worker_prefix(self, level: int, message: str):
        worker_id = self.get_worker_id()
        if worker_id is not None:
            self._check_and_add_worker_segment()
            with _stats_lock:
                _workflow_stats[worker_id]['log_count'] = _workflow_stats[worker_id].get('log_count', 0) + 1
        
        if worker_id is not None:
            message = f"[Worker-{worker_id}] {message}"
        self.logger.log(level, message)
    
    def log_planner_decision(self, task_type: str, problem_desc: str = '', planner_description:str = '', reasoning: str = "", todo_list: list = None):
        self._log_with_worker_prefix(logging.INFO, "🎯 PLANNER DECISION")
        if problem_desc:
            self.logger.info(f"   Problem: {problem_desc}")
        if planner_description:
            self.logger.info(f"   Planner_desc: {planner_description}")
        self.logger.info(f"   Task Type: {task_type}")
        if reasoning:
            self.logger.info(f"   Reasoning: {reasoning}")
        if todo_list and isinstance(todo_list, list) and len(todo_list) > 0:
            self.logger.info("   📋 Global Todo List:")
            for i, todo in enumerate(todo_list, 1):
                if not isinstance(todo, dict):
                    continue
                status = todo.get('status', 'TODO')
                status_icons = {
                    'TODO': '⏳ TODO',
                    'DOING': '🔄 DOING', 
                    'DONE': '✅ DONE',
                    'BLOCKED': '🚫 BLOCKED'
                }
                status_icon = status_icons.get(status, '❓')
                priority = todo.get('priority', 'MEDIUM')
                priority_icons = {
                    'HIGH': '🔴 HIGH',
                    'MEDIUM': '🟡 MEDIUM', 
                    'LOW': '🟢 LOW'
                }
                priority_icon = priority_icons.get(priority, '⚪')
                title = todo.get('title', f'Task {i}')
                description = todo.get('description', '')
                task_type_todo = todo.get('task_type', '')
                self.logger.info(f"      {i}. {status_icon} {priority_icon} {title}")
                if task_type_todo:
                    self.logger.info(f"         Type: {task_type_todo}")
                if description and len(description) <= 100:
                    self.logger.info(f"         Desc: {description}")
                elif description:
                    self.logger.info(f"         Desc: {description[:97]}...")
                depends_on = todo.get('depends_on', [])
                if depends_on and isinstance(depends_on, list) and len(depends_on) > 0:
                    deps_str = ', '.join(depends_on[:3])  
                    if len(depends_on) > 3:
                        deps_str += f" (+{len(depends_on)-3} more)"
                    self.logger.info(f"         Deps: {deps_str}")
                expected = todo.get('expected_outcome', '')
                if expected and len(expected) <= 80:
                    self.logger.info(f"         Goal: {expected}")
                elif expected:
                    self.logger.info(f"         Goal: {expected[:77]}...")
                if i < len(todo_list):
                    self.logger.info("         " + "·" * 30)
        
        self.logger.info("─" * 60)
    
    def log_router_dispatch(self, task_desc: str, solver_name: str, reasoning: str = "", candidates: list = None):
        self._log_with_worker_prefix(logging.INFO, "🚀 ROUTER DISPATCH")
        self.logger.info(f"   Task: {task_desc}")
        if candidates:
            candidates_str = ", ".join(candidates)
            self.logger.info(f"   Candidates: [{candidates_str}]")
        self.logger.info(f"   Selected: {solver_name}")
        if reasoning:
            self.logger.info(f"   Reasoning: {reasoning}")
        self.logger.info("─" * 60)
    
    def log_solver_result(self, solver_name: str, status: str,
                         result_summary: str = "", reasoning: str = ""):
        if status == "COMPLETED":
            level = logging.INFO
            icon = "✅"
        elif status == "NEEDS_FOLLOWUP":
            level = logging.WARNING
            icon = "🔄"
        elif status == "NEEDS_ABILITY":
            level = logging.INFO
            icon = "🔧"
        elif status == "FAILED":
            level = logging.ERROR
            icon = "❌"
        else:
            level = logging.INFO
            icon = "❓"
        
        self._log_with_worker_prefix(level, f"{icon} SOLVER RESULT - {solver_name}")
        self.logger.log(level, f"   Status: {status}")
        if result_summary:
            self.logger.log(level, f"   Result_Summary: {result_summary}")
        if reasoning:
            self.logger.log(level, f"   Reasoning: {reasoning}")
        self.logger.log(level, "─" * 60)
    
    def log_supervisor_processing(self, solver_name: str, task_name: str, solver_status: str,
                                 has_supervisor_feedback: bool, feedback_result: dict = None, 
                                 will_retry: bool = False):
        icon = "🔍"
        
        self._log_with_worker_prefix(logging.INFO, f"{icon} SUPERVISOR PROCESSING - {solver_name}")
        self.logger.info(f"   Task: {task_name}")
        self.logger.info(f"   Status: {solver_status}")
        self.logger.info(f"   Has_Supervisor_Feedback: {has_supervisor_feedback}")
        
        if feedback_result:
            self.logger.info(f"   Feedback_Result:")
            self.logger.info(f"     - Has_Hallucination: {feedback_result.get('has_hallucination', False)}")
            self.logger.info(f"     - Is_Consistent: {feedback_result.get('is_consistent', True)}")
            
            if feedback_result.get('supervision_process'):
                supervision_str = feedback_result['supervision_process']
                if len(supervision_str) > 200:
                    supervision_str = supervision_str[:200] + "..."
                self.logger.info(f"     - Supervision_Process: {supervision_str}")
            
            if feedback_result.get('comments'):
                comments_str = feedback_result['comments']
                if len(comments_str) > 200:
                    comments_str = comments_str[:200] + "..."
                self.logger.info(f"     - Comments: {comments_str}")
            
            if feedback_result.get('feedback'):
                feedback_str = feedback_result['feedback']
                if len(feedback_str) > 200:
                    feedback_str = feedback_str[:200] + "..."
                self.logger.info(f"     - Feedback: {feedback_str}")
        
        self.logger.info(f"   Will_Retry: {will_retry}")
        
        if will_retry:
            self.logger.info(f"   Action: 重置任务状态，让{solver_name}重新处理")
        else:
            self.logger.info(f"   Action: 继续正常流程")
        
        self.logger.info("─" * 60)
    
    def log_ability_call(self, solver_name: str, ability_name: str, 
                        parameters: dict, result: any):
        self._log_with_worker_prefix(logging.INFO, "🔧 ABILITY CALL")
        self.logger.info(f"   Solver: {solver_name}")
        self.logger.info(f"   Ability: {ability_name}")
        params_str = str(parameters) if parameters else "{}"
        if len(params_str) > 200:
            params_str = params_str[:200] + "..."
        self.logger.info(f"   Parameters: {params_str}")
        result_str = str(result) if result is not None else "None"
        if len(result_str) > 500:
            result_str = result_str[:500] + "..."
        self.logger.info(f"   Result: {result_str}")
        self.logger.info("─" * 60)

    def log_workflow_start(self, problem_desc: str, clear_previous: bool = True):
        worker_id = self.get_worker_id()
        if clear_previous:
            global _first_worker_cleared, _last_logged_worker_id
            with _first_worker_lock:
                if not _first_worker_cleared:
                    self.clear_log()
                    _first_worker_cleared = True
                    with _last_worker_lock:
                        _last_logged_worker_id = None
        if worker_id is not None:
            with _last_worker_lock:
                if _last_logged_worker_id is not None and _last_logged_worker_id != worker_id:
                    self.logger.info("")
                    self.logger.info("")
                    self.logger.info("╔" + "═" * 68 + "╗")
                    self.logger.info(f"║ {'Worker-' + str(worker_id) + ' 日志分段':^66} ║")
                    self.logger.info("╚" + "═" * 68 + "╝")
                    self.logger.info("")
                _last_logged_worker_id = worker_id
            
            with _stats_lock:
                _workflow_stats[worker_id]['start_time'] = datetime.now()
                _workflow_stats[worker_id]['log_count'] = 0
                _workflow_stats[worker_id]['status'] = 'RUNNING'
            
            self.logger.info("")
            self.logger.info("=" * 70)
            self.logger.info(f"Worker-{worker_id} 工作流开始")
            self.logger.info("=" * 70)
        else:
            self.logger.info("🚀 WORKFLOW STARTED")
        
        self.logger.info(f"   Problem: {problem_desc}")
        if worker_id is not None:
            self.logger.info("-" * 70)
        else:
            self.logger.info("=" * 60)
    
    def log_workflow_end(self, final_result: str = ""):
        worker_id = self.get_worker_id()
        if worker_id is not None:
            with _stats_lock:
                _workflow_stats[worker_id]['end_time'] = datetime.now()
                _workflow_stats[worker_id]['status'] = 'COMPLETED'
        
        if worker_id is not None:
            self.logger.info("-" * 70)
            self.logger.info("🏁 WORKFLOW COMPLETED")
        else:
            self.logger.info("🏁 WORKFLOW COMPLETED")
        
        if final_result:
            self.logger.info(f"   Final Result: {final_result}")
        
        if worker_id is not None:
            with _stats_lock:
                start_time = _workflow_stats[worker_id].get('start_time')
                end_time = _workflow_stats[worker_id].get('end_time')
                log_count = _workflow_stats[worker_id].get('log_count', 0)
            
            if start_time and end_time:
                duration = (end_time - start_time).total_seconds()
                self.logger.info(f"   耗时: {duration:.2f}秒 | 日志条数: {log_count}")
            
            self.logger.info("=" * 70)
            self.logger.info(f"Worker-{worker_id} 工作流结束")
            self.logger.info("=" * 70)
            self.logger.info("")
        else:
            self.logger.info("=" * 60)
    
    def log_task_creation(self, task_name: str, task_type: str, parent_task: str = ""):
        self._log_with_worker_prefix(logging.INFO, "📝 TASK CREATED")
        self.logger.info(f"   Name: {task_name}")
        self.logger.info(f"   Type: {task_type}")
        if parent_task:
            self.logger.info(f"   Parent: {parent_task}")
        self.logger.info("─" * 60)
    
    def log_task_completion(self, task_name: str, result_status: str):
        icon = "✅" if result_status == "COMPLETED" else "⚠️"
        self._log_with_worker_prefix(logging.INFO, f"{icon} TASK COMPLETED - {task_name}")
        self.logger.info(f"   Status: {result_status}")
        self.logger.info("─" * 60)

    def log_solver_iteration_limit(self, solver_name: str, task_desc: str, max_iterations: int, final_status: str = "UNKNOWN"):
        self._log_with_worker_prefix(logging.WARNING, "⏳ SOLVER ITERATION LIMIT REACHED")
        self.logger.warning(f"   Solver: {solver_name}")
        self.logger.warning(f"   Task: {task_desc}")
        self.logger.warning(f"   Max Iterations: {max_iterations}")
        self.logger.warning(f"   Final Status: {final_status}")
        self.logger.warning("─" * 60)

    def clear_log(self):
        log_path = None
        for handler in self.logger.handlers:
            if isinstance(handler, logging.FileHandler) or isinstance(handler, RealtimeFileHandler):
                log_path = handler.baseFilename
                break
        
        if log_path and os.path.exists(log_path):
            with open(log_path, 'w', encoding='utf-8') as f:
                f.write("")

        self.logger.info("📝 LOG FILE CLEARED - NEW SESSION STARTED")
    
    @staticmethod
    def reset_session():
        global _first_worker_cleared
        with _first_worker_lock:
            _first_worker_cleared = False
    
    @staticmethod
    def log_workflow_summary(total_workers: int):
        logger_instance = get_workspace_logger()
        
        with _stats_lock:
            completed_workers = [wid for wid in range(total_workers) 
                               if _workflow_stats[wid].get('status') == 'COMPLETED']
            
            if not completed_workers:
                return
            
            logger_instance.logger.info("")
            logger_instance.logger.info("=" * 70)
            logger_instance.logger.info("=" * 70)
            logger_instance.logger.info("汇总: 所有并发工作流统计")
            logger_instance.logger.info("=" * 70)
            logger_instance.logger.info(f"总工作流数: {total_workers}")
            logger_instance.logger.info(f"成功完成数: {len(completed_workers)}")
            logger_instance.logger.info("")
            logger_instance.logger.info("各Worker详情:")
            logger_instance.logger.info("-" * 70)
            
            for worker_id in sorted(completed_workers):
                stats = _workflow_stats[worker_id]
                start_time = stats.get('start_time')
                end_time = stats.get('end_time')
                log_count = stats.get('log_count', 0)
                duration = (end_time - start_time).total_seconds() if start_time and end_time else 0
                
                logger_instance.logger.info(f"  Worker-{worker_id}: "
                                          f"耗时 {duration:.2f}秒 | "
                                          f"日志 {log_count}条 | "
                                          f"状态 {stats.get('status', 'UNKNOWN')}")
            
            logger_instance.logger.info("=" * 70)
            logger_instance.logger.info("=" * 70)
            logger_instance.logger.info("")
_global_logger_cache: Dict[str, WorkflowLogger] = {}
_logger_cache_lock = threading.Lock()

_global_workflow_logger: Optional[WorkflowLogger] = None


def get_workflow_logger() -> WorkflowLogger:
    global _global_workflow_logger
    if _global_workflow_logger is None:
        if not os.environ.get("NAIL_SESSION_DIR"):
            workspace_dir = None
        else:
            workspace_dir = os.environ.get("LLM_WORKFLOW_LOG_DIR")
        _global_workflow_logger = get_workspace_logger(workspace_dir)
    return _global_workflow_logger

def get_workspace_logger(workspace_dir: str = None) -> WorkflowLogger:
    if not os.environ.get("NAIL_SESSION_DIR"):
        workspace_dir = None
    else:
        if workspace_dir is None:
            workspace_dir = os.environ.get("LLM_WORKFLOW_LOG_DIR")
    cache_key = str(workspace_dir) if workspace_dir else "None"
    if cache_key in _global_logger_cache:
        return _global_logger_cache[cache_key]
    with _logger_cache_lock:
        if cache_key in _global_logger_cache:
            return _global_logger_cache[cache_key]
        logger_instance = WorkflowLogger(log_file="llm_workflow_log", workspace_dir=workspace_dir)
        _global_logger_cache[cache_key] = logger_instance
        return logger_instance
