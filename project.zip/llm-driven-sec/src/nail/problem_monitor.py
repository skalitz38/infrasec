from nail.common_structure import (
    Problem
)
from nail.tasks.task_router import TaskRouter
from nail.config import config
from lian.events.handler_template import EventData
from nail.utils.build_context import get_call_stmt_context, filter_llm_relevant_metadata
from lian.core.resolver import Resolver
from lian.util.loader import Loader
from nail.result_validator import ResultValidator
from nail.utils.workflow_log import WorkflowLogger
from concurrent.futures import ThreadPoolExecutor, as_completed, wait
from typing import List, Optional
import copy


class ProblemMonitor:
    def __init__(self, lian):
        self.lian = lian
        self.loader:Loader = lian.loader
        self.resolver:Resolver = lian.resolver
        self.result_validator:ResultValidator = ResultValidator(lian)
        self.router = TaskRouter(lian=lian)
        self.current_breakpoint_id = None

    def method_call_handler(self, data: EventData):
        in_data = data.in_data
        breakpoint_stmt_id = in_data.stmt_id
        frame = data.in_data.frame
        if self.current_breakpoint_id != breakpoint_stmt_id:
            self.current_breakpoint_id = breakpoint_stmt_id
            self.router.reset()
        if config.ONLY_DYNAMIC_ANALYSIS:
            if frame.stmt_state_analysis.analysis_phase_id != 3:
                return

        if breakpoint_stmt_id in self.result_validator.result_cache:
            out_data = data.out_data
            callee_ids = self.result_validator.result_cache.get(breakpoint_stmt_id)
            out_data.callee_method_ids = callee_ids
            out_data.interruption_flag = True
            return
        collected_info = get_call_stmt_context(data)
        if not collected_info:
            return
        llm_metadata = filter_llm_relevant_metadata(collected_info)
        
        problem = Problem( 
            description="**这是初始任务————函数调用解析失败**。核心目标是解析出这条函数调用语义实际调用的目标方法信息",
            metadata=llm_metadata
        )

        Problem.set_breakpoint_context(collected_info)  
        results = self.found_problem(problem)
        self.result_validator.complete_lian(results, collected_info, data)

    def found_problem(self, problem) -> List:
        CONCURRENT_COUNT = config.LLM_CONCURRENT_COUNT
        
        def run_single_workflow(problem_copy: Problem, worker_id: int):
            WorkflowLogger.set_worker_id(worker_id)
            router = TaskRouter(lian=self.lian)
            try:
                result = router.run(problem_copy)
                return result
            except Exception as e:
                print(f"并发工作流执行失败 (Worker-{worker_id}): {e}")
                return None
        results = []
        timeout_seconds = getattr(config, "LLM_CONCURRENT_TIMEOUT_SECONDS", 60)
        with ThreadPoolExecutor(max_workers=CONCURRENT_COUNT) as executor:
            future_to_worker = {
                executor.submit(run_single_workflow, copy.deepcopy(problem), i): i
                for i in range(CONCURRENT_COUNT)
            }
            done, not_done = wait(set(future_to_worker.keys()), timeout=timeout_seconds)

            for future in done:
                worker_id = future_to_worker[future]
                try:
                    result = future.result()
                    if result is not None:
                        results.append(result)
                except Exception as e:
                    print(f"并发工作流结果获取失败 (Worker-{worker_id}): {e}")
            if not_done:
                for future in not_done:
                    worker_id = future_to_worker[future]
                    future.cancel()
                executor.shutdown(wait=False, cancel_futures=True)
                print(f"并发工作流执行超时，已取消未完成任务数量: {len(not_done)}，超时时间: {timeout_seconds}s")
        WorkflowLogger.log_workflow_summary(CONCURRENT_COUNT)
        return results if results else []
