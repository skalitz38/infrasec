from inspect import cleandoc

from nail.common_structure import Problem, Task, SolverResult
from nail.utils.workflow_log import get_workspace_logger


logger = get_workspace_logger()

class TaskExecutor:

    def __init__(self, task_stack=None, lian=None):
        self.task_stack = task_stack
        self.lian = lian
        from nail.tasks.router_impl import LLMTaskRouter
        self.llm_router = LLMTaskRouter()

    def dispatch_to_solver(self, task):

        solver_name = self.llm_router.resolve_solver_name(task)
        if solver_name:
            solver = self.llm_router.instantiate(solver_name, lian=self.lian)

            if solver is not None:
                setattr(task, 'dispatched_solver', solver_name)
                result = solver.solve(task)
                return result
        elif solver_name is None:
            from nail.common_structure import SolverResult
            return SolverResult(
                status="FAILED",
                error_message="当前不应该NeedFollowUP，没有找到合适的solver来处理此任务。",
                reasoning="Router无法找到可用的solver",
                summary="Router分发失败"
            )
        from nail.solvers.method_call_solver import MethodCallSolver
        from nail.solvers.import_solver import ImportSolver
        from nail.solvers.method_finder_solver import MethodFinderSolver

        if getattr(task, 'task_type', None) == 'METHOD_CALL':
            solver = MethodCallSolver(self.lian)
            return solver.solve(task)

        if getattr(task, 'task_type', None) == 'IMPORT_RESOLUTION':
            solver = ImportSolver(self.lian)
            return solver.solve(task)

        if getattr(task, 'task_type', None) == 'FUNC_DEFINITION':
            solver = MethodFinderSolver(self.lian)
            return solver.solve(task)

        return None

    def result_determination(self, task, result):
        if result is None:
            return 'CONTINUE'

        status = getattr(result, 'status', '')
        if hasattr(result, 'supervisor_feedback') and result.supervisor_feedback:
            feedback = result.supervisor_feedback
            has_issues = feedback.get('has_hallucination') or not feedback.get('is_consistent', True)
            solver_name = getattr(task, 'dispatched_solver', 'Unknown')
            logger.log_supervisor_processing(
                solver_name=solver_name,
                task_name=task.name,
                solver_status=status,
                has_supervisor_feedback=True,
                feedback_result=feedback,
                will_retry=has_issues
            )

            if has_issues:
                print(f"[TaskExecutor] 检测到监督反馈，重新处理任务: {task.name}")
                task.supervisor_feedback = feedback
                task.status = "PENDING"
                return 'CONTINUE'

        if status == 'COMPLETED' or (hasattr(result, 'is_completed') and result.is_completed()):
            return self._handle_completed(task, result)
        if (status == 'NEEDS_ABILITY' or (hasattr(result, 'needs_ability') and result.needs_ability())
            or status == 'NEEDS_FOLLOWUP' or (hasattr(result, 'needs_followup') and result.needs_followup())):
            return self._handle_needs_followup(task, result)

        if status == 'FAILED' or (hasattr(result, 'is_failed') and result.is_failed()):
            return self._handle_failed(task, result)

        return 'CONTINUE'

    def _handle_completed(self, task: Task, result: SolverResult) -> str:
        if hasattr(self.task_stack, 'add_success'):
            self.task_stack.add_success(task, result)
        task.complete(result)
        try:
            if hasattr(self.task_stack, 'planner') and self.task_stack.planner:
                planner = self.task_stack.planner
                if hasattr(planner, 'llm_planner') and planner.llm_planner:
                    planner.llm_planner.update_after_solver_completed(task, result)
        except Exception as e:
            logger.warning(f"[TaskExecutor] 通知 Planner 更新 todo-list 失败: {e}")
        
        if len(self.task_stack) > 1:
            parent_task:Task = self.task_stack.stack[-2]  
            if hasattr(task, 'parent_task') and task.parent_task and parent_task == task.parent_task:
                parent_task.resume()
        
        return 'DONE'

    def _handle_needs_followup(self, task: Task, result: SolverResult) -> str:
        new_problem = self._create_new_problem_from_solver_result(task, result)
        if hasattr(self.task_stack, 'planner') and self.task_stack.planner:
            next_task:Task = self.task_stack.planner.plan(new_problem)
            if next_task:
                task.add_child_task(
                    child_task=next_task,
                    purpose=f"解决{task.name}中的{getattr(result, 'summary', '未知问题')}",
                )
                task.interrupt(result)
                
                self.task_stack.add(next_task)
                return 'CONTINUE'
        return 'CONTINUE'

    def _create_new_problem_from_solver_result(self, task: Task, result: SolverResult) -> Problem:
        from nail.common_structure import Problem
        summary = getattr(result, 'summary', '')
        reasoning = getattr(result, 'reasoning', '')
        result_data = getattr(result, 'result_data', {})
        follow_up_tasks = getattr(result, "follow_up_tasks", {})
        
        description_parts = []
        summary = summary if summary else "无"
        reasoning = reasoning if reasoning else "无"
        result_data = result_data if result_data else "无"
        follow_up_tasks = follow_up_tasks if follow_up_tasks else "无"

        description_parts.append(cleandoc(f"""\
            - 问题总结：{summary}
            - 分析推理：{reasoning}
            - 发现信息：{result_data}
            - 面临问题描述：{follow_up_tasks}"""))

        new_description = "\n".join(description_parts) if description_parts else f"在分析{task.description}时产生的新问题"
        parent_planner_ctx = {}
        try:
            parent_planner_ctx = (getattr(getattr(task, 'problem', None), 'metadata', {}) or {}).get('planner_context', {})
        except Exception:
            parent_planner_ctx = {}

        new_metadata = {
            'solver_reasoning': reasoning,
            'solver_result_data': result_data,
            'follow_up_tasks': getattr(result, 'follow_up_tasks', []),
            'summary': summary,
            'reasoning': reasoning,
            'result_data': result_data,
        }
        if parent_planner_ctx:
            new_metadata['planner_context'] = parent_planner_ctx
        new_problem = Problem(
            description=new_description,
            metadata=new_metadata
        )

        return new_problem

    def _handle_failed(self, task: Task, result: SolverResult) -> str:
        if hasattr(self.task_stack, 'add_failure'):
            from nail.common_structure import Failure
            self.task_stack.add_failure(Failure(task=task, result=result, description=result.error_message or result.reasoning))
        task.fail(result)

        if len(self.task_stack) > 1:
            parent_task:Task = self.task_stack.stack[-2]  
            if hasattr(task, 'parent_task') and task.parent_task and parent_task == task.parent_task:
                parent_task.resume()
        return 'DONE'
