import os
from lian.util import util

ROOT_DIR                        = os.path.realpath(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))))
ROOT_DIR                        = os.path.dirname(ROOT_DIR)
LIAN_DIR                        = os.path.join(ROOT_DIR, "lian/src")
SRC_DIR                         = os.path.join(ROOT_DIR, "src")

ANY_LANG                        = "%"


DEEPSEEK_API_KEY                = "your-api-key"
DEEPSEEK_MODEL                  = "deepseek-chat"
DEEPSEEK_BASE_URL               = "https://api.deepseek.com/v1"
LLM_CONCURRENT_COUNT            = 5
LLM_CONCURRENT_TIMEOUT_SECONDS  = 300

SOLVER_MAX_TIMES                = 15
INITIAL_TASK_MAX_TIMES          = 3

ENABLE_SOLVER_SUPERVISION       = False
SUPERVISION_VOTERS              = 1


SEC_WORKSPACE_DIR               = os.path.join(ROOT_DIR, "tests/workspace")


EXTERN_PATH                     = os.path.join(ROOT_DIR, "src/llm_driven_sec/externs")
ONLY_DYNAMIC_ANALYSIS            = True


IGNORED_METHOD_LIST = {
    "len", "type", "id", "repr", "str", "format", "print", "dir",
    "vars", "locals", "globals", "hash",
    "int", "float", "str", "bool", "list", "dict", "tuple", "set",
    "frozenset", "bytes", "bytearray", "memoryview",
    "isinstance", "issubclass",
    "Exception", "BaseException", "ValueError", "TypeError", "RuntimeError",
    "raise", "assert",
    "enumerate", "zip", "map", "filter", "any", "all",
    "sorted", "reversed",
    "getattr", "setattr", "hasattr", "delattr",
    "abs", "sum", "min", "max", "round", "pow", "divmod",
    "copy", "deepcopy",
    "cast", "Any", "Optional", "Union", "logging.Formatter"
}

