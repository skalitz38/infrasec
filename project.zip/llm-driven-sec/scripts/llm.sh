

clear

if [ $
    echo "$0 <path>"
    exit 1
fi


ROOT_DIR=$(realpath $0)
ROOT_DIR=$(dirname $ROOT_DIR)
ROOT_DIR=$(dirname $ROOT_DIR)



CMD="python $ROOT_DIR/src/llm_driven_sec/main.py"
OUTPUT_PATH="$ROOT_DIR/tests/workspace"
OPTIONS="run -l python,java -f -d -w $OUTPUT_PATH"




$CMD $OPTIONS $@

echo


