function forEach(callback) {
    for (var index in this) {
        callback(obj[index], index, obj);
    }
}

