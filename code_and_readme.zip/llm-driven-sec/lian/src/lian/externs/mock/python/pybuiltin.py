def append(e):
    this[e] = e