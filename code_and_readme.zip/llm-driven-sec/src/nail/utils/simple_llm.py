

from openai import OpenAI
from nail.config import config

class SimpleLLM:
    
    def __init__(self, model=None, llm_character=None):
        self.model = model or getattr(config, "DEEPSEEK_MODEL", "deepseek-chat")
        self.llm_character = llm_character  
        self.client = OpenAI(
            api_key=getattr(config, "DEEPSEEK_API_KEY", ""),
            base_url=getattr(config, "DEEPSEEK_BASE_URL", "https://api.deepseek.com/v1")
        )

    def chat_structured(self, system_prompt: str, user_prompt: str) -> str:
        import time
        import uuid

        conversation_id = str(uuid.uuid4())[:8]
        timestamp = time.strftime("%H:%M:%S")

        caller_emoji = "🤖"
        display_name = "LLM"
        if self.llm_character == "planner":
            caller_emoji = "📋"
            display_name = "PLANNER"
        elif self.llm_character == "router":
            caller_emoji = "🔀"
            display_name = "ROUTER"
        elif self.llm_character and self.llm_character.endswith("Solver"):
            caller_emoji = "🔧"
            display_name = f"SOLVER({self.llm_character})"
        elif self.llm_character:
            display_name = self.llm_character.upper()
        print("=" * 80)
        print(f"{caller_emoji} {display_name}对话开始 [{conversation_id}] - {timestamp}")
        print("=" * 80)
        print("📥 用户提示词:")
        print("-" * 40)
        print(user_prompt)
        print(f"来自({caller_emoji} {display_name})")
        print("-" * 40)
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=1500,
                temperature=0.3
            )
            result = response.choices[0].message.content

            print("📤 LLM响应:")
            print("-" * 40)
            print(result)
            print("-" * 40)
            print(f"✅ {display_name}对话完成 [{conversation_id}]")
            print("=" * 80)
            print()

            return result
        except Exception as e:
            return f"LLM调用失败: {str(e)}"
