
import sys
from typing import Any, Dict
from lian.core.resolver import Resolver
from lian.util.loader import Loader
from lian.util import util
from lian.events.handler_template import EventData
from lian.config.constants import (
    EVENT_KIND,
    LIAN_SYMBOL_KIND, LIAN_INTERNAL
)
from lian.common_structs import (
    AccessPoint,
    InterruptionData,
    State,
    Symbol,
    ComputeFrame
)
from nail.config.config import IGNORED_METHOD_LIST


def concat_source_code(code: list[str]) -> str:
    return "\n".join(code)

def get_call_stmt_context(data: EventData) -> dict:
    context = {}
    language: str = data.lang
    in_data = data.in_data
    loader:Loader = in_data.loader
    resolver:Resolver = in_data.resolver
    frame:ComputeFrame = in_data.frame
    stmt_id = in_data.stmt_id
    unit_id = loader.convert_stmt_id_to_unit_id(stmt_id)
    unit_info = loader.convert_module_id_to_module_info(unit_id)
    unit_path = unit_info.unit_path if unit_info.unit_path else loader.convert_unit_id_to_unit_path(unit_id)
    class_id = loader.convert_method_id_to_class_id(frame.method_id)
    class_name = loader.convert_class_id_to_class_name(class_id)
    status = in_data.status
    stmt_src_code = loader.get_stmt_source_code_with_comment(stmt_id)
    callee_name = resolver.recover_callee_name(stmt_id, loader)

    if callee_name in IGNORED_METHOD_LIST:
        return {}
    target_snippets = [
        "return self._call_with_config(self._format_prompt_with_error_handling,",
        "return func(input, **kwargs)",
        "context.run(call_func_with_variable_args,",
        "query_result = conn.execute(sql).fetchall()",
        "session.flush()",
        "self.chat_handler = llama_chat_format.Jinja2ChatFormatter(",
        "self.model_executor = executor_class(vllm_config=vllm_config, )",
        "self._init_executor()",
        "self.driver_worker.load_model()",
        "return tokenizer_class.from_pretrained(pretrained_model_name_or_path, *inputs, **kwargs)",
        "f.write(image.file.read())",
        "output = await app.get_blocks().process_api(",
        "pickle.load(file_path.open('rb'))",
    ]

    if callee_name.startswith(LIAN_INTERNAL.SELF):
        callee_name = callee_name.replace(LIAN_INTERNAL.SELF, "self")
    context["stmt"] = in_data.stmt
    context["stmt_id"] = stmt_id
    context["loader"] = loader
    context["resolver"] = resolver
    context["file_path"] = unit_info.unit_path
    context["language"] = language
    context["callee_name"] = callee_name
    context["frame"] = frame
    context["unit_id"] = frame.unit_id
    context["method_id"] = frame.method_id
    context["class_id"] = class_id
    context["class_name"] = class_name
    context["status"] = status
    context["class_id"] = loader.convert_method_id_to_class_id(frame.method_id)
    context["class_name"] = "非类方法" if loader.convert_class_id_to_class_name(context["class_id"]) == -1 else loader.convert_class_id_to_class_name(context["class_id"])
    context["call_site_code"] = concat_source_code(loader.get_stmt_source_code_with_comment(stmt_id))
    context["caller_code"] = concat_source_code(loader.get_stmt_source_code_with_comment(in_data.frame.method_id))

    return context


def filter_llm_relevant_metadata(collected_info: Dict[str, Any]) -> Dict[str, Any]:
    if not collected_info:
        return {}
    llm_relevant_fields = {
        'call_site_code',    
        'callee_name',       
        'file_path',         
        'symbol_name',       
        'language',         
        'class_name',        
    }

    filtered = {}
    for key in llm_relevant_fields:
        if field := collected_info.get(key, None): 
            filtered[key] = field

    return filtered
