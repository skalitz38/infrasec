from typing import Dict, Any, List, Optional

from nail.utils.simple_llm import SimpleLLM
from nail.utils.format_llm_out import get_dict_from_reply
from nail.utils.workflow_log import get_workspace_logger



class SolverSupervisor:
    def __init__(self, model: Optional[str] = None):
        self.model = model

    def generate_system_prompt(self) -> str:
        return (
            "你是一个严谨的多Agent协作监督模型，负责审阅求解器的处理过程。\n"
            "## 监督维度\n"
            "1. **幻觉检测**：推理中是否引用了不存在的事实或无支撑的断言\n"
            "2. **一致性检查**：结论是否与证据、历史信息、前后推理一致\n"
            "3. **历史信息利用**：是否正确使用了任务执行历史中的已有信息\n"
            "4. **重复处理检测**：是否重复处理了已完成的任务\n"
            "5. **输出格式合规**：结果是否符合期望的输出格式\n"
            "\n"
            "## 特别关注点\n"
            "- 如果任务执行历史中已有相关信息，Solver是否有效利用了这些信息？\n"
            "- 如果历史信息明确，Solver是否忽略了这些信息？\n"
            "- Solver的推理是否与历史信息矛盾？\n"
            "- Solver是否已经具备了所有必要信息但仍返回NEEDS_FOLLOWUP？\n"
            "- Solver是否在超出自己职责范围的问题上仍然返回NEEDS_FOLLOWUP？如果是职责以外的事，应该返回COMPLETED或FAILED\n"
            "- Solver是否没有满足任务完成条件，但仍返回COMPLETED？\n"
            "- Solver是否声明需要调用工具，但却返回COMPLETED而非NEEDS_FOLLOWUP？"
            "\n"
            "## 输出格式\n"
            "仅输出严格JSON：{\n"
            "  \"is_consistent\": true|false,\n"
            "  \"has_hallucination\": true|false,\n"
            "  \"confidence_adjustment\": 0.0-1.0,\n"
            "  \"supervision_process\": \"详细的监督过程和理由\",\n"
            "  \"feedback\": \"简短的反馈意见(给Solver看的)\",\n"
            "  \"comments\": \"简述问题或确认\"\n"
            "}\n"
            "请仅输出JSON本体。"
        )
    
    def generate_user_prompt(self, payload: Dict[str, Any]) -> str:
        task_desc = payload.get("task_desc", "")
        task_params = payload.get("task_params", {})
        summary = payload.get("summary", "")
        reasoning = payload.get("reasoning", "")
        ability_results = payload.get("ability_results", [])
        result_data = payload.get("result_data", {})
        guided_steps = payload.get("guided_steps", "")
        task_execution_history = payload.get("task_execution_history", "")
        expected_output_format = payload.get("expected_output_format", "")
        
        return (
            f"## 任务信息\n"
            f"任务描述: {task_desc}\n"
            f"任务参数: {task_params}\n"
            f"\n"
            f"## 任务执行历史\n"
            f"{task_execution_history}\n"
            f"\n"
            f"## 求解器处理结果\n"
            f"总结: {summary}\n"
            f"推理: {reasoning}\n"
            f"工具结果: {ability_results}\n"
            f"结构化输出: {result_data}\n"
            f"## 求解器指导步骤\n"
            f"{guided_steps}\n"
            f"## 期望输出格式\n"
            f"{expected_output_format}\n"
            f"请基于以上信息进行监督审查。"
        )

    def review_once(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        llm = SimpleLLM()
        system_prompt = self.generate_system_prompt()
        user_prompt = self.generate_user_prompt(payload)
        try:
            reply = llm.chat_structured(system_prompt=system_prompt, user_prompt=user_prompt)
            verdict = get_dict_from_reply(reply) or {}
            return verdict
        except Exception:
            return {}

    def review_with_voting(self, payload: Dict[str, Any], voters: int = 3) -> Dict[str, Any]:
        votes: List[Dict[str, Any]] = []
        for _ in range(max(1, voters)):
            v = self.review_once(payload)
            votes.append(v if isinstance(v, dict) else {})

        def vote_bool(key: str, default: bool) -> bool:
            tally = 0
            total = 0
            for v in votes:
                if key in v:
                    total += 1
                    tally += 1 if bool(v.get(key)) else 0
            if total == 0:
                return default
            return tally >= (total // 2 + 1)

        def median_conf() -> Optional[float]:
            vals: List[float] = []
            for v in votes:
                try:
                    c = float(v.get("confidence_adjustment"))
                    if 0.0 <= c <= 1.0:
                        vals.append(c)
                except Exception:
                    pass
            if not vals:
                return None
            vals.sort()
            n = len(vals)
            if n % 2 == 1:
                return vals[n // 2]
            return (vals[n // 2 - 1] + vals[n // 2]) / 2.0
        supervision_processes = [str(v.get("supervision_process", "")) for v in votes if v.get("supervision_process")]
        feedbacks = [str(v.get("feedback", "")) for v in votes if v.get("feedback")]
        
        agg = {
            "is_consistent": vote_bool("is_consistent", True),
            "has_hallucination": vote_bool("has_hallucination", False),
            "confidence_adjustment": median_conf(),
            "supervision_process": "; ".join(supervision_processes)[:1024] if supervision_processes else "",
            "feedback": "; ".join(feedbacks)[:512] if feedbacks else "",
            "comments": "; ".join([str(v.get("comments")) for v in votes if v.get("comments")])[:512]
        }
        return agg



def doublecheck_solver_result_by_supervisor(result, task, guided_steps: str, voter_counts: int = 3, solver=None):

    supervisor = SolverSupervisor()
    ability_results = task.ability_call_history
    task_execution_history = ""
    if hasattr(task, 'format_execution_history'):
        task_execution_history = task.format_execution_history()
    expected_output_format = ""
    if solver and hasattr(solver, 'output_format'):
        expected_output_format = solver.output_format

    payload = {
        "task_desc": getattr(task, 'description', ''),
        "task_params": getattr(task, 'params', {}),
        "summary": getattr(result, 'summary', ''),
        "reasoning": getattr(result, 'reasoning', ''),
        "ability_results": ability_results,
        "result_data": getattr(result, 'result_data', {}),
        "guided_steps": guided_steps,
        "task_execution_history": task_execution_history,
        "expected_output_format": expected_output_format,
    }

    verdict = supervisor.review_with_voting(payload, voters=max(1, voter_counts))

    has_hallu = bool(verdict.get("has_hallucination", False))
    consistent = bool(verdict.get("is_consistent", True))
    adj = verdict.get("confidence_adjustment")
    try:
        if adj is not None:
            adj = float(adj)
            result.confidence = max(0.0, min(1.0, adj))
    except Exception:
        pass
    if not hasattr(result, 'supervisor_feedback'):
        setattr(result, 'supervisor_feedback', {})
    
    result.supervisor_feedback.update({
        "supervision_process": verdict.get("supervision_process", ""),
        "feedback": verdict.get("feedback", ""),
        "has_hallucination": has_hallu,
        "is_consistent": consistent,
    })

    return result

