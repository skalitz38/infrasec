
from typing import Any, Optional, List
from inspect import cleandoc


class Problem:

    _breakpoint_full_context = None

    @classmethod
    def set_breakpoint_context(cls, collected_info):
        cls._breakpoint_full_context = collected_info

    @classmethod
    def get_breakpoint_context(cls):
        return cls._breakpoint_full_context

    def __init__(self, description, metadata=None):
        self.description = description
        self.metadata = metadata or {}
        self._full_context = None 

    def to_dict(self) -> dict:

        return {
            'description': self.description,
            'metadata': self.metadata,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'Problem':

        problem = cls(
            description=data.get('description', ''),
            metadata=data.get('metadata', {})
        )
        problem._full_context = data.get('_full_context')
        return problem


class SolverResult:


    def __init__(self,
                 status: str,  
                 result_data: dict = None,
                 confidence: float = 0.0,
                 reasoning: str = "",
                 summary: str = "",
                 suggested_abilities: list = None,
                 follow_up_tasks: list = None,
                 error_message: str = ""):
        self.status = status
        self.result_data = result_data or {}
        self.confidence = confidence  
        self.reasoning = reasoning  
        self.summary = summary  
        self.suggested_abilities = suggested_abilities  
        self.follow_up_tasks = follow_up_tasks or []  
        self.error_message = error_message

    def is_completed(self) -> bool:
        return self.status == "COMPLETED"

    def needs_ability(self) -> bool:
        return self.status == "NEEDS_ABILITY"

    def needs_followup(self) -> bool:
        return self.status == "NEEDS_FOLLOWUP"

    def is_failed(self) -> bool:
        return self.status == "FAILED"
    
    def to_dict(self) -> dict:

        return {
            'status': self.status,
            'result_data': self.result_data,
            'confidence': self.confidence,
            'reasoning': self.reasoning,
            'summary': self.summary,
            'suggested_abilities': self.suggested_abilities,
            'follow_up_tasks': self.follow_up_tasks,
            'error_message': self.error_message
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'SolverResult':

        return cls(
            status=data.get('status', ''),
            result_data=data.get('result_data', {}),
            confidence=data.get('confidence', 0.0),
            reasoning=data.get('reasoning', ''),
            summary=data.get('summary', ''),
            suggested_abilities=data.get('suggested_abilities'),
            follow_up_tasks=data.get('follow_up_tasks', []),
            error_message=data.get('error_message', '')
        )

class Task:
    def __init__(self, name, description, problem: Problem, task_type=None, params=None):
        self.name = name
        self.description = description
        self.problem = problem 
        self.task_type = task_type  
        self.params = params or {} 
        self.context = {} 
        self.final_result = None 
        self.failure_message = None 
        self.interrupt_reason = None  
        self.ability_call_history = []  
        self.dispatched_solver = None  
        self.status = "PENDING"  
        self.parent_task:Task = None  
        self.child_tasks = [] 
        self.creation_timestamp = self._get_timestamp()
        self.last_activity_timestamp = self._get_timestamp() 
        self.supervisor_feedback = {}  

    def _get_timestamp(self):
        import time
        return time.time()

    def add_child_task(self, child_task, purpose):
        child_task.parent_task = self
        self.child_tasks.append(child_task)
        self.last_activity_timestamp = self._get_timestamp()

    def interrupt(self, solver_result_cause_interruption:SolverResult):
        self.status = "INTERRUPTED"
        self.interrupt_reason = solver_result_cause_interruption
        self.last_activity_timestamp = self._get_timestamp()
    
    def resume(self):
        self.status = "RUNNING"
        self.last_activity_timestamp = self._get_timestamp()
    
    def complete(self, final_result:SolverResult):
        self.status = "COMPLETED"
        self.final_result = final_result
        self.last_activity_timestamp = self._get_timestamp()
    
    def fail(self, failure_result:SolverResult):
        self.status = "FAILED"
        self.failure_message = failure_result
        self.last_activity_timestamp = self._get_timestamp()
    
    def add_ability_call_history(self, solver_name: str, ability_name: str, ability_result: Any, description: str="", reason: str = ""):
        params = {}
        success = None
        error = None
        if isinstance(ability_result, dict):
            params = ability_result.get('parameters', {})
            success = ability_result.get('success')
            error = ability_result.get('error')

        ability_call_record = {
            'timestamp': self._get_timestamp(),
            'solver_name': solver_name,
            'ability_name': ability_name,
            'parameters': params,
            'success': success,
            'error': error,
            'ability_result': ability_result,
            'reason': reason,
            'description': description,
            'call_sequence': len(self.ability_call_history) + 1  
        }
        self.ability_call_history.append(ability_call_record)
        self.last_activity_timestamp = self._get_timestamp()
    
    def get_ability_call_count(self, ability_name: str = None, solver_name: str = None, only_success: bool = False) -> int:

        count = 0
        for record in self.ability_call_history:
            if ability_name and record.get('ability_name') != ability_name:
                continue
            if solver_name and record.get('solver_name') != solver_name:
                continue
            if only_success:
                succ = record.get('success')
                if succ is None:
                    ar = record.get('ability_result')
                    if isinstance(ar, dict):
                        succ = ar.get('success')
                if succ is not True:
                    continue
            count += 1
        return count

    def to_dict(self) -> dict:

        final_result_dict = None
        if self.final_result and hasattr(self.final_result, 'to_dict'):
            final_result_dict = self.final_result.to_dict()
        elif self.final_result:
            final_result_dict = self.final_result
        
        failure_message_dict = None
        if self.failure_message and hasattr(self.failure_message, 'to_dict'):
            failure_message_dict = self.failure_message.to_dict()
        elif self.failure_message:
            failure_message_dict = self.failure_message
            
        interrupt_reason_dict = None
        if self.interrupt_reason and hasattr(self.interrupt_reason, 'to_dict'):
            interrupt_reason_dict = self.interrupt_reason.to_dict()
        elif self.interrupt_reason:
            interrupt_reason_dict = self.interrupt_reason

        return {
            'name': self.name,
            'description': self.description,
            'problem': self.problem.to_dict() if self.problem else None,
            'task_type': self.task_type,
            'params': self.params,
            'context': self.context,
            'final_result': final_result_dict,
            'failure_message': failure_message_dict,
            'interrupt_reason': interrupt_reason_dict,
            'ability_call_history': self.ability_call_history,
            'status': self.status,
            'parent_task_name': self.parent_task.name if self.parent_task else None,
            'child_task_names': [child.name for child in self.child_tasks],
            'creation_timestamp': self.creation_timestamp,
            'last_activity_timestamp': self.last_activity_timestamp
        }
    
    def format_execution_history(self) -> str:

        if not self.child_tasks:
            return ""

        lines = []
        index = 1
        for child_task in self.child_tasks:
            child_name = getattr(child_task, 'name', 'Unknown')
            child_desc = getattr(child_task, 'description', '')
            status = getattr(child_task, 'status')
            dispatched_solver = getattr(child_task, 'dispatched_solver', 'Unknown')
            result_description = ''
            result_data = ''
            if hasattr(child_task, 'final_result') and child_task.final_result:
                result = child_task.final_result
                summary = getattr(result, 'summary', None)
                error_message = getattr(result, 'error_message', None)
                reasoning = getattr(result, 'reasoning', None)
                result_data = getattr(result, 'result_data', None)
                if summary:
                    result_description = summary
                elif error_message:
                    result_description = error_message
                elif reasoning:
                    result_description = reasoning
            elif hasattr(child_task, 'failure_message') and child_task.failure_message:
                result = child_task.failure_message
                error_message = getattr(result, 'error_message', None)
                reasoning = getattr(result, 'reasoning', None)
                if error_message:
                    result_description = error_message
                elif reasoning:
                    result_description = reasoning
            task_desc = child_desc or child_name

            lines.append(f" 子任务#{index}: {task_desc}")
            lines.append(f"   ├─ 处理者: {dispatched_solver}")
            lines.append(f"   ├─ 处理状态: {status}")

            if result_description:
                lines.append(f"   ├─ 结果描述: {result_description}")
            if result_data:
                lines.append(f"   └─ 结果数据: {result_data}")
            if not result_description and not result_data:
                lines.append(f"   └─ 处理结果: 无")
            if hasattr(child_task, 'child_tasks') and child_task.child_tasks:
                sub_history = child_task.format_execution_history()
                if sub_history.strip():
                    sub_lines = sub_history.split('\n')
                    for sub_line in sub_lines:
                        if sub_line.strip():  
                            lines.append(f"   {sub_line}")
                        else:
                            lines.append("")  

            lines.append("")  
            index += 1
        return '\n'.join(lines)

    def format_dispatch_history(self, max_records: int = 20) -> str:

        chain: List["Task"] = []
        cursor = self.parent_task
        while cursor is not None and len(chain) < max_records:
            chain.append(cursor)
            cursor = getattr(cursor, 'parent_task', None)

        if not chain:
            return "无"

        recent_chain = chain[:5]
        recent_chain.reverse() 
        
        header = "任务分发历史（最早 → 最近，最近5条）"
        blocks: List[str] = []
        for idx, task in enumerate(recent_chain, start=1):
            desc = getattr(task, 'description', '')
            solver = getattr(task, 'dispatched_solver', 'Unknown')
            follow_up_desc = ''
            if hasattr(task, 'interruption_reason') and task.interruption_reason:
                interruption_reason = task.interruption_reason
                if hasattr(interruption_reason, 'follow_up_tasks') and interruption_reason.follow_up_tasks:
                    follow_up_tasks = interruption_reason.follow_up_tasks
                    if hasattr(follow_up_tasks, 'description') and follow_up_tasks.description:
                        follow_up_desc = f"当前需求: {follow_up_tasks.description}"

            block = cleandoc(f"""\
                #{idx} 任务
                描述: {desc}
                分发给: {solver}
                {follow_up_desc}""")
            blocks.append(block.strip())

        return f"{header}\n\n" + "\n\n".join(blocks) if blocks else "无"


class Failure:
    def __init__(self, task: Task, result, description):
        self.task = task
        self.result = result
        self.description = description

class TaskStack:
    def __init__(self):
        self.stack = []
        self.failure_list = []
        self.success_list = []  

    def add(self, task: Task):
        self.stack.append(task)

    def pop(self):
        return self.stack.pop()

    def peek(self):
        if len(self.stack) == 0:
            return None
        return self.stack[-1]

    def __len__(self):
        return len(self.stack)

    def add_failure(self, failure: Failure):
        self.failure_list.append(failure)

    def add_success(self, task: Task, result):
        self.success_list.append({
            'task': task,
            'result': result,
            'timestamp': self._get_timestamp()
        })

    def _get_timestamp(self):
        import time
        return time.time()

class Result:
    def __init__(self, task: Task, result):
        self.task = task
        self.result = result

class AbilityCall:

    def __init__(self, ability_name: str, parameters: dict, description: str = ""):
        self.ability_name = ability_name
        self.parameters = parameters
        self.description = description
