from typing import Dict, Any, Optional
from inspect import cleandoc

from nail.utils.build_context import filter_llm_relevant_metadata
from nail.utils.simple_llm import SimpleLLM
from nail.utils.workflow_log import get_workflow_logger

from nail.utils.workflow_log import get_workspace_logger
logger = get_workspace_logger()

class _LLMPlanner:
    def __init__(self, task_planner=None, model=None):
        self.task_planner = task_planner
        self.llm = SimpleLLM(model=model, llm_character="planner")

    def generate_system_prompt(self) -> str:
        return cleandoc("""\
            你是一个智能任务规划师，负责全局统筹和任务规划。你的核心职责是根据初始任务目标和执行历史，动态管理任务清单，引导任务走在正确的解决轨道上。
            
            ## 核心职责
            - 分析问题描述，识别本质特征与需求，基于问题特征生成可能的任务类型及其关联性
            - 考虑任务间的依赖关系与执行顺序，分析任务进度与状态
            - 明确产出一个最推荐的任务类型与任务描述，解释推荐理由，并维护/更新全局待办清单（状态、优先级、依赖）
            - **重要**：如果当前solver是解决初始任务的solver，听取solver的需求并更新你的todo-list，不要自己生成任务
                        
            ## 可用任务类型
            
            1. **调用解析（CALL_RESOLUTION）**
               - 核心目标：解析各种调用语句，确定其具体归属
               - 典型场景：需要分析某个方法调用中被调用的目标方法的相关信息
               - 关键词：函数调用、方法调用、`self.func()`、cls()/cls.func()`、`super()`
            
            2. **类型解析与推断（TYPE_INFERENCE）**
               - 核心目标：推断或查找符号（如变量、参数、返回值、属性）的类型，并在多态场景下确定具体子类
               - 典型场景：沿调用链与赋值关系进行类型追溯、查找类型定义、解析导入语句
               - 关键词：类型、符号、参数、返回值、属性、子类、导入、定义
               
            3. **方法定义解析（FUNC_DEFINITION）**
               - 核心目标：找到某个方法的具体定义（非外部库）
               - 典型场景：知道某个方法的方法名以及所在文件/所属类，需要找到该方法的源代码等信息
               - 关键词：方法定义、方法签名、方法源代码
               
            4. **函数执行API（FUNC_EXECUTION）**
               - 核心目标：解析出一条涉及函数执行API的调用语句中，真正被指定执行的方法的具体信息
               - 典型场景：当前问题描述中提到这是和函数执行API相关的调用语句，需要解析其具体被执行的方法
               - 关键词：函数执行API
            
            ## 分析策略
            ## 待办清单构建
            - 目标：为整个问题的解决创建一个可执行的全局待办清单
            - 原则：原子、可执行、可验证；包含依赖与优先级；状态为`TODO|DOING|DONE|BLOCKED`
            - 顺序化要求：
              - 对涉及链式调用的任务，待办项必须严格按解析顺序排列，不得跳步；每项写明 `depends_on` 以保证前后约束清晰。
            
            ### 特殊要求
            - 若已存在全局待办清单（global_todo_list），基于当前的问题描述，更新清单中代办的状态与优先级，并选择一个待办项作为推荐任务
            - **重要**：如果发现初始任务中的方法调用为调用第三方库/标准库的API，不需要获得目标方法的定义，因为本身就无法获得外部库API的源代码
            
            ### 执行历史分析
            - **进度评估**：基于执行历史判断当前完成度和剩余工作量
            - **问题识别**：识别执行中的失败点、阻塞点和重复尝试，保证问题不会卡在某个不必要的问题或者已经解决的问题上
            - **效率优化**：避免重复工作，优化执行路径
            
            ### 动态调整机制
            - **优先级调整**：根据任务执行历史中的已知信息和每轮的问题描述，及时更新各任务进度，并重新排序任务
            - **状态更新**：根据执行结果实时更新任务状态（TODO→DOING→DONE）
            - **依赖管理**：分析调整任务间的依赖关系，解除阻塞

            ## 链式调用解析
            - 特征：`a.b.c().d()` 或 `obj.x.y().z` 或 `self.property.func()` 等多级访问/调用
            - 策略：
              - 从左至右逐段确认：先解析 `a|obj|self.property` 的类型 → `a.b|obj.x` 的属性/方法 → `a.b.c()` 的返回类型 → 后续段
              - 每一步的结论作为下一步的前置条件。
            - 待办清单约束：
              - 针对链式调用，按上述先后顺序生成待办项序列（在 `title` 中体现 Step 1...N）。
              - 每个待办项的 `depends_on` 指向前一步的 `title` ，形成明确的依赖链。
              - 推荐任务应选择序列中第一个 `DOING` 且其依赖已全部 `DONE` 的待办项；若存在阻塞则将其标记为 `BLOCKED` 并挑选下一个可执行项。
            
            ## 代办清单维护
            - 目标：保证问题解决的方向正确性以及效率
            - 原则：根据当前的问题描述以及元数据，更新代办清单的状态，如果发现代办需要获取的目标信息已经存在，则将代办状态设置为DONE
            - 顺序要求：
                **审查问题描述与元数据**，并遍历当前所有的任务，判断是否有状态为TODO的任务已经在问题描述中有结果了
                如果有，将该任务的状态设置为DONE，并更新其依赖的任务的状态为DONE
                发现清单中依赖已经全部 'DONE' 的代办项，且自身为 'BLOCK' 的代办，状态应该设置为 TODO
                对于序列中第一个 TODO 代办，将其状态设置为 DOING
            
            ## 输出格式
            严格按照以下JSON格式输出，无额外文本：
            ```json
            {
              "analysis": {
                "problem_features": ["<提取的关键特征>"],
                "complexity": "<LOW|MEDIUM|HIGH>",
                "dependencies": ["<可能的依赖关系>"],
                "progress_assessment": "<基于执行历史的进度评估>",
                "blocking_issues": ["<识别的阻塞问题>"]
              },
              "global_todo_list": [
                {
                  "title": "<待办项标题>",
                  "status": "<TODO|DOING|DONE|BLOCKED>",
                  "task_type": "<任务类型>",
                  "description": "<动作与目标>",
                  "priority": "<HIGH|MEDIUM|LOW>",
                  "depends_on": ["<其他待办项标题或任务类型>"],
                  "expected_outcome": "<验证任务完成的依据>"
                }
              ],
              "recommended_task": {
                "task_type": "<最推荐的任务类型>",
                "name": "<任务名称>",
                "description": "<任务描述>",
                "reason": "<推荐理由>"
              }
            }
            ```""")

    def generate_user_prompt(self, description, problem_metadata) -> str:
        todo_raw = getattr(self.task_planner, 'global_todo_list', []) if self.task_planner else []
        initial_task_history = ""
        if self.task_planner and self.task_planner.initial_task:
            initial_task_history = self.task_planner.initial_task.format_execution_history()

        header = cleandoc("""\
            问题描述：""")
        initial_task_section = ""
        if initial_task_history.strip():
            initial_task_section = cleandoc(f"""\
            
            ## 初始任务执行历史
            - 这是当前初始任务的完整执行历史，包含所有子任务的执行情况和结果
            - 请基于这些历史信息，判断当前任务进展，规划下一步行动
            {initial_task_history}""")

        footer = cleandoc(f"""\
            元数据: {problem_metadata}
            当前的TODO-List: {todo_raw}
            计划下一个立即任务，并维护/更新全局待办清单。""")

        return f"{header}\n{description}{initial_task_section}\n{footer}"

    def plan(self, problem: Any) -> Optional[dict]:
        try:
            description = getattr(problem, "description", "")
            problem_metadata = getattr(problem, "metadata", {})
            system_prompt = self.generate_system_prompt()
            user_prompt = self.generate_user_prompt(description, problem_metadata)

            reply = self.llm.chat_structured(system_prompt, user_prompt)
            from nail.utils.format_llm_out import get_dict_from_reply
            data = get_dict_from_reply(reply)
            if not isinstance(data, dict):
                logger.error(f"[Planner] LLM返回格式错误: {reply}")
                print(f"[Planner] LLM返回格式错误: {reply}")
                return None
            recommended_task = data.get("recommended_task", {})
            if recommended_task:
                task_type = recommended_task.get("task_type")
                name = recommended_task.get("name")
                planner_description = recommended_task.get("description")
                reason = recommended_task.get("reason", "")
            else:
                task_type = data.get("task_type")
                name = data.get("name")
                planner_description = data.get("description")
                reason = ""

            global_todo_list = data.get("global_todo_list", []) or []
            if self.task_planner:
                self.task_planner.global_todo_list = global_todo_list
                full_analysis = data.get("full_analysis", {}) or {}
            problem_metadata = getattr(problem, "metadata", {}) or {}
            params = filter_llm_relevant_metadata(problem_metadata)

            logger.log_planner_decision(
                task_type=task_type,
                planner_description=planner_description,
                reasoning=reason,
                todo_list=global_todo_list
            )
            
            return {
                "task_type": task_type,
                "name": name,
                "description": planner_description,
                "params": params,
                "reason": reason,
                "global_todo_list": global_todo_list,
                "full_analysis": data  
            }
        except Exception as e:
            logger.error(f"[Planner] 规划失败: {str(e)}")
            print(f"[Planner] 规划失败: {str(e)}")
            return None

    def update_todo_after_solver_completed(self, task, result) -> Optional[list]:

        try:
            if not self.task_planner:
                return None
            todo_list = getattr(self.task_planner, 'global_todo_list', [])

            initial_task_history = ""
            if self.task_planner.initial_task:
                initial_task_history = self.task_planner.initial_task.format_execution_history()
            completed_task_desc = getattr(task, 'description', '')
            completed_task_type = getattr(task, 'task_type', '')
            completed_solver = getattr(task, 'dispatched_solver', 'Unknown')
            result_summary = getattr(result, 'summary', '')
            result_reasoning = getattr(result, 'reasoning', '')

            system_prompt = cleandoc("""
                你是一个智能任务规划师，负责在子任务完成后维护/更新全局待办清单（global_todo_list）。
                规则：
                - 根据刚刚完成的子任务，定位并将对应的待办项标记为 DONE。
                - 若有依赖该项的后续待办，检查其依赖是否全部 DONE，若是则将其状态置为 TODO；队列中第一个可执行项可置为 DOING。
                - 若完成结果已覆盖某些代办项的目标（例如信息已获得），将这些代办项直接置为 DONE。
                - 保持清单的依赖关系、优先级字段的一致性与完整性。
                输出：严格 JSON，输出字段 global_todo_list（数组））。
            """)

            user_prompt = cleandoc(f"""
                ## 初始任务执行历史
                {initial_task_history}

                ## 当前完成的子任务
                - 任务类型: {completed_task_type}
                - 任务描述: {completed_task_desc}
                - 处理者: {completed_solver}
                - 结果摘要: {result_summary}
                - 结果推理: {result_reasoning}

                ## 原来todo-list
                {todo_list}

                请更新全局待办清单。
            """)

            reply = self.llm.chat_structured(system_prompt, user_prompt)
            from nail.utils.format_llm_out import get_dict_from_reply
            data = get_dict_from_reply(reply)
            if not isinstance(data, dict):
                logger.warning(f"[Planner] todo 更新阶段返回格式错误: {reply}")
                return None

            new_todo = data.get('global_todo_list', []) or []
            self.task_planner.global_todo_list = new_todo
            get_workflow_logger().log_planner_decision(
                task_type="TODO_UPDATE",
                planner_description="子任务完成后更新 todo-list",
                reasoning="根据完成任务与依赖关系自动维护全局清单",
                todo_list=new_todo
            )

            return new_todo
        except Exception as e:
            logger.error(f"[Planner] todo 更新失败: {str(e)}")
            print(f"[Planner] todo 更新失败: {str(e)}")
            return None

class LLMTaskPlanner:
    def __init__(self, task_planner=None, model=None):
        self.task_planner = task_planner
        self.llm = _LLMPlanner(task_planner=task_planner, model=model)

    def propose_next_task(self, problem: Any) -> Optional[dict]:
        return self.llm.plan(problem)

    def update_after_solver_completed(self, task, result) -> Optional[list]:

        return self.llm.update_todo_after_solver_completed(task, result)


