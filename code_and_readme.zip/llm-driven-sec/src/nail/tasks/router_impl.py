from typing import Dict, List, Optional
from nail.utils.simple_llm import SimpleLLM
from inspect import cleandoc
from nail.common_structure import Task
from nail.utils.workflow_log import get_workspace_logger

logger = get_workspace_logger()

class _LLMChooser:
    def __init__(self, model=None, solver_catalog: Optional[Dict[str, str]] = None):
        self.llm = SimpleLLM(model=model, llm_character="router")
        self.solver_catalog = solver_catalog or {}

    def _resolve_solver_class(self, solver_name: str):
        try:
            if solver_name not in self.solver_catalog:
                return None
            module_path, class_name = self.solver_catalog[solver_name].split(":")
            mod = __import__(module_path, fromlist=[class_name])
            return getattr(mod, class_name, None)
        except Exception:
            return None

    def _build_candidate_descriptions(self, candidates: List[str]) -> str:
        lines: List[str] = []
        for name in candidates:
            clazz = self._resolve_solver_class(name)
            if clazz:
                desc = clazz.router_description
                lines.append(str(desc).strip())
                continue
            lines.append(cleandoc(f"""\
            **{name}**
            - 处理范围：未知
            - 主要能力：未知""").strip())
        return "\n\n".join(lines)

    def generate_system_prompt(self, candidates: Optional[List[str]] = None) -> str:
        candidate_names = ', '.join(candidates) if candidates else '无'
        candidate_block = self._build_candidate_descriptions(candidates or [])

        header = cleandoc(f"""\
            你是一个智能任务路由器，负责为每个任务选择最合适的专业求解器。

            ## 核心职责
            - 分析任务特征和需求，匹配最适合的求解器
            - 考虑求解器的专业能力和协作关系
            - 基于任务上下文和历史信息做出最优决策
            - 确保任务分发的准确性和效率

            **重要**：请务必从下面的候选求解器中选择，禁止选择列表之外的求解器。

            ## 候选求解器能力概览""")

        footer = cleandoc("""\
            **链式调用识别特征**:
            - 任务描述中包含链式调用"a.b.…….c()"
            - 应该从前向后，先确定a的类型，再确定b()方法

            ### 求解器选择原则
            1. **专业匹配**: 选择最擅长处理当前问题类型的求解器
            2. **能力覆盖**: 确保求解器具备处理任务所需的工具和能力
            3. **协作效率**: 考虑求解器间的协作关系和信息传递
            4. **历史信息**: 考虑当前任务的分发历史和成功情况

            ### 特殊情况处理
            - **失败重试**: 基于失败原因选择替代求解器
            - **多解场景**: 选择最有可能成功的求解器
            - **链式调用**: 严格按照属性→方法的顺序处理
            
            ## 输出格式
            严格按照以下JSON格式输出，无额外文本：
            ```json
            {
            "solver": "<求解器名称>",
            "reason": "<选择理由，包含关键特征和决策依据>",
            "confidence": "<0.0-1.0，选择信心度>",
            "alternative_solvers": ["<备选求解器列表>"],
            "expected_collaboration": ["<可能需要协作的求解器>"]
            }
            ```

            ## 关键原则
            - 优先选择专业匹配度最高的求解器
            - 从可选的求解器列表中进行选择
            - 基于任务上下文和历史信息做出决策
            - 不允许从候选求解器之外选取
            """)

        return f"{header}\n{candidate_block}\n\n{footer}"

    def generate_user_prompt(self, task: Task) -> str:
        task_description = getattr(task, 'description', '')
        task_type = getattr(task, 'task_type', '')
        task_name = getattr(task, 'name', '')
        parent_task = getattr(task, 'parent_task')
        problem = getattr(task, 'problem', None)
        problem_description = ""
        if problem:
            problem_description = getattr(problem, 'description', '')
        dispatch_history_info = task.format_dispatch_history() if parent_task else "无"
        parent_execution_history = parent_task.format_execution_history() if parent_task else "无"
        sec1 = cleandoc(f"""\
            ## 任务信息
            **任务名称**: {task_name}
            **任务类型**: {task_type}
            **任务描述**: {task_description}

            ## 问题信息
            **问题描述**:""")

        sec2 = cleandoc(f"""\
            ## 分发历史
            - 请你吸取分发历史的经验，避免重复将同一任务目标分发到相同solver，导致无限递归
            - **处理策略**：如果发现递归链，尝试分发到其他Solver解决，避免继续递归""")

        sec3 = cleandoc("""\
            ## 父任务执行历史
            - 避免多次分发到失败solver""")

        sec4 = cleandoc("""\
            ## 路由要求
            基于以上分析，请选择最合适的求解器。考虑：
            1. 任务特征与求解器专业能力的匹配度
            2. 求解器的工具能力和协作关系
            3. 历史执行经验和失败教训
            4. 任务依赖关系和执行效率
            5. 链式调用处理策略
            6. 避免重复分发相同语义问题到同一solver

            请输出JSON格式的路由决策结果。""")

        return f"{sec1}\n{problem_description}\n\n{sec2}\n{dispatch_history_info}\n\n{sec3}\n{parent_execution_history}\n\n{sec4}"

    def choose(self, task, candidates=None) -> Optional[str]:
        try:
            system_prompt = self.generate_system_prompt(candidates)
            user_prompt = self.generate_user_prompt(task)
            reply = self.llm.chat_structured(system_prompt, user_prompt)
            
            from nail.utils.format_llm_out import get_dict_from_reply
            llm_formatted_output = get_dict_from_reply(reply)
            solver = llm_formatted_output.get("solver")
            reason = llm_formatted_output.get("reason", "")
            if solver and isinstance(solver, str):
                logger.log_router_dispatch(
                    task_desc=task.description,
                    solver_name=solver,
                    reasoning=reason,
                    candidates=candidates
                )
            
            return solver if isinstance(solver, str) else None
        except Exception as e:
            print(f"[Router] 选择solver报错: {str(e)}")
            return None

class LLMTaskRouter:
    def __init__(self, model=None):
        self.last_decision = None  
        self.solver_catalog = {
            "CodeComprehensionSolver": "nail.solvers.code_comprehension_solver:CodeComprehensionSolver",
            "DecoratorSolver": "nail.solvers.decorator_solver:DecoratorSolver",
            "ExternLibSolver": "nail.solvers.extern_lib_solver:ExternLibSolver",
            "HierarchySolver": "nail.solvers.hierarchy_solver:HierarchySolver",
            "ImportSolver": "nail.solvers.import_solver:ImportSolver",
            "MethodCallSolver": "nail.solvers.method_call_solver:MethodCallSolver",
            "MethodFinderSolver": "nail.solvers.method_finder_solver:MethodFinderSolver",
            "FunctionExecutionSolver": "nail.solvers.function_execution_solver:FunctionExecutionSolver",
            "ParameterTypeSolver": "nail.solvers.parameter_type_solver:ParameterTypeSolver",
            "ReturnTypeSolver": "nail.solvers.return_type_solver:ReturnTypeSolver",
            "SelfClsFuncSolver": "nail.solvers.self_cls_func_solver:SelfClsFuncSolver",
            "SelfClsPropTypeSolver": "nail.solvers.self_cls_prop_type_solver:SelfClsPropTypeSolver",
            "SuperTypeSolver": "nail.solvers.super_type_solver:SuperTypeSolver",
            "SymbolTypeSolver": "nail.solvers.symbol_type_solver:SymbolTypeSolver",
            "WithSolver": "nail.solvers.with_solver:WithSolver"
        }
        self.llm = _LLMChooser(model=model, solver_catalog=self.solver_catalog)

    def resolve_solver_name(self, task:Task) -> Optional[str]:
        if task.dispatched_solver:
            logger.log_router_dispatch(
                task_desc=getattr(task, 'description', ''),
                solver_name=task.dispatched_solver,
                reasoning="该task中已经有dispatched_solver，直接分发",
                candidates=None
            )
            return task.dispatched_solver
        candidates = self._get_candidate_solvers(task)
        if not candidates:
            return None

        if self.llm is not None:
            solver = self.llm.choose(task, candidates)
            if solver in candidates:
                self.last_decision = {
                    'solver': solver,
                    'method': 'LLM',
                    'candidates': candidates,
                    'task_info': {
                        'name': getattr(task, "name", ""),
                        'description': getattr(task, "description", ""),
                        'task_type': getattr(task, "task_type", ""),
                        'problem_kind': getattr(getattr(task, "problem", None), "kind", ""),
                        'params': getattr(task, "params", {}) or {}
                    }
                }
                return solver
        logger.log_router_dispatch(
            task_desc=getattr(task, 'description', ''),
            solver_name="CodeComprehensionSolver",
            reasoning="！！！兜底分发CodeComprehensionSolver！！！",
            candidates=candidates
        )
        return "CodeComprehensionSolver"

    def _get_candidate_solvers(self, task) -> List[str]:
        parent_task = getattr(task, "parent_task", None)
        if not parent_task:
            return ["MethodCallSolver", "SelfClsFuncSolver"]
        
        parent_solver_name = getattr(parent_task, 'dispatched_solver', None)
        if not parent_solver_name:
            return list(self.solver_catalog.keys())

        try:
            if parent_solver_name in self.solver_catalog:
                module_path, parent_class_name = self.solver_catalog[parent_solver_name].split(":")
                mod = __import__(module_path, fromlist=[parent_class_name])
                parent_solver_clazz = getattr(mod, parent_class_name, None)
                if parent_solver_clazz:
                    available_solvers = getattr(parent_solver_clazz, 'available_solvers', [])
                    if '*' in available_solvers:
                        return list(self.solver_catalog.keys())
                    available_solvers = [s for s in available_solvers if s in self.solver_catalog]
                    if not available_solvers:
                        return []
                    called_solvers = set()
                    
                    def collect_solvers_from_task(current_task):
                        if hasattr(current_task, 'dispatched_solver') and current_task.dispatched_solver:
                            called_solvers.add(current_task.dispatched_solver)
                        for child in getattr(current_task, 'child_tasks', []):
                            collect_solvers_from_task(child)
                    collect_solvers_from_task(parent_task)
                    valid_solvers = []
                    for available_solver_name in available_solvers:
                        solver_module_path, available_solver_class_name = self.solver_catalog[available_solver_name].split(":")
                        solver_mod = __import__(solver_module_path, fromlist=[available_solver_class_name])
                        available_solver_clazz = getattr(solver_mod, available_solver_class_name, None)
                        if available_solver_clazz:
                            dependent_solvers = getattr(available_solver_clazz, 'dependent_solvers', [])
                            if not dependent_solvers or all(dep in called_solvers for dep in dependent_solvers):
                                valid_solvers.append(available_solver_name)

                    if valid_solvers:
                        return valid_solvers

            print(f"[Router] : _get_candidate_solvers 未获取到可用的candidate. parent_solver_name: {parent_solver_name} & available_solvers: {available_solvers}")
            return []

        except Exception as e:
            print(f"[Router] : _get_candidate_solvers 获取失败————{str(e)}")
            return list(self.solver_catalog.keys())

    def get_last_decision(self) -> Optional[dict]:
        return self.last_decision

    def instantiate(self, solver_name: str, lian=None):
        if solver_name not in self.solver_catalog:
            return None
        module_path, class_name = self.solver_catalog[solver_name].split(":")
        mod = __import__(module_path, fromlist=[class_name])
        clazz = getattr(mod, class_name, None)
        return clazz(lian) if clazz else None
