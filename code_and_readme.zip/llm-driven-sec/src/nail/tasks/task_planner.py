from nail.common_structure import Problem


class TaskPlanner:
    def __init__(self, task_stack=None, lian=None):
        self.task_stack = task_stack
        self.lian = lian
        from nail.tasks.planner_impl import LLMTaskPlanner
        self.llm_planner = LLMTaskPlanner(self)
        self.initial_task = None
        self.global_todo_list = []

    def plan(self, problem):
        from nail.common_structure import Task

        kind = getattr(problem, 'kind', None)
        metadata = getattr(problem, 'metadata', {})
        try:
            proposed = self.llm_planner.propose_next_task(problem)
            if isinstance(proposed, dict) and 'task_type' in proposed:
                params = proposed.get('params') or {}
                params = self._enrich_task_params_with_context(params, problem)
                
                task = Task(
                    name=proposed.get('name', 'LLM Task'),
                    description=proposed.get('description', ''),
                    problem=problem,
                    task_type=proposed.get('task_type'),
                    params=params
                )
                return task
        except Exception as e:
            print(f"TaskPlanner.plan报错：{e}")
        if kind == 'UnresolvedMethodCall':
            params = {
                'call_site': metadata.get('call_site'),
                'receiver_expr': metadata.get('receiver_expr'),
                'callee_expr': metadata.get('callee_expr'),
                'source_context': metadata.get('source_context')
            }
            params = self._enrich_task_params_with_context(params, problem)
            return Task(
                name='Resolve Method Call',
                description=f'{metadata.get("call_name")}解析失败，用method_call_solver解析出调用目标',
                problem=problem,
                task_type='METHOD_CALL',
                params=params
            )

        if kind == 'ImportResolutionNeeded':
            params = {
                'symbol_name': metadata.get('symbol_name'),
                'file_path': metadata.get('file_path'),
                'import_stmt': metadata.get('import_stmt')
            }
            params = self._enrich_task_params_with_context(params, problem)
            return Task(
                name='Resolve Import Type',
                description=f'{metadata.get("symbol_name")}来自import语句{metadata.get("import_stmt")}，用import_solver解析出具体类型名',
                problem=problem,
                task_type='IMPORT_RESOLUTION',
                params=params
            )
        params = self._enrich_task_params_with_context({}, problem)
        return Task(
            name='Any',
            description=f'请你根据当前问题描述{problem.description}和所有的solver，选择一个最合适的solver',
            problem=problem,
            task_type='Any',
            params=params
        )

    def _enrich_task_params_with_context(self, params: dict, problem: Problem) -> dict:

        breakpoint_context = problem.get_breakpoint_context()
        if not breakpoint_context:
            return params
        enriched_params = params.copy()
        context_mappings = {
            'class_name': 'class_name',
            'file_path': 'file_path', 
            'call_site': 'call_site',
            'call_site_code': 'call_site_code',
            'symbol_name': 'symbol_name',
            'callee_name': 'callee_name',
            'receiver_expr': 'receiver_expr',
            'language': 'language'
        }
        for param_key, context_key in context_mappings.items():
            if param_key not in enriched_params and context_key in breakpoint_context:
                enriched_params[param_key] = breakpoint_context[context_key]
        
        return enriched_params
