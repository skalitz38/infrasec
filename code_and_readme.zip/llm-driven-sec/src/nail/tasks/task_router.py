from nail.utils.build_context import filter_llm_relevant_metadata
from lian.core.resolver import Resolver
from lian.util.loader import Loader
from nail.common_structure import Task, Problem, SolverResult
from nail.common_structure import TaskStack
from nail.tasks.task_planner import TaskPlanner
from nail.tasks.task_executor import TaskExecutor
from nail.config.config import INITIAL_TASK_MAX_TIMES

from nail.utils.workflow_log import get_workspace_logger
logger = get_workspace_logger()


class TaskRouter:
    def __init__(self, lian=None):
        self.lian = lian
        if self.lian:
            self.loader:Loader = self.lian.loader
            self.resolver:Resolver = self.lian.resolver
        self.task_stack = TaskStack()
        self.task_planner = TaskPlanner(task_stack=self.task_stack, lian=lian)
        self.task_executor = TaskExecutor(task_stack=self.task_stack, lian=lian)
        self.task_stack.planner = self.task_planner

    def reset(self):
        self.task_stack = TaskStack()
        self.task_planner = TaskPlanner(task_stack=self.task_stack, lian=self.lian)
        self.task_executor = TaskExecutor(task_stack=self.task_stack, lian=self.lian)
        self.task_stack.planner = self.task_planner

    def run(self, problem):
        logger.log_workflow_start(problem.description)
        initial_call_task = generate_initial_call_task(problem)
        initial_call_task.status = "RUNNING"
        self.task_stack.add(initial_call_task)
        self.task_planner.initial_task = initial_call_task
        final_result = None
        
        initial_task_retry_count = 0

        while len(self.task_stack) != 0:
            current_task = self.task_stack.peek()
            result = self.task_executor.dispatch_to_solver(current_task)
            decision = self.task_executor.result_determination(current_task, result)
            
            if decision == 'DONE':
                finished_task = self.task_stack.pop()
                if len(self.task_stack) == 0:
                    if result.status == 'FAILED' and not finished_task.parent_task:
                        if initial_task_retry_count >= INITIAL_TASK_MAX_TIMES:
                            logger.log_workflow_end(f"初始任务失败次数超过限制({INITIAL_TASK_MAX_TIMES})，需要兜底逻辑")
                            final_result = SolverResult(
                                status='FAILED',
                                summary=f"初始任务重试{initial_task_retry_count}次后仍然失败，需要兜底逻辑",
                                reasoning=f"任务'{finished_task.name}'在{INITIAL_TASK_MAX_TIMES}次重试后仍然失败"
                            )
                            final_result.need_fallback = True
                            return final_result
                        else:
                            initial_task_retry_count += 1
                            finished_task.dispatched_solver = None
                            finished_task.status = "PENDING"
                            self.task_stack.add(finished_task)
                            logger.log_workflow_end(f"初始任务失败，第{initial_task_retry_count}次重试")
                            continue
                    final_result = result
                    break
        final_summary = ""
        if final_result and hasattr(final_result, 'summary'):
            final_summary = final_result.summary
        logger.log_workflow_end(final_summary)
        
        return final_result

def generate_initial_call_task(problem:Problem):
    params = filter_llm_relevant_metadata(problem.metadata)
    task = Task(
        description=problem.description,
        params=params,
        task_type="CALL_RESOLUTION",
        name=f"初始任务：解析{params.get('callee_name', '未知方法')}具体调用的目标方法以及方法定义",
        problem=problem
    )
    return task
