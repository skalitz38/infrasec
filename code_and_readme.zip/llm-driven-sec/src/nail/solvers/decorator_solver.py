
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class DecoratorSolver(SolverTemplate):

    available_solvers = []
    router_description = cleandoc("""\
        **DecoratorSolver** - 装饰器调用解析专家
        - **专业领域**: 装饰器调用中实际调用方法所属的类名与方法名
        - **核心能力**: 装饰器调用解析
        - **适用场景**: 装饰器调用中包含上下文管理协议的调用
        - **协作关系**: 需要装饰器的上下文管理协议信息""")
    
    def _init_solver(self):
        
        self.domain = "处理被@修饰器装饰的方法调用问题"
        self.capabilities = cleandoc("""\
            给定一个@修饰器修饰过后的方法源代码
            - 确定该@修饰器的语义，并根据可协作Solver，分发为子问题""")
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：获取修饰器方法源代码
            **强制工具调用**：
            - **必须执行**：如果当前上下文中没有@修饰器修饰过后的方法的源代码，则调用get_method_code_in_container获取方法的源代码
            - **验证要求**：必须获得明确的方法源代码，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用get_method_code_in_container，获得方法源代码：[具体源代码]"
            
            ### 第二步：分析修饰器语义
            **修饰器语义分析**：
            - **修饰器识别**：识别@修饰器的类型和功能
            - **语义总结**：总结@修饰器的语义和作用
            - **显式声明**：在reasoning中明确记录"分析修饰器语义：[具体语义分析]"
            
            ### 第三步：问题分发分析
            **问题分发逻辑**：
            - **问题识别**：识别当前问题需要什么类型的处理
            - **Solver匹配**：分析需要哪个Solver来处理当前问题
            - **问题总结**：总结当前问题的性质和需求
            - **显式声明**：在reasoning中记录"问题分发分析：[具体分析结果]"
            
            ### 第四步：结果自检与输出
            **自检清单**：
            1. 是否调用了get_method_code_in_container？获得了什么方法源代码？
            2. 是否分析了修饰器语义？语义是什么？
            3. 是否进行了问题分发分析？分析结果是什么？
            4. 推断依据是否充分？
            5. 每个结论都有明确的依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功分析修饰器语义且信息完整时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **NEEDS_FOLLOWUP**：当遇到无法解决的问题时，必须详细描述问题场景
            - **FAILED**：当遇到无法处理的情况时，必须详细描述问题场景""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于修饰器分析的语义识别总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)get_method_code_in_container调用结果 2)修饰器语义分析过程 3)问题分发分析过程 4)推断依据 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "semantic": "@修饰符的语义"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "get_method_code_in_container", 
                        "parameters": { "method_name": "方法名", "container_identifier": "容器名", "container_type": "class|module|package" }, 
                        "description": "获取方法源代码",
                        "reason": "需要获取方法源代码进行修饰器分析"
                    }
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_self_cls_result  
        self.post_processor = self._post_process_self_cls_result  
    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["field_name", "class_name", "current_file"]
        return all(param in task.params for param in required_params)
    
    def _validate_self_cls_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["type"]
        return all(field in result_data for field in required_fields)
    
    def _post_process_self_cls_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
