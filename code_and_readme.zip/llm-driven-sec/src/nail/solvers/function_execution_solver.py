
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult, AbilityCall
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config

from inspect import cleandoc

class FunctionExecutionSolver(SolverTemplate):

    available_solvers = ['MethodCallSolver','SelfClsFuncSolver']
    dependent_solvers = ["ExternLibSolver","ImportSolver"]

    router_description = cleandoc("""\
        **FunctionExecutionSolver** - 函数执行API专家
        - **专业领域**: 涉及函数执行API的语义映射
        - **核心能力**: 函数执行API知识推理、函数指针参数传递分析、实际调用方法确定
        - **适用场景**: 涉及执行用户指定函数的API调用
    """)

    def _init_solver(self):
        self.domain = "函数执行API语义解析与目标方法识别"
        self.capabilities = "函数执行API识别、API语义分析、函数执行调用语句解析、执行语义识别"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：分析函数执行API调用语句结构
            **调用语句解析**：
            - **输入分析**：分析当前调用点涉及的函数执行API调用语句
            - **语句结构识别**：
              - **API调用识别**：识别函数执行API调用（如threading.Thread、asyncio.create_task、contextvars.Context.run等）
              - **参数分析**：分析API调用的参数，特别是目标函数参数
              - **调用位置**：记录调用位置信息
            - **显式声明**：在reasoning中明确记录"解析函数执行API调用语句：[具体调用语句]，API类型：[具体API]，参数：[具体参数]"
            
            ### 第二步：识别函数执行API类型
            **API类型识别**：
            - **API识别**：根据API调用识别涉及的函数执行API
              - **多线程API**：threading.Thread、_thread等
              - **异步API**：asyncio.create_task、asyncio.run等
              - **多进程API**：multiprocessing.Process、concurrent.futures等
              - **上下文API**：contextvars.Context.run等
              - **其他函数执行API**：具有执行用户指定函数语义的API
            - **API语义分析**：分析当前API的语义和用途
            - **显式声明**：在reasoning中明确记录"识别函数执行API：[具体API名]，API语义：[具体语义]"
            
            ### 第三步：推断实际调用的目标方法
            **目标方法推断**：
            - **参数传递分析**：分析通过参数形式传递的目标方法
              - **直接传递**：target=function_name、func=function_name
              - **间接传递**：通过args、kwargs传递
              - **方法引用**：self.method_name、cls.method_name
            - **方法识别**：根据API语义推断**实际被指定执行的函数**
            - **显式声明**：在reasoning中明确记录"推断实际调用方法：[具体方法名]，推断依据：[具体依据]"
            
            ### 第四步：检查任务历史中的方法信息
            **历史信息检查**：
            - **任务执行历史检查**：检查任务执行历史中是否已有其他Solver返回的目标方法详细信息
                - **信息完整性检查**：检查是否包含container_type、container_identifier、method_name、method_desc、method_signature、method_location
                - **决策**：如果信息完整，直接使用历史结果，返回COMPLETED
                - **显式声明**：在reasoning中记录"使用历史方法信息：[具体方法信息]"
              
              - **信息不完整**：如果历史信息不完整或不存在
                - **问题描述要求**：详细描述当前遇到的问题场景和需求
                - **必须包含**：
                  - 当前函数执行API的调用语句
                  - 推断出的目标方法名
                  - 缺少什么关键信息（方法定义位置、方法签名等）
                  - 这个问题的性质（方法调用解析问题）
                  - 需要什么帮助（解析这个被执行的函数详细信息）
                - **显式声明**：在reasoning中详细记录"需要解析目标方法详细信息，问题描述：[详细问题场景]"
            
            ### 第五步：结果自检与输出
            **自检清单**：
            1. 是否正确解析了函数执行API调用语句结构？
            2. 是否识别了函数执行API类型和语义？
            3. 是否推断出了实际调用的目标方法？
            4. 是否检查了任务历史中的方法信息？
            5. 如果历史信息完整，是否使用了历史结果？
            6. 如果历史信息不完整，是否详细描述了问题场景和需求？
            7. 每个结论都有明确的依据吗？
            
            **输出条件**：
            - **COMPLETED**：当任务历史中有完整的目标方法信息时
            - **NEEDS_FOLLOWUP**：当需要解析目标方法详细信息时，必须详细描述问题场景和需求
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **FAILED**：当遇到无法处理的情况时，必须详细描述问题场景""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED(任务成功)|FAILED(任务失败)",
                "confidence": 0.0 - 1.0,
                "summary": "基于函数执行API语义分析的目标方法识别总结，或详细描述遇到的问题场景和需求",
                "reasoning": "必须包含：1)函数执行API调用语句解析 2)API类型识别和语义分析 3)目标方法推断过程 4)任务历史信息检查 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "description": "该函数执行API的解释和描述，强调这是一个函数执行API，实际调用的是这个方法",
                    "container_type": "目标方法所属的容器类型：class|module|package",
                    "container_identifier": "目标方法所属的容器名称：类名/模块绝对路径/包绝对路径",
                    "method_name": "实际被执行的函数名"
                },
                "suggested_abilities": [ { "ability_name": "", "parameters": { }, "description": "" } ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题、需求或困难", 
                    "metadata": { 
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析",
                        "help_needed": "需要什么帮助（解析这个被指定执行的函数详细信息）"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_function_execution_result  
        self.post_processor = self._post_process_function_execution_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["symbol_name", "import_stmt"]
        return all(param in task.params for param in required_params)
    
    def _validate_function_execution_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["target"]
        return all(field in result_data for field in required_fields)
    
    def _post_process_function_execution_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
