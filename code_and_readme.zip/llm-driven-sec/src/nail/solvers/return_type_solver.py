
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult, AbilityCall
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class ReturnTypeSolver(SolverTemplate):
    available_solvers = ["MethodCallSolver","MethodFinderSolver", "SelfClsFuncSolver", "SymbolTypeSolver", "ImportSolver"]
    router_description = cleandoc("""\
        **ReturnTypeSolver** - 返回值类型判断专家
        - **专业领域**: 解析方法返回值的具体类型信息
        - **核心能力**: 判断该方法返回值的具体类型，解答"该方法的返回值是什么类型？"
        - **适用场景**: a = func()/self.func()/obj.func() 需要确定a的类型
    """)
    
    def _init_solver(self):
        self.domain = "判断方法返回值的类型"
        self.capabilities = "分析在当前调用点 a = func()/a, b = func() 中，func 的返回值给赋给 a 什么类型的数据"

        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            **重要！**：如果已经知道方法来源，直接跳到第三步

            ### 第一步：判断方法来源
            **强制工具调用**：
            - **必须执行**：调用find_last_define_of_symbol查找方法定义（如果是a.func()类型的调用，symbol应该为a；如果为func()，symbol应该为func)
            - **工具要求**：在传递symbol_name时，如果碰到a.b.c.d()的形似链式调用的情况，应尝试"a"、"a.b"、"a.b.c"、"a.b.c.d"作为参数
            - **验证要求**：必须获得明确的方法定义来源，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用find_last_define_of_symbol，获得方法来源：[方法定义来源]"
            
            ### 第二步：判断任务是否超出边界
            **定义来源分析**：
            - **import来源**：如果该方法定义来自于import
              - 如果来自import语句，则需要其他solver帮助(NEEDS_FOLLOWUP)，获取import的具体来源
              - **问题描述要求**：详细描述当前遇到的问题场景和困难
              - **必须包含**：
                - 当前方法名是什么
                - 该方法来自哪个import语句
                - 缺少什么关键信息（方法定义所在文件、方法实现等）
                - 这个问题的性质（是导入解析问题、方法查找问题、还是其他问题）
              - **显式声明**：在reasoning中详细记录"方法来自import，问题描述：[详细问题场景]"
            
            - **当前文件定义**：如果方法定义就在当前文件中
              - **决策**：继续第三步，获取方法源代码
              - **显式声明**：在reasoning中记录"方法定义在当前文件中，继续获取源代码"
            
            ### 第三步：获取方法源代码
            **强制工具调用**：
            - **必须执行**：调用get_method_code_in_container获取func的源代码
            - **验证要求**：必须获得明确的方法源代码，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用get_method_code_in_container，获得方法源代码：[具体源代码]"
            
            ### 第四步：分析返回点
            **返回点分析逻辑**：
            - **返回点识别**：在func的源代码中，查看所有可能的返回点
              - **return语句**：直接返回语句
              - **yield语句**：生成器返回
            - **显式声明**：在reasoning中明确记录"分析返回点：[具体返回点列表]"
            
            ### 第五步：确定返回值类型
            **返回值类型推断**：
            - **接收变量分析**：a作为接收的返回点，a是返回值中第几个值？
            - **类型推断**：结合返回点分析，推断a的具体类型
            - **显式声明**：在reasoning中明确记录"推断返回值类型：[具体类型]，依据：[推断依据]"
            
            ### 第六步：结果自检与输出
            **自检清单**：
            1. 是否调用了find_last_define_of_symbol工具获取了方法的定义？
            2. 是否分析了方法定义来源？来源是什么？
            3. 如果方法在当前文件中，是否调用了get_method_code_in_container？
            4. 是否分析了所有返回点？返回点有哪些？
            5. 是否确定了返回值类型？推断依据是什么？
            6. 如果遇到问题，是否详尽地描述了问题场景？
            7. 每个结论都有明确的工具调用依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功推断出返回值类型且信息完整时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **NEEDS_FOLLOWUP**：当遇到无法解决的问题时，必须详细描述问题场景
            - **FAILED**：当遇到无法处理的情况时，必须详细描述问题场景""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于方法源代码分析的返回值类型推断总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)find_last_define_of_symbol调用结果 2)方法定义来源分析 3)get_method_code_in_container调用结果 4)返回点分析过程 5)返回值类型推断依据 6)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "type": "a的类型"
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "find_last_define_of_symbol", 
                        "parameters": { "symbol_name": "方法名" }, 
                        "description": "查找方法定义",
                        "reason": "需要获取方法定义进行分析"
                    },
                    { 
                        "ability_name": "get_method_code_in_container", 
                        "parameters": { "method_name": "方法名", "container_identifier": "容器名", "container_type": "class|module|package" }, 
                        "description": "获取方法源代码",
                        "reason": "需要获取方法源代码进行返回点分析"
                    }
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_return_type_result  
        self.post_processor = self._post_process_return_type_result  

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["method_source_codes"]
        return all(param in task.params for param in required_params)
    
    def _validate_return_type_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["type"]
        return all(field in result_data for field in required_fields)
    
    def _post_process_return_type_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
