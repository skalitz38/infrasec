
import os
import re
from textwrap import dedent
from typing import Dict, Any

from nail.common_structure import Problem, Task
from nail.utils.build_context import concat_source_code
from lian.config.constants import LIAN_SYMBOL_KIND, IMPORT_OPERATION
from lian.core.resolver import Resolver
from lian.common_structs import ComputeFrame
from lian.util import util
from lian.util.loader import Loader


def get_possible_sources_of_key(params: Dict[str, Any]) -> str:
    parameters_from_llm = params.get("parameters_from_llm",{})
    symbol_name = parameters_from_llm.get("symbol_name", "")
    validate_messages = _validate_name(symbol_name)
    loader:Loader = params.get("loader")
    resolver: Resolver = params.get("resolver")

    task: Task = params.get("task")
    import_stmts = task.context.get("import_stmts", {}) or task.parent_task.context.get("import_stmts", {})
    file_path = task.params.get("file_path", "")
    import_analysis_results = [] 

    if util.is_available(import_stmts):
        for import_stmt_id in import_stmts:
            import_stmt = loader.convert_stmt_id_to_stmt(import_stmt_id)
            if import_stmt.operation not in IMPORT_OPERATION:
                continue

            import_stmt_src_code = loader.get_stmt_source_code_with_comment(import_stmt_id)
            if all(symbol_name not in line for line in import_stmt_src_code):
                continue

            key_name = import_stmt.name if import_stmt.operation != "from_import_stmt" else (import_stmt.source.split('.')[-1] if import_stmt.source and '.' in import_stmt.source else import_stmt.source)
            actual_symbol_name = key_name if key_name != symbol_name else symbol_name

            source_analysis = _find_imported_py_files_with_key(loader, resolver, actual_symbol_name)

            import_analysis_results.append({
                'import_stmt': import_stmt_src_code,
                'actual_symbol_name': actual_symbol_name,
                'source_analysis': source_analysis
            })

    if util.is_empty(import_analysis_results):
        if validate_messages:
            return validate_messages
        note = f"-**注意**:当前文件{file_path}中未找到找到导入内容为{symbol_name}的import语句。现在仍然在项目内搜索{symbol_name}可能的来源，但在使用该结果前请你仔细判断结果可用性"
        source_analysis = _find_imported_py_files_with_key(loader, resolver, symbol_name)
        
        result_lines = [note]
        result_lines.append("")
        result_lines.append(f"**可能来源**:")
        
        for source_type, files in source_analysis.items():
            if files:
                result_lines.append(f"- {source_type}: {', '.join(files)}")
            else:
                result_lines.append(f"- {source_type}: 无")
        
        return '\n'.join(result_lines)
    

    result_lines = [f"symbol '{symbol_name}' 的import分析结果：\n"]
    
    for i, analysis in enumerate(import_analysis_results, 1):
        result_lines.append(f"### Import语句 {i}:")
        result_lines.append(f"```python")
        result_lines.append(f"{analysis['import_stmt']}")
        result_lines.append(f"```")
        result_lines.append(f"**被导入的真正symbol名**: `{analysis['actual_symbol_name']}`")
        result_lines.append(f"**可能来源**:")
        
        for source_type, files in analysis['source_analysis'].items():
            if files:
                result_lines.append(f"- {source_type}: {', '.join(files)}")
            else:
                result_lines.append(f"- {source_type}: 无")
        
        result_lines.append("")  
    
    return '\n'.join(result_lines)

def find_last_define_of_symbol(params: Dict[str, Any]) -> Any:
    loader:Loader = params.get("loader")
    resolver: Resolver = params.get("resolver")

    parameters_from_llm = params.get("parameters_from_llm",{})
    symbol_name = parameters_from_llm.get("symbol_name", "")

    if not symbol_name:
        return f"调用find_last_define_of_symbol失败：给定的参数symbol_name为空"
    
    if validation_message := _validate_name(symbol_name, "symbol_name"):
        def is_dotted_format(s):

            pattern = r'^[a-zA-Z_][a-zA-Z0-9_]*(\.[a-zA-Z_][a-zA-Z0-9_]*)*$'
            return re.fullmatch(pattern, s) is not None
        if is_dotted_format(symbol_name):
            symbol_name = symbol_name.replace('.', '_')
        else:
            return validation_message

    task = params.get("task")
    breakpoint_context = Problem.get_breakpoint_context()

    frame = task.context["frame"] if task.context.get("frame", None) else breakpoint_context.get("frame")
    unit_id = task.context["unit_id"] if task.context.get("unit_id", None) else breakpoint_context.get("unit_id")
    stmt_id = task.context["stmt_id"] if task.context.get("stmt_id", None) else breakpoint_context.get("stmt_id")

    if not (frame and unit_id and stmt_id):
        return f"没有找到 {symbol_name} 的定义, frame/unit_id/stmt_id为空"

    try:
        def_result = _find_symbol_def_stmt_by_symbol_name(loader, resolver, symbol_name=symbol_name, frame=frame,
                                                         unit_id=unit_id, stmt_id=stmt_id)
        def_stmts = def_result['stmt_ids']
        is_import = def_result['is_import']
        source_unit_id = def_result['source_unit_id']
        source_unit_path = loader.convert_unit_id_to_unit_path(source_unit_id) if source_unit_id != -1 else loader.convert_unit_id_to_unit_path(unit_id)
        
        if (util.is_empty(def_stmts) or def_stmts == {-1}):
            if validation_message:
                return validation_message
            return f"没有找到 {symbol_name} 的定义"
        if validation_message and not is_import:
            return validation_message

        task.context["source_unit_id"] = source_unit_id
        task.context["source_unit_path"] = source_unit_path

        if is_import and len(def_stmts) == 1:
            def_stmt_id = next(iter(def_stmts))
            if source_unit_id == -1:
                import_info = f"（{symbol_name}来自当前模块的import语句:）"
                task.context["import_stmts"] = def_stmts
            elif def_stmt_id == source_unit_id and loader.is_unit_id(def_stmt_id):
                task.context["def_stmts"] = def_stmts
                task.context["import_stmts"] = def_result.get('import_stmts', {})
                return f"({symbol_name}来自import，它的具体类型就是文件<FILE>{source_unit_path})"
            else:
                import_info = f"（{symbol_name}来自其他模块的import，源模块路径: {source_unit_path}）"
                task.context["import_stmts"] = def_stmts

        else:
            import_info = f"（{symbol_name}在当前模块中定义，模块路径: {source_unit_path}）"
            task.context["def_stmts"] = def_stmts

        source_codes = []
        for def_stmt in def_stmts:
            if def_stmt != -1:
                source_codes.extend(loader.get_stmt_source_code_with_comment(def_stmt))
        source_codes = "\n".join(source_codes)
    except Exception as e:
        print(f"Error: {e}")
        return f"找{symbol_name}的定义时出错，请检查"
    return f"\n{import_info}\n{source_codes}"

def get_upper_call_stack(params: Dict[str, Any]) -> str:
    resolver: Resolver = params.get("resolver")
    loader: Loader = params.get("loader")
    task = params.get("task")
    breakpoint_context = Problem.get_breakpoint_context()
    frame = task.context["frame"] if task.context.get("frame", None) else breakpoint_context.get("frame")
    if frame is None:
        return f"调用工具get_upper_call_stack时，缺失frame信息"

    current_stack_index = task.get_ability_call_count(ability_name="get_upper_call_stack", only_success=True)

    try:
        call_site_info = resolver.get_previous_call_site(frame, current_stack_index)

        if call_site_info is None:
            return f"已到达调用栈顶层，无法获取第{current_stack_index + 1}层调用信息"

        result_parts = [f"调用栈第{current_stack_index + 1}层信息："]

        if call_site_info.get("caller_method_unit_path"):
            result_parts.append(f"调用者方法所在模块绝对路径：{call_site_info['caller_method_unit_path']}")

        if call_site_info.get("caller_method_class_name"):
            result_parts.append(f"调用者方法所在类的类名：{call_site_info['caller_method_class_name']}")

        if call_site_info.get("caller_method_id"):
            caller_source_code = loader.get_stmt_source_code_with_comment(call_site_info['caller_method_id'])
            result_parts.append(f"调用者方法源代码：\n{concat_source_code(caller_source_code)}")

        if call_site_info.get("call_stmt_source_code"):
            result_parts.append(f"调用语句：\n{call_site_info['call_stmt_source_code']}")

        if call_site_info.get("callee_method_decl"):
            result_parts.append(f"被调用方法声明：\n{concat_source_code(call_site_info['callee_method_decl'])}")

        if caller_frame := call_site_info.get("caller_frame"):
            if isinstance(caller_frame, ComputeFrame):
                task.context["frame"] = caller_frame
                task.context["stmt_id"] = call_site_info.get("call_stmt_id")
                task.context["unit_id"] = call_site_info.get("caller_method_unit_id")
                task.context["class_id"] = call_site_info.get("caller_method_class_id")

        result = "\n\n".join(result_parts)

        return result

    except Exception as e:
        return f"获取调用栈信息时出错：{str(e)}"

def get_parent_of_class(params: Dict[str, Any]) -> str:
    parameters_from_llm = params.get("parameters_from_llm",{})
    class_name = parameters_from_llm.get("class_name", "")
    if validation_message := _validate_name(class_name, "class_name"):
        return validation_message

    loader:Loader = params.get("loader")

    res = loader.get_parent_class_by_class_name(class_name)
    if len(res) == 0:
        return "该类没有直接父类"
    else:
        parent_classes = []
        for node in res:
            parent_classes.append(node.parent_name)
        return f"class {class_name}的父类：" + ", ".join(parent_classes)

def get_son_of_class(params: Dict[str, Any]) -> str:
    parameters_from_llm = params.get("parameters_from_llm",{})
    class_name = parameters_from_llm.get("class_name", "")

    loader: Loader = params.get("loader")

    res = loader.get_son_class_by_class_name(class_name)
    if len(res) == 0:
        return "该类没有直接子类"
    else:
        son_classes = []
        for node in res:
            son_classes.append(node.name)
    return f"class {class_name}的子类：" + ", ".join(son_classes)

def check_method_of_class(params: Dict[str, Any]) -> str:
    new_params = params.copy()
    parameters_from_llm = new_params.get("parameters_from_llm")
    class_name = parameters_from_llm.get("class_name", "")
    method_name = parameters_from_llm.get("method_name", "")
    if validation_message := _validate_name(class_name, "class_name"):
        return validation_message

    if validation_message := _validate_name(method_name, "method_name"):
        return validation_message

    parameters_from_llm["container_type"] = "class"
    parameters_from_llm["container_identifier"] = class_name
    return get_method_code_in_container(new_params)

def get_method_code_in_container(params: Dict[str, Any]) -> str:

    parameters_from_llm = params.get("parameters_from_llm",{})
    method_name = parameters_from_llm.get("method_name", "")
    container_type = parameters_from_llm.get("container_type", "")
    container_identifier = parameters_from_llm.get("container_identifier", "")

    loader:Loader = params.get("loader")
    resolver:Resolver = params.get("resolver")

    if container_type == "class":
        if validation_message := _validate_name(container_identifier, "class_name"):
            return validation_message
        class_ids = loader.convert_class_name_to_class_ids(container_identifier)
        if util.is_empty(class_ids):
            return f"在项目内部没有找到名为{container_identifier}的类"
        method_src_codes = _get_method_code_of_class(loader, container_identifier, method_name)
        return method_src_codes if util.is_available(method_src_codes) else f"class {container_identifier}中没有定义{method_name}方法"
    elif container_type == "module" or container_type == "file":
        unit_id = loader.convert_unit_path_to_unit_id(container_identifier)
        if unit_id == -1:
            return f"绝对路径{container_identifier}不匹配项目中的任何模块/文件"
        method_src_codes = _get_method_code_in_module(loader, resolver, container_identifier, method_name)
        return method_src_codes if util.is_available(method_src_codes) else f"file {container_identifier}中没有定义{method_name}方法"
    elif container_type == "package":
        method_src_codes = _get_method_code_in_package(loader, resolver, container_identifier, method_name)
        if method_src_codes is None:
            return f"绝对路径{container_identifier}不匹配项目中的任何包/目录"
        return method_src_codes if util.is_available(method_src_codes) else f"package {container_identifier}中没有定义{method_name}方法"
    else:
        return "请指定正确的target_type"

def get_init_method_source_code_of_class(params: Dict[str, Any]) -> list[str]:
    parameters_from_llm = params.get("parameters_from_llm",{})
    class_name = parameters_from_llm.get("class_name", "")
    if validation_message := _validate_name(class_name, "class_name"):
        return [validation_message]

    loader:Loader = params.get("loader")

    init_names = ["__init__", "__post_init__"]
    init_method_src_codes = []
    for init_name in init_names:
        init_src_code = _get_method_code_of_class(
            loader,
            class_name=class_name,
            method_name=init_name,
        )
        init_method_src_codes.extend(init_src_code)
    return init_method_src_codes

def get_prop_def_codes_of_class(params: Dict[str, Any]):
    loader: Loader = params.get("loader")
    task = params.get("task")
    breakpoint_context = Problem.get_breakpoint_context()

    parameters_from_llm = params.get("parameters_from_llm", {})
    class_name = parameters_from_llm.get("class_name", "")
    prop_name = parameters_from_llm.get("prop_name", "")
    if validation_message := _validate_name(prop_name, "prop_name"):
        return validation_message

    if class_name == "":
        class_name = breakpoint_context.get("class_name", "")

    if validation_message := _validate_name(class_name, "class_name"):
        return validation_message
    class_ids = loader.convert_class_name_to_class_ids(class_name)
    if util.is_empty(class_ids):
        return f"未在项目中找到名为 '{class_name}' 的类的定义"

    matching_lines = []

    for i, class_id in enumerate(class_ids):
        class_src_lines = loader.get_stmt_source_code_with_comment(class_id)
        pattern = rf'(self\.{re.escape(prop_name)}\s*=|cls\.{re.escape(prop_name)}\s*=)'
        
        collecting_multiline = False
        current_assignment_lines = []
        base_indent = 0
        paren_count = 0  
        
        for line_num, line_content in enumerate(class_src_lines, 1):
            if re.search(pattern, line_content):
                if collecting_multiline:
                    matching_lines.append('\n'.join(current_assignment_lines))
                
                collecting_multiline = True
                current_assignment_lines = [line_content]
                base_indent = len(line_content) - len(line_content.lstrip())
                
                paren_count = line_content.count('(') - line_content.count(')')
                
            elif collecting_multiline:
                stripped_line = line_content.strip()
                
                if not stripped_line:
                    current_assignment_lines.append(line_content)
                    continue
                
                if stripped_line.startswith('#'):
                    current_indent = len(line_content) - len(line_content.lstrip())
                    if current_indent > base_indent:
                        current_assignment_lines.append(line_content)
                        continue
                    else:
                        matching_lines.append('\n'.join(current_assignment_lines))
                        collecting_multiline = False
                        current_assignment_lines = []
                        paren_count = 0
                        continue
                
                paren_count += line_content.count('(') - line_content.count(')')
                
                current_indent = len(line_content) - len(line_content.lstrip())
                
                if current_indent > base_indent:
                    current_assignment_lines.append(line_content)
                elif paren_count > 0:
                    current_assignment_lines.append(line_content)
                elif current_indent == base_indent and stripped_line.startswith(')'):
                    current_assignment_lines.append(line_content)
                else:
                    matching_lines.append('\n'.join(current_assignment_lines))
                    collecting_multiline = False
                    current_assignment_lines = []
                    paren_count = 0
        if collecting_multiline and current_assignment_lines:
            matching_lines.append('\n'.join(current_assignment_lines))
        
    if util.is_empty(matching_lines):
        return f"在类 '{class_name}' 中未找到属性 '{prop_name}' 的相关代码"
    formatted_results = []
    for i, assignment in enumerate(matching_lines, 1):
        formatted_assignment = f"第{i}处：\n{assignment}"
        formatted_results.append(formatted_assignment)
    
    return formatted_results
        
    
def get_class_source_code(params: Dict[str, Any]) -> str:
    loader: Loader = params.get("loader")
    task = params.get("task")
    breakpoint_context = Problem.get_breakpoint_context()

    parameters_from_llm = params.get("parameters_from_llm",{})
    class_name = parameters_from_llm.get("class_name", "")

    if class_name == "":
        class_name = breakpoint_context.get("class_name", "")
    
    if validation_message := _validate_name(class_name, "class_name"):
        return validation_message
    class_ids = loader.convert_class_name_to_class_ids(class_name)
    if util.is_empty(class_ids):
        return f"未在项目中找到名为 '{class_name}' 的类的定义"
    
    all_class_sources = []
    
    for i, class_id in enumerate(class_ids):
        class_src_lines = loader.get_stmt_source_code_with_comment(class_id)
        class_src_code = "\n".join(class_src_lines)
        if len(class_ids) > 1:
            all_class_sources.append(f"# 类定义 {i+1}/{len(class_ids)} (ID: {class_id})")
            unit_id = loader.convert_stmt_id_to_unit_id(class_id)
            unit_path = loader.convert_unit_id_to_unit_path(unit_id)
            all_class_sources.append(f"    # 类定义所在模块路径: {unit_path}")
            all_class_sources.append(class_src_code)
            if i < len(class_ids) - 1:  
                all_class_sources.append("\n" + "="*50 + "\n")
        else:
            all_class_sources.append(class_src_code)
    
    return "\n".join(all_class_sources)
def analyze_project_context(params: Dict[str, Any]) -> str:
    loader: Loader = params.get("loader")
    try:
        import re
        roots = []
        if loader:
            try:
                targets = loader.get_target_paths_to_be_analyzed() or []
            except Exception:
                targets = []
            for p in targets:
                if isinstance(p, str):
                    d = os.path.dirname(p) if os.path.isfile(p) else p
                    if d:
                        roots.append(os.path.abspath(d))
        base = roots[0] if len(roots) == 1 else (os.path.commonpath(roots) if roots else os.getcwd())
        readme = ""
        for n in ["README.md", "Readme.md", "readme.md", "README", "README.rst", "readme.rst"]:
            p = os.path.join(base, n)
            if os.path.isfile(p):
                readme = p
                break
        if not readme:
            try:
                for entry in os.listdir(base):
                    sub = os.path.join(base, entry)
                    if not os.path.isdir(sub):
                        continue
                    for n in ["README.md", "Readme.md", "readme.md", "README", "README.rst", "readme.rst"]:
                        p = os.path.join(sub, n)
                        if os.path.isfile(p):
                            readme = p
                            break
                    if readme:
                        break
            except Exception:
                pass

        name, snippet = "", ""
        if readme:
            try:
                txt = open(readme, "r", encoding="utf-8", errors="ignore").read()
            except Exception:
                txt = ""

            if txt:
                m = re.search(r"^\s*#\s+(.+)$", txt, re.M)
                if m:
                    name = m.group(1).strip().strip("#")
                if not name:
                    m = re.search(r"^(.+)\n=+\s*$|^(.+)\n-+\s*$", txt, re.M)
                    if m:
                        name = (m.group(1) or m.group(2) or "").strip()
                if not name:
                    m = re.search(r"<img[^>]*alt=[\"']([^\"']+)[\"'][^>]*>", txt, re.I)
                    if m:
                        name = m.group(1).strip()
                if not name:
                    m = re.search(r"<h[1-3][^>]*>(.*?)</h[1-3]>", txt, re.I | re.S)
                    if m:
                        name = re.sub(r"<[^>]+>", "", m.group(1)).strip()
                if not name:
                    lines = txt.splitlines()
                    about_idx = next((i for i, ln in enumerate(lines) if re.match(r"^\s*##\s*About\b", ln)), -1)
                    if about_idx != -1:
                        prev_line = next((lines[i].strip() for i in range(about_idx - 1, -1, -1) if lines[i].strip()), "")
                        next_line = next((lines[i].strip() for i in range(about_idx + 1, len(lines)) if lines[i].strip()), "")
                        name = prev_line or next_line or ""
                if not snippet:
                    lines = txt.splitlines()
                    snippet = "\n".join(lines[1:21]).strip() if len(lines) > 1 else ""

        if not name:
            name = os.path.basename(base) or "未知项目"

        parts = ["项目上下文分析结果：", f"- 项目名称: {name}"]
        if readme:
            parts.append(f"- README 路径: {readme}")
            if snippet:
                parts.append("- README 片段:\n" + (snippet if len(snippet) <= 1200 else snippet[:1200].rstrip() + "..."))
        else:
            parts.append(f"- 项目主目录: {base}")
        return "\n".join(parts)
    except Exception as e:
        return f"项目上下文分析失败: {str(e)}"

def get_caller_source_code(params: Dict[str, Any]) -> str:
    breakpoint_context = Problem.get_breakpoint_context()
    return breakpoint_context.get("caller_code")

def get_class_define_path(params: Dict[str, Any]) -> str:
    parameters_from_llm = params.get("parameters_from_llm",{})
    class_name = parameters_from_llm.get("class_name", "")

    if validation_message := _validate_name(class_name, "class_name"):
        return validation_message

    loader = params.get("loader")
    class_ids = loader.convert_class_name_to_class_ids(class_name)
    if util.is_empty(class_ids):
        return f"没有找到类名为{class_name}的类定义"
    class_id = class_ids.copy().pop()
    unit_id = loader.convert_class_id_to_unit_id(class_id)
    unit_path = loader.convert_unit_id_to_unit_path(unit_id)
    return f"class {class_name}的定义文件路径为：{unit_path}"
def _find_imported_py_files_with_key(loader, resolver, key: str) -> dict:

    METHOD = "全局方法"
    CLASS = "全局类"
    FILE = "同名文件"
    MODULE = "同名模块"

    sources = {
        METHOD  : set(),
        CLASS   : set(),
        FILE    : set(),
        MODULE  : set()
    }

    def locate_py_files_with_file_name(file_name: str) -> set:
        interested_units: set[str] = set()
        for unit_info in loader.get_all_unit_info():
            unit_path = unit_info.unit_path
            unit_name = os.path.basename(unit_path)
            unit_name_without_ext = os.path.splitext(unit_name)[0]
            if unit_name_without_ext == file_name:
                interested_units.add(unit_info)
                sources[FILE].add(unit_info)
        return interested_units

    def locate_py_files_defining_certain_symbol(symbol_name: str) -> set:
        interested_units = set()
        if util.is_empty(symbol_name): return interested_units
        for unit_info in loader.get_all_unit_info():
            unit_id = unit_info.unit_id
            symbol_global_def_in_unit = resolver.find_symbol_global_def_in_unit(unit_id, symbol_name)
            if not any(symbol_global_def_in_unit[kind] for kind in [LIAN_SYMBOL_KIND.CLASS_KIND, LIAN_SYMBOL_KIND.METHOD_KIND]):
                continue
            interested_unit_info = unit_info
            if util.is_available(interested_unit_info):
                interested_units.add(interested_unit_info)
                if util.is_available(symbol_global_def_in_unit[LIAN_SYMBOL_KIND.CLASS_KIND]):
                    sources[CLASS].add(interested_unit_info)
                if util.is_available(symbol_global_def_in_unit[LIAN_SYMBOL_KIND.METHOD_KIND]):
                    sources[METHOD].add(interested_unit_info)
                continue
        return interested_units

    def locate_py_dirs_with_dir_name(dir_name: str) -> set:
        interested_dirs = set()
        root_path = loader.get_target_paths_to_be_analyzed()[0]
        for dirPath, dirNames, fileNames in os.walk(root_path):
            current_dir_name = os.path.basename(dirPath)
            if current_dir_name == dir_name and "__init__.py" in fileNames:
                dir_id = loader.convert_unit_path_to_unit_id(dirPath)
                dir_info = loader.convert_module_id_to_module_info(dir_id)
                interested_dirs.add(dir_info)
                sources[MODULE].add(dir_info)

        return interested_dirs
    candidate_unit_info_rows = (
        locate_py_files_with_file_name(key) |
        locate_py_files_defining_certain_symbol(key) |
        locate_py_dirs_with_dir_name(key)
    )
    analyzed_sources = {}
    for source_type in ["全局类", "全局方法", "同名文件", "同名模块"]:
        if sources.get(source_type):
            source_files = []
            for unit_info in sources[source_type]:
                if hasattr(unit_info, 'unit_path'):
                    source_files.append(unit_info.unit_path)
                else:
                    source_files.append(str(unit_info))
            analyzed_sources[source_type] = source_files
        else:
            analyzed_sources[source_type] = []

    return analyzed_sources

def _find_symbol_def_stmt_by_symbol_name(loader, resolver, frame, unit_id, stmt_id, symbol_name: str) -> dict:

    NEAREST = "nearest_def_stmt_ids"
    ALL = "all_def_stmt_ids"
    if stmt_id in frame.stmt_id_to_status:
        intra_method_def = resolver.resolve_symbol_name_to_def_stmt_in_method(frame, unit_id, stmt_id, symbol_name)
        if intra_method_def[NEAREST]:
            return {
                'stmt_ids': intra_method_def[NEAREST],
                'is_import': False,
                'source_unit_id': unit_id
            }
        elif intra_method_def[ALL]:
            return {
                'stmt_ids': intra_method_def[ALL],
                'is_import': False,
                'source_unit_id': unit_id
            }
    source_symbol_scope = resolver.resolve_symbol_source_decl(unit_id, stmt_id, symbol_name)
    if (loader.is_import_stmt(source_symbol_scope.source_symbol_id) and
        source_symbol_scope.source_unit_id == -1):
        return {
            'stmt_ids': {source_symbol_scope.source_symbol_id},
            'is_import': True,
            'import_stmts': {source_symbol_scope.current_symbol_id},
            'source_unit_id': -1
        }
    elif source_symbol_scope.source_unit_id != unit_id:
        return {
            'stmt_ids': {source_symbol_scope.source_symbol_id},
            'is_import': True,
            'import_stmts' : {source_symbol_scope.current_symbol_id},
            'source_unit_id': source_symbol_scope.source_unit_id
        }
    return {
        'stmt_ids': {source_symbol_scope.source_symbol_id} if source_symbol_scope.source_symbol_id>0 else {},
        'is_import': False,
        'source_unit_id': unit_id
    }

def _get_method_code_in_module(loader, resolver, unit_path, method_name: str) -> str:
    unit_id = loader.convert_unit_path_to_unit_id(unit_path)
    symbol_global_def_in_unit = resolver.find_symbol_global_def_in_unit(unit_id, method_name)
    method_src_codes = []
    for method_id in symbol_global_def_in_unit[LIAN_SYMBOL_KIND.METHOD_KIND]:
        method_src_code: str = "\n".join(loader.get_stmt_source_code_with_comment(method_id)) + '\n\n'
        method_src_codes.append(method_src_code)
    if util.is_available(method_src_codes):
        method_ids = loader.convert_method_name_to_method_ids(method_name)
        for method_id in method_ids:
            verifying_unit_id = loader.convert_method_id_to_unit_id(method_id)
            if verifying_unit_id == unit_id:
                method_src_code: str = "该方法可能是闭包方法：\n".join(loader.get_stmt_source_code_with_comment(method_id)) + '\n\n'
                method_src_codes.append(method_src_code)

    return method_src_codes if util.is_available(method_src_codes) else ""

def _get_method_code_of_class(loader:Loader, class_name: str, method_name: str) -> str:

    method_ids = loader.get_method_of_class_with_name(class_name, method_name)
    method_src_codes = []
    for method_id in method_ids:
        method_decl = loader.convert_method_id_to_method_decl_format(method_id)
        if "abstract" in method_decl.get("attrs", {}):
            continue
        method_src_code:str = "\n".join(loader.get_stmt_source_code_with_comment(method_id)) + '\n\n'
        unit_id = loader.convert_method_id_to_unit_id(method_id)
        unit_path = loader.convert_unit_id_to_unit_path(unit_id)
        method_location_info: str = f"文件路径:{unit_path},类名:{class_name},方法名{method_name}，找到源代码如下：\n"
        method_src_codes.append(method_location_info+method_src_code)
    return method_src_codes if util.is_available(method_src_codes) else ""

def _get_method_code_in_package(loader, resolver, package_path: str, method_name: str) -> list[Any] | str | None:

    if not os.path.exists(package_path) or not os.path.isdir(package_path):
        return None
    init_file_path = os.path.join(package_path, '__init__.py')
    if not os.path.exists(init_file_path):
        return ""
    init_unit_id = loader.convert_unit_path_to_unit_id(init_file_path)
    if init_unit_id == -1:
        return ""
    
    symbol_global_def_in_unit = resolver.find_symbol_global_def_in_unit(init_unit_id, method_name)
    method_src_codes = []
    for method_id in symbol_global_def_in_unit[LIAN_SYMBOL_KIND.METHOD_KIND]:
        method_src_code = "\n".join(loader.get_stmt_source_code_with_comment(method_id)) + '\n\n'
        method_src_codes.append(method_src_code)
    if util.is_available(method_src_codes):
        return method_src_codes 
    for import_stmt_id in symbol_global_def_in_unit[LIAN_SYMBOL_KIND.IMPORT_STMT]:
        import_stmt = loader.get_stmt_source_code_with_comment(import_stmt_id)
        method_src_codes.append(import_stmt)
    return method_src_codes if util.is_available(method_src_codes) else ""

def _validate_name(name, name_type="symbol_name"):
    import re
    import inspect
    caller_name = inspect.currentframe().f_back.f_code.co_name
    invalid_patterns = [
        (r'\.', "a.b"),
        (r'[\[\]]', "A[B]"), 
        (r'[()]', "A(B)")
    ]
    for pattern, form in invalid_patterns:
        if re.search(pattern, name):
            return f"调用{caller_name}失败：{name_type}不应该是{form}的形式，请提供简单的{name_type}"
    
    return None
def get_source_code(params: Dict[str, Any]) -> str:
    file_path = params.get("file_path", "")
    line_range = params.get("line_range", "")
    
    return f"源代码：\n- 文件路径：{file_path}\n- 行号范围：{line_range}\n- 代码内容：def nail_function():\n    pass"

def check_module_in_project(params: Dict[str, Any]) -> str:
    module_name = params.get("module_name", "")
    loader: Loader = params.get("loader")
    
    try:
        root_path = loader.get_target_paths_to_be_analyzed()[0]
        module_dir = os.path.join(root_path, module_name)
        has_module_dir = os.path.exists(module_dir) and os.path.isdir(module_dir)
        module_file = os.path.join(root_path, f"{module_name}.py")
        has_module_file = os.path.exists(module_file)
        all_units = loader.get_all_unit_info()
        related_files = []
        for unit in all_units:
            unit_path = unit.unit_path
            if module_name in unit_path:
                related_files.append(unit_path)
        
        result_parts = [f"模块 '{module_name}' 在项目中的存在情况："]
        
        if has_module_dir:
            result_parts.append(f"- 存在模块目录: {module_dir}")
        
        if has_module_file:
            result_parts.append(f"- 存在模块文件: {module_file}")
        
        if related_files:
            result_parts.append(f"- 相关文件: {', '.join(related_files[:5])}")  
            if len(related_files) > 5:
                result_parts.append(f"  ... 还有 {len(related_files) - 5} 个相关文件")
        
        if not (has_module_dir or has_module_file or related_files):
            result_parts.append("- 项目中未找到该模块")
        
        return "\n".join(result_parts)
        
    except Exception as e:
        return f"模块检查失败: {str(e)}"
ABILITY_IMPLEMENTATIONS = {
    "get_possible_sources_of_key": get_possible_sources_of_key,
    "get_source_code": get_source_code,
    "find_last_define_of_symbol": find_last_define_of_symbol,
    "get_upper_call_stack": get_upper_call_stack,
    "get_parent_of_class": get_parent_of_class,
    "get_son_of_class": get_son_of_class,
    "get_method_code_in_container": get_method_code_in_container,
    "get_init_method_source_code_of_class": get_init_method_source_code_of_class,
    "get_class_source_code": get_class_source_code,
    "analyze_project_context": analyze_project_context,
    "get_class_define_path": get_class_define_path,
    "get_caller_source_code": get_caller_source_code,
    "check_method_of_class": check_method_of_class,
    "get_prop_def_codes_of_class":get_prop_def_codes_of_class
}
