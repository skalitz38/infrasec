
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class MethodCallSolver(SolverTemplate):
    available_solvers = ["SymbolTypeSolver", "ReturnTypeSolver", "SuperTypeSolver", "SelfClsPropTypeSolver",
                          "ExternLibSolver", "FunctionExecutionSolver", "HierarchySolver", "SelfClsFuncSolver", "MethodFinderSolver"]
    router_description = cleandoc("""\
        **MethodCallSolver** - 解决SelfClsFuncSolver无法处理的方法调用
        - **专业领域**: 方法调用的目标方法解析
        - **解答问题**: 给定一条调用语句(非self.func()形式的方法调用)，这条语句实际要调用的目标方法是什么？
        - **适用场景**: 找到形如obj.func(),a.method(),Class(),self.prop.func()的调用(非self.func()形式的方法调用)的目标方法
    """)

    def _init_solver(self):
        self.domain = "方法调用解析与目标方法确定"
        self.capabilities = "方法调用解析、目标方法查找"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            首先判断方法调用问题是否并不属于self./cls.后面直接跟方法名的调用方式，如果属于，这并不属于你的任务范围，立刻返回任务失败
            
            ### 第一步：检查任务执行历史中的其他Solver结果
            **结果整合**：
            - **其他Solver结果检查**：如果任务执行历史中已有其他Solver的处理结果
            - **特殊**：如果是多态场景且已经找到所有的可能的子类，直接返回结果，此时method_location为None, container_identifier为字符串列表，列表元素为HierarchySolver结果的target_classes中的子类名
                      如果是第三方库/标准库调用，不需要找到方法的源代码与签名
            - **决策**：基于其他Solver结果继续处理，自行决定跳到第几步
            - **显式声明**：在reasoning中记录"基于其他Solver结果继续处理：[具体结果]"
            
            ### 第二步：分析调用语句结构
            **调用语句解析**：
            - **输入分析**：
                - 若调用语句为`obj.func()`的结构
                  - **receiver_expr**：obj（接收者表达式）
                  - **method_name**：func（方法名）
                  - **call_site**：调用位置信息
                  - **显式声明**：在reasoning中明确记录"解析调用语句：obj.func，接收者=obj，方法名=func"
                - 若调用语句为`func()`的结构
                  - **method_name**：func（方法名）
                  - **call_site**：调用位置信息
                  - **显式声明**：在reasoning中明确记录"解析调用语句：方法名=func"
                  - **决策**: 返回NEEDS_FOLLOWUP，请求解析func的定义。
            
            ### 第三步：检查obj类型是否已知
            **类型状态检查**：
            - **任务执行历史检查**：检查任务执行历史中是否已有obj的类型信息
              - **已知类型**：如果已有obj的类型解析结果（必须来自工具调用或明确的类型解析结果）
                - **决策**：直接使用已知类型，进入第三步
                - **显式声明**：在reasoning中记录"使用已知obj类型：[具体类型]，来源：[工具调用结果/类型解析结果]"
              
              - **类型未知**：如果obj类型未知
                - **决策**：返回NEEDS_FOLLOWUP
                - **问题描述要求**：详细描述当前遇到的问题场景和困难
                - **必须包含**：
                  - 当前obj是什么符号（变量名、表达式等）
                  - 当前已知什么的信息
                  - 推理过程（为什么无法确定类型）
                  - 缺少什么关键信息
                  - 这个问题的性质（是符号类型解析问题、导入问题、还是其他问题）
                - **显式声明**：在reasoning中详细记录"obj类型未知，问题描述：[详细问题场景]"
            
            ### 第四步：检查obj类型是否涉及到外部第三方库或函数执行API
            **类型检查**：
            - **任务执行历史检查**：检查任务执行历史中obj的类型信息
              
              - **函数执行API类型**：如果obj类型明确标识为来自函数执行API
                - **情况A：当前任务历史中已有函数执行API相关的Solver解析了当前调用**：任务执行历史中显示，函数执行API的Solver已明确指出实际执行的目标方法及其完整信息
                  - **信息完整性检查**：检查是否包含container_type、container_identifier、method_name、method_desc、method_signature、method_location
                  - **决策**：如果信息完整，直接使用历史结果，返回COMPLETED
                  - **显式声明**：在reasoning中记录"obj类型为函数执行API，已获得实际调用方法信息：[具体方法信息]，任务完成"
                
                - **情况B：任务历史中没有函数执行API相关的Solver解析当前调用**：如果任务执行历史中只指出是这是一个外部库的函数执行API，但未指出具体调用的实际方法
                  - **决策**：返回NEEDS_FOLLOWUP，详细描述当前遇到的问题场景和需求
                  - **必须包含**：
                    - 当前obj的类型信息（明确标识为函数执行API）
                    - 当前完整的调用语句
                    - 函数执行API的名称或标识
                    - 这个问题的性质（函数执行API调用语义解析问题）
                  - **显式声明**：在reasoning中详细记录"obj类型为函数执行API，需要解析调用语义，问题描述：[详细问题场景]"

              - **外部库类型**：如果obj类型明确标识为External（外部第三方库）
                - **决策**：返回NEEDS_FOLLOWUP，详细描述当前遇到的问题场景和需求
                - **必须包含**：
                  - 当前obj的类型信息（明确标识为External）
                  - 依据哪条任务执行历史的哪句话，得出这是外部库的结论？**引用原句**
                  - 外部库的名称或标识
                  - 这个问题的性质（外部库调用解析问题）
                  - 你想知道什么信息（这条涉及到外部库的调用语句，到底调用了什么方法）
                - **显式声明**：在reasoning中详细记录"obj类型为外部第三方库，问题描述：[详细问题场景]"
              
              - **内部类型**：如果obj类型为内部类型（非External，非函数执行API）
                - **决策**：继续进入第四步处理
                - **显式声明**：在reasoning中记录"obj类型为内部类型，继续处理方法调用"
            
            ### 第五步：获取目标方法
            **方法查找逻辑**：
            - **已知obj类型**：如果obj类型已知（如ClassName）
              - **强制工具调用**：调用get_method_code_in_container(method_name, obj类型名/模块或包的绝对路径, "class|module|package")
              - **验证要求**：必须获得明确的方法信息，不能基于假设
              - **显式声明**：在reasoning中明确记录"已调用get_method_code_in_container(method_name, ClassName/ModuleAbsPath, "class|module|package")，获得方法信息：[具体方法信息]"
            
            ### 第六步：方法信息验证与输出
            **方法信息处理**：
            - **方法存在**：如果成功获取到方法信息(包括container_type、container_identifier、method_name、method_location、method_signature)
              - **决策**：如果方法定义是一个抽象方法，则返回NEEDS_FOLLOWUP，因为需要寻找子类类型。写清楚问题描述，并在reasoning中明确记录"找到方法定义为抽象方法，需要寻找具体实现的子类：[基类类型与方法名等信息]"
                         如果方法定义不是一个抽象方法，则任务成功，返回完整的方法信息，在reasoning中明确记录"成功找到目标方法：[方法详细信息]"
                
            - **方法不存在**：如果未找到方法
              - **决策**：返回FAILED状态
              - **显式声明**：在reasoning中记录"在类型[obj类型]中未找到方法[method_name]"
            
            ### 第七步：结果自检与输出
            **自检清单**：
            0. 是否查看了当前任务执行历史中其他Solver的结果？
            1. 是否正确解析了调用语句结构？
            2. 是否检查了obj类型是否已知，且来自于工具调用结果或任务执行历史？
            3. 如果类型未知，是否详细描述了问题场景和困难？
            4. 是否检查了obj类型是否为外部第三方库或函数执行API？
            5. 如果类型为函数执行API，是否检查了任务执行历史中是否有实际被执行的函数信息？若**没有**，则是否详细描述了问题场景并返回NEEDS_FOLLOWUP？
            6. 如果类型为外部库，是否详细描述了问题场景并返回NEEDS_FOLLOWUP？
            7. 如果类型已知且为内部类型，是否调用了get_method_code_in_container？
            8. 是否获得了明确的方法信息(包括container_type、container_identifier、method_name、method_location、method_signature)？
            9. 如果遇到问题，是否详尽地描述了问题场景？
            
            **输出条件**：
            - **COMPLETED**：当成功找到目标方法且信息完整时，或当函数执行API已有完整目标方法信息时
            - **NEEDS_FOLLOWUP**：当遇到无法解决的问题时，必须详细描述问题场景
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **FAILED**：当类型已知但未找到对应方法时""") 
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED|NEEDS_ABILITY(需要使用工具)|NEEDS_FOLLOWUP(需要其他Solver帮助)|FAILED",
                "confidence": 0.0 - 1.0,
                "summary": "基于obj类型和方法查找的工具调用解析总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)调用语句结构解析 2)obj类型状态检查(必须说明类型信息来源) 3)外部库类型检查 4)方法查找过程 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    (若调用语句是obj.func)"container_type": "obj如果为类则为class，如果为模块则为module，如果为包则为package",
                    (若调用语句是obj.func)"container_identifier": "obj类名/模块完整绝对路径（文件绝对路径）/包完整绝对路径",
                    "method_name": "方法名（如func）",
                    "method_desc": "找到的目标方法的信息描述",
                    "method_signature": "方法签名（如def method_name(self, param):）",
                    "method_location": "方法定义位置（给出绝对路径）",
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "get_method_code_in_container", 
                        "parameters": { "method_name": "方法名", "container_identifier": "模块或包的完整绝对路径/类型名", "container_type": "class|module|package" }, 
                        "description": "在指定模块/类型中查找方法",
                        "reason": "需要查找obj类型中的具体方法"
                    } 
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "problem_scenario": "详细的问题场景描述",
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                } 
            }
            ```""")

        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_method_call_result  
        self.post_processor = self._post_process_method_call_result  

    def _validate_method_call_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["receiver_type", "method_name", "target_method"]
        return all(field in result_data for field in required_fields)
    
    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["receiver_expr", "method_name", "call_site"]
        return all(param in task.params for param in required_params)
    
    def _post_process_method_call_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, self.thinking_steps, voter_counts=voter_counts, solver=self)
        
        return result
