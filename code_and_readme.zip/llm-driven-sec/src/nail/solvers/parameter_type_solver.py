from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult, AbilityCall
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class ParameterTypeSolver(SolverTemplate):

    available_solvers = ["SymbolTypeSolver", "SelfClsPropTypeSolver", "HierarchySolver", "ReturnTypeSolver", "MethodFinderSolver"]
    dependent_solvers = ["SymbolTypeSolver"]
    router_description = cleandoc("""\
        **ParameterTypeSolver** - 参数类型推断专家
        - **专业领域**: 解析参数符号的具体类型和定义来源、调用栈查询、类型提示信息 
        - **解答问题**: 一个来自参数的符号，它的具体类型信息或类型推断是什么？
        - **适用场景**: 需要解析来自参数声明的符号类型或定义位置
    """)
    
    def _init_solver(self):
        self.domain = "通过调用栈分析找到symbol的具体定义语句"
        self.capabilities = "调用栈分析、参数类型推断、类型约束检查"
        
        self.thinking_steps = cleandoc("""\
            ## 你的思考步骤
            
            ### 第一步：确认参数定义任务
            **任务确认**：
            - **输入分析**：当前symbol已确认为函数形参，需要沿调用栈向上查找其具体定义
            - **显式声明**：在reasoning中明确记录"开始参数类型推断任务，目标symbol：[symbol_name]"
            
            ### 第二步：调用工具获取上一层调用栈
            **强制工具调用**：
            - **必须执行**：调用get_upper_call_stack获取上一层调用点，其中包括调用当前方法的上一层caller方法的源代码、调用语句源代码、调用语句所在文件路径、所属类名
            - **验证要求**：必须获得明确的调用栈信息，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已调用get_upper_call_stack，获得调用栈信息：[具体调用栈信息]"
            
            ### 第三步：找到形参symbol关联的实参symbol'的定义
            **强制审计代码**：
            - **必须执行**：审计get_upper_call_stack工具给出的caller方法的源代码，找到实参symbol'在caller中的定义语句
            - **验证要求**：必须严格审计caller方法中的symbol'定义，不能基于假设或推测
            - **显式声明**：在reasoning中明确记录"已审计调用者[caller_name]的源代码，获得symbol'定义：[具体定义]"
            
            ### 第四步：若在caller中没有找到实参symbol'的任何定义
            - **决策**：
                - 调用工具find_last_define_of_symbol，尝试寻找symbol'的定义。
                - 若仍然没找到，则返回FAILED，并根据是否有类型提示，返回相应信息。
            - **有类型提示**：若寻找过程中有关于symbol的类型提示
              - **决策**：返回FAILED，返回definition_source为TYPE_HINT
              - **显式声明**：在reasoning中记录"无法找到[实参]的定义，只能根据类型提示判断为[提示类型]"
            - **无类型提示**：如果连symbol的类型提示都没有
              - **要求**：在返回结果中必须包括实参定义所在的文件路径、类名、方法名（从工具get_upper_call_stack的结果中获取），返回definition_source为UNKNOWN
              - **显式声明**：在reasoning中记录"找到参数的来源，为方法[caller_name]中的实参[symbol']，需要解析[具体文件路径+类名]中[symbol']的具体类型"
            
            ### 第五步：若在caller中找到了实参symbol'的定义，则判断定义类型
            - **symbol'仍来自caller的参数声明**：如果实参定义仍然来自上一层caller的参数
              - **决策**：继续向上查找，重复第二步和第三步
              - **显式声明**：在reasoning中记录"[实参]仍来自于调用者的参数，继续向上查找"
            
            - **symbol'不来自caller的参数声明**：如果实参定义来自其他语句（如变量赋值）
              - **决策**：返回COMPLETED，必须提供找到的定义语句，返回definition_source为ASSIGNMENT
              - **显式声明**：在reasoning中明确记录"找到非参数声明的实参定义：[具体定义语句]"
            
            ### 第六步：处理工具显示已到达调用栈底的情况
            **调用栈底处理**：
            - **到达栈底**：当get_upper_call_stack工具结果**明确告知**已经找到调用栈底，且此时实参symbol'定义依旧来自参数
              - **决策**：返回NEEDS_FOLLOWUP，并详细描述当前遇到的问题场景和困难，返回definition_source为PARAMETER
              - **验证要求**：必须是get_upper_call_stack工具结果中明确告知已找到栈顶，不能基于假设
              - **必须包含**：
                - 调用链中的类型提示信息(参数声明中)
                - 缺少什么关键信息
                - 这个问题的性质（是调用链分析问题、类型推断问题、还是其他问题）
              - **显式声明**：在reasoning中详细记录"工具调用结果#x条显示，已经到达调用栈底且仍为参数，问题描述：[详细问题场景]，需要多态解析基类[xxx]可能的子类类型"
            
            ### 第七步：结果自检与输出
            **自检清单**：
            1. 是否调用了get_upper_call_stack？获得了什么调用栈信息？
            2. 是否认真审计了get_upper_call_stack中调用者的源代码并查找symbol'的定义？
            3. 是否进行了定义类型判断？判断结果是什么？
            4. 是否完成了完整的调用链分析？"找到栈顶"这一信息是否是由是否调用了get_upper_call_stack工具明确告知的？
            5. 如果找到栈底却依旧为参数，是否检查并提供了调用链中的类型提示信息？
            6. 如果遇到问题，是否详尽地描述了问题场景？
            7. 每个结论都有明确的工具调用依据吗？
            
            **输出条件**：
            - **COMPLETED**：当成功找到非参数定义时
            - **NEEDS_ABILITY**：如果信息不足，必须说明需要什么工具
            - **NEEDS_FOLLOWUP**：如果无法找到实参的任何定义，必须详细说明面临的问题与相关信息
            - **FAILED**：没有找到非参数的定义，则必须详细描述问题场景""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
                "status": "COMPLETED(任务成功)|NEEDS_ABILITY(需要使用工具)|FAILED(任务失败)",
                "confidence": 0.0 - 1.0,
                "summary": "基于调用栈分析的参数类型推断总结，或详细描述遇到的问题场景",
                "reasoning": "必须包含：1)get_upper_call_stack调用结果 2)find_last_define_of_symbol调用结果 3)定义类型判断过程 4)调用链分析过程 5)问题场景详细描述(如果遇到问题)",
                "result_data": {
                    "symbol_name": "实参符号名",
                    "final_definition": "具体的定义语句，如果还是来源于参数或未知的实参，则为包含该参数方法的方法签名",
                    "defined_file": "定义所在文件（实参定义所在文件）",
                    "defined_class": "定义所属类（实参定义所属类名）",
                    "defined_method": "定义所在方法名",
                    "parameter_name": "参数名",
                    "definition_source": "ASSIGNMENT|UNKNOWN|PARAMETER|TYPE_HINT",
                },
                "suggested_abilities": [ 
                    { 
                        "ability_name": "get_upper_call_stack", 
                        "parameters": { "current_file": "当前文件", "current_line": 0 }, 
                        "description": "获取上一层调用栈信息",
                        "reason": "需要获取调用栈信息进行参数类型推断"
                    },
                    { 
                        "ability_name": "find_last_define_of_symbol", 
                        "parameters": { "symbol_name": "符号名" }, 
                        "description": "查找symbol定义",
                        "reason": "需要查找symbol定义进行类型推断"
                    }
                ],
                "next_problems": { 
                    "description": "详细描述当前遇到的问题场景和困难", 
                    "metadata": { 
                        "current_info": "当前已有的信息",
                        "missing_info": "缺少的关键信息",
                        "reasoning_process": "推理过程",
                        "problem_nature": "问题的性质分析"
                    }
                }
            }
            ```""")
        
        self.task_params_validator = self._validate_task_params  
        self.result_validator = self._validate_parameter_type_result  
        self.post_processor = self._post_process_parameter_type_result  

    
    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["symbol_name", "current_file_path"]
        return all(param in task.params for param in required_params)
    
    def _post_process_parameter_type_result(self, result: SolverResult, task: Task) -> SolverResult:
        if result.status == "COMPLETED":
            if not self._validate_parameter_type_result(result.result_data):
                return SolverResult(
                    status="NEEDS_ABILITY",
                    suggested_abilities=[AbilityCall(
                        ability_name="get_upper_stack",
                        parameters={
                            "current_file": task.params.get("current_file_path", ""),
                            "current_line": task.params.get("current_line", 0)
                        },
                        description="补全缺失字段以完成类型推断"
                    )],
                    confidence=max(0.0, result.confidence * 0.6),
                    reasoning="参数类型推断结果缺字段，建议再取证"
                )

        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)

        return result
    
    def _validate_parameter_type_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["symbol_name", "inferred_type", "type_source", "final_definition"]
        return all(field in result_data for field in required_fields)
