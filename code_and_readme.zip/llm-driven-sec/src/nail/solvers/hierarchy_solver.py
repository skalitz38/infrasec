
from nail.solvers.solver_template import SolverTemplate
from nail.common_structure import Task, SolverResult
from nail.utils.solver_supervisor_llm import doublecheck_solver_result_by_supervisor
from nail.config import config
from inspect import cleandoc

class HierarchySolver(SolverTemplate):
    available_solvers = []
    router_description = cleandoc("""\
        **HierarchySolver** - 多态类型判断专家
        - **专业领域**: 多态兜底
        - **核心能力**: 根据基类，找到所有的子类
        - **适用场景**: 只有一个类型注解，无法确定具体子类
        - **需求数据**: 需要基类类型以及调用的方法名""")

    def _init_solver(self):
        self.domain = "处理多态调用"
        self.capabilities = cleandoc("""\
            给定一条Base.func()形式的调用，找到：
            - 所有Base类的子类
            - 在该条调用中，可能会被调用的具体子类方法""")
        
        self.thinking_steps = cleandoc("""\
            ## 思考步骤(请你一步一步思考)
            0. 如果Base.func()是一个抽象方法，则该处一定是调用了某个子类重写的func方法
            1. 如果Base.func()不是一个抽象方法，则该处有可能就是调用了Base类的func方法，也可能是调用了某个子类重写的func方法
            2. 调用工具get_son_of_class，查看当前类的所有子类
            3. 调用工具check_method_of_class查看各个子类中是否重写了该方法
            4. 重复2-3步，直到找到Base的所有子类以及子孙类，并判断完了各个类中是否重写定义了方法func
            5. 根据你的判断结果，按下面的输出格式要求输出。""")
        
        self.output_format = cleandoc("""\
            ## 输出格式（仅JSON，无多余文本）
            ```json
            {
              "status": "COMPLETED(任务成功)|NEEDS_ABILITY(需要使用工具)|FAILED(任务失败)",
              "confidence": 0.0-1.0,
              "summary": "...",
              "reasoning": "...",
              "result_data": {
                "base_class": "基类的类名",
                "subclasses": ["子类1的类名", "子类2的类名", "..."],
                "target_classes": ["可能的目标类（如果确定，则该列表只有一个元素，否则每个元素都是一个可能的目标类的类名）"],
              }
              "suggested_abilities": [ { "ability_name": "", "parameters": { }, "description": "" } ],
              "next_problems": [ { "description": "...", "kind": "...", "metadata": { } } ]
            }
            ```""")
        
        self.result_validator = self._validate_import_result  
        self.post_processor = self._post_process_import_result  
        self.task_params_validator = self._validate_task_params  
        

    def _validate_import_result(self, result_data: dict) -> bool:
        return True
        required_fields = ["base_class", "subclasses", "target_class"]
        return all(field in result_data for field in required_fields)

    def _validate_task_params(self, task: Task) -> bool:
        return True
        required_params = ["symbol_name", "import_stmt"]
        return all(param in task.params for param in required_params)
    
    def _post_process_import_result(self, result: SolverResult, task: Task) -> SolverResult:
        if config.ENABLE_SOLVER_SUPERVISION and result.status in ("COMPLETED", "NEEDS_FOLLOWUP"):
            voter_counts = getattr(config, 'SUPERVISION_VOTERS', 3)
            result = doublecheck_solver_result_by_supervisor(result, task, "", voter_counts=voter_counts, solver=self)
        
        return result
