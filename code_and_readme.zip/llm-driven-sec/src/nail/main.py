import sys
import logging
import os

current_file = os.path.realpath(__file__)
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.dirname(current_file)))
LIAN_DIR = os.path.join(ROOT_DIR, "lian", "src")
SRC_DIR = os.path.join(ROOT_DIR, "src")

sys.path.insert(0, LIAN_DIR)  
sys.path.insert(0, SRC_DIR)   
sys.path.insert(0, ROOT_DIR)  

from nail.problem_monitor import ProblemMonitor
from lian.config.constants import EVENT_KIND
from nail.config import config
workspace_dir = os.environ.get("SEC_WORKSPACE_DIR", os.path.join(ROOT_DIR, "tests", "workspace"))
os.makedirs(workspace_dir, exist_ok=True)
tests_dir_default = os.path.join(ROOT_DIR, "tests")
os.makedirs(tests_dir_default, exist_ok=True)
os.environ.setdefault("LLM_WORKFLOW_LOG_DIR", os.path.join(tests_dir_default, "single_run"))

session_dir_env = os.environ.get("NAIL_SESSION_DIR")
if not session_dir_env:
    log_file_path = os.path.join(tests_dir_default, "single_run_std_out_log")
else:
    log_file_path = None

logging.basicConfig(
    level=logging.DEBUG,
    format='%(levelname)s [%(name)s:%(lineno)d] %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)  
    ]
)
if log_file_path:
    try:
        class _Tee:
            def __init__(self, stream, file_path):
                self._stream = stream
                os.makedirs(os.path.dirname(file_path), exist_ok=True)
                self._file = open(file_path, 'a', encoding='utf-8', buffering=1)
            def write(self, data):
                self._stream.write(data)
                self._file.write(data)
            def flush(self):
                self._stream.flush()
                self._file.flush()
            def isatty(self):
                return False
        sys.stdout = _Tee(sys.stdout, log_file_path)
        sys.stderr = _Tee(sys.stderr, log_file_path)
    except Exception:
        pass
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("openai").setLevel(logging.WARNING)
logging.getLogger("openai._base_client").setLevel(logging.WARNING)
logging.getLogger("urllib3").setLevel(logging.WARNING)

from lian.main import Lian
from lian.lang.lang_analysis  import LangAnalysis
from lian.basics.basic_analysis import BasicSemanticAnalysis
from lian.core.prelim_semantics import PrelimSemanticAnalysis
from lian.core.global_semantics import GlobalSemanticAnalysis

class TaintWorker:

    def init_taint_engine(self):
        lian = Lian()
        lian.parse_cmds().set_workspace_dir(workspace_dir)
        lian.options.extern_path = config.EXTERN_PATH
        lian.init_submodules()
        problem_monitor = ProblemMonitor(lian)
        lian.event_manager.register(
            event=EVENT_KIND.P2STATE_EXTERN_CALLEE,
            handler=problem_monitor.method_call_handler,
            langs=[config.ANY_LANG]
        )
        LangAnalysis(lian).run()
        logging.info("------------------------------- LangAnalysis ------------------------------")
        BasicSemanticAnalysis(lian).run()
        logging.info("--------------------------- BasicSemanticAnalysis -------------------------")
        ssg = PrelimSemanticAnalysis(lian)
        ssg.run()
        logging.info("------------------------- SemanticSummaryGeneration -----------------------")
        GlobalSemanticAnalysis(lian, ssg.analyzed_method_list).run()
        logging.info("------------------------------ GlobalSemanticAnalysis -----------------------------")
        lian.loader.export()
        return lian

    def run(self):
        logging.info("初始化污点分析引擎...")
        self.lian = self.init_taint_engine()
        logging.info("==================== 污点分析引擎结束 ====================")


class Compiler:
    def run(self):
        logging.info(
            "\n\n" + "/" * 75 + "\n" +
            "////" + " " * 20 + "LLM-Driven Security Analysis" + " " * 18 + " ////\n"
            + "/" * 75 + "\n"
        )
        taint_worker = TaintWorker()
        taint_worker.run()

def main():
    Compiler().run()

if __name__ == "__main__":
    if len(sys.argv) == 1:
        print("Error: 请在main.py后传递一个参数<目标文件夹路径>")
        exit()
    if len(sys.argv) == 2:
        target_path = sys.argv[1]
        workspace_dir = os.environ.get("SEC_WORKSPACE_DIR", os.path.join(ROOT_DIR, "tests", "workspace"))
        sys.argv = [
            sys.argv[0],
            "run",
            "-l", "python",
            "-f",
            "-d",
            "--noextern",
            "-w", workspace_dir,
            target_path
        ]

    main()
